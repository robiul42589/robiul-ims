/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DataProvider, useData } from './context/DataContext';
import { LanguageProvider } from './context/LanguageContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { ToastContainer } from './components/ToastContainer';
import { LoginView } from './components/LoginView';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { UserProfileModal } from './components/UserProfileModal';
import { UserGuideModal } from './components/UserGuideModal';
import { DataCenterModal } from './components/DataCenterModal';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';

// Views
import { DashboardView } from './components/views/DashboardView';
import { FamilyView } from './components/views/FamilyView';
import { EducationSkillsView } from './components/views/EducationSkillsView';
import { AssetsView } from './components/views/AssetsView';
import { LiabilitiesView } from './components/views/LiabilitiesView';
import { EmploymentView } from './components/views/EmploymentView';
import { ReportsView } from './components/views/ReportsView';

const MainLayout: React.FC = () => {
  const { isAuthenticated, activeTab } = useData();
  const { isDark } = useTheme();

  // Sidebar mobile toggle
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Modals state
  const [isUserProfileOpen, setIsUserProfileOpen] = useState(false);
  const [isUserGuideOpen, setIsUserGuideOpen] = useState(false);
  const [isDataCenterOpen, setIsDataCenterOpen] = useState(false);
  const [isAIOpen, setIsAIOpen] = useState(false);

  // If user is not logged in, show Login Screen with demo credentials
  if (!isAuthenticated) {
    return <LoginView />;
  }

  // Active View router
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'family':
        return <FamilyView />;
      case 'education-skills':
        return <EducationSkillsView />;
      case 'assets':
        return <AssetsView />;
      case 'liabilities':
        return <LiabilitiesView />;
      case 'employment':
        return <EmploymentView />;
      case 'reports':
        return <ReportsView />;
      case 'data-center':
        return (
          <div className="space-y-6 animate-in fade-in">
            <div className="p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center max-w-xl mx-auto space-y-4 shadow-sm transition-colors">
              <div className="w-16 h-16 rounded-2xl bg-teal-50 dark:bg-teal-950/70 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto text-2xl">
                💾
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">ক্লাউড সিঙ্ক ও ডাটা ব্যাকআপ কেন্দ্র</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                আপনার সকল পারিবারিক, জমি-সম্পদ ও আর্থিক হিসাব ব্রাউজারের এনক্রিপ্টেড লোকাল ডাটাবেজে রিয়েল-টাইমে সংরক্ষিত রয়েছে।
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={() => setIsDataCenterOpen(true)}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-teal-600/20 cursor-pointer"
                >
                  ডাটা সেন্টার উইন্ডো খুলুন
                </button>
              </div>
            </div>
          </div>
        );
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col lg:flex-row antialiased transition-colors duration-200">
      {/* Sidebar (বাম পাশের সাইবার) */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onOpenUserProfile={() => setIsUserProfileOpen(true)}
        onOpenAI={() => setIsAIOpen(true)}
      />

      {/* Right Working Area (ডান পাশের ওয়াকিং এরিয়া) */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Header / Navbar */}
        <Navbar
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          onOpenUserGuide={() => setIsUserGuideOpen(true)}
          onOpenDataCenter={() => setIsDataCenterOpen(true)}
          onOpenUserProfile={() => setIsUserProfileOpen(true)}
          onOpenAI={() => setIsAIOpen(true)}
        />

        {/* Working Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
          <div className="max-w-7xl mx-auto">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* Global Modals & Drawers */}
      <UserProfileModal
        isOpen={isUserProfileOpen}
        onClose={() => setIsUserProfileOpen(false)}
      />

      <UserGuideModal
        isOpen={isUserGuideOpen}
        onClose={() => setIsUserGuideOpen(false)}
      />

      <DataCenterModal
        isOpen={isDataCenterOpen}
        onClose={() => setIsDataCenterOpen(false)}
      />

      <AIAssistantDrawer
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <DataProvider>
          <ToastContainer />
          <MainLayout />
        </DataProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
