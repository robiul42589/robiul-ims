import React, { useState, useRef, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  Loader2
} from 'lucide-react';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({ isOpen, onClose }) => {
  const { 
    userProfile, 
    familyMembers, 
    education, 
    assets, 
    liabilities, 
    employment 
  } = useData();
  const { language } = useLanguage();

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: language === 'bn' 
        ? `আসসালামু আলাইকুম! আমি রোবিউল IMS এর স্মার্ট এআই সহকারী। আপনার পরিবার পরিচিতি, জমি ও খতিয়ান, শিক্ষা, চাকুরী বা দেনা-পাওনা সংক্রান্ত যেকোনো প্রশ্ন করতে পারেন। কিভাবে সাহায্য করতে পারি?`
        : `Hello! I am the Robiul IMS Smart AI Assistant. Ask me anything about your family, land assets, debts, jobs, or system navigation!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (!isOpen) return null;

  // Context summary to feed into server or fallback
  const getContextSummary = () => {
    const totalPlots = assets.reduce((s, a) => s + (a.plots?.length || 0), 0);
    const totalAssetVal = assets.reduce((s, a) => s + (a.estimatedValueBDT || 0), 0);
    const activeDebts = liabilities.filter(l => l.status === 'চলমান');
    const totalDebt = activeDebts.reduce((s, l) => s + (l.loanAmountBDT - (l.paidAmountBDT || 0)), 0);
    const currentJob = employment.find(e => e.isCurrent);

    return {
      name: userProfile.nameBn,
      totalFamily: familyMembers.length,
      familyNames: familyMembers.map(m => `${m.nameBn} (${m.relation})`).join(', '),
      totalAssets: assets.length,
      totalPlots,
      totalAssetVal,
      activeDebtCount: activeDebts.length,
      totalRemainingDebt: totalDebt,
      currentJob: currentJob ? `${currentJob.designation} at ${currentJob.companyName}` : 'নেই',
      degrees: education.map(e => e.examName).join(', ')
    };
  };

  const handleSend = async (customPrompt?: string) => {
    const promptToSend = customPrompt || inputText;
    if (!promptToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: promptToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInputText('');
    setIsTyping(true);

    const ctx = getContextSummary();

    try {
      // Attempt backend API call
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          language,
          context: ctx
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data && data.reply) {
          setMessages(prev => [
            ...prev,
            {
              id: 'ai_' + Date.now(),
              sender: 'assistant',
              text: data.reply,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ]);
          setIsTyping(false);
          return;
        }
      }
    } catch (e) {
      // Backend unavailable or fallback
      console.warn('Backend AI unavailable, using intelligent local advisor');
    }

    // High quality intelligent local response generator
    setTimeout(() => {
      let reply = '';
      const p = promptToSend.toLowerCase();

      if (p.includes('ঋণ') || p.includes('দেনা') || p.includes('debt') || p.includes('loan')) {
        reply = language === 'bn'
          ? `আপনার সিস্টেমে বর্তমানে মোট ${ctx.activeDebtCount}টি চলমান দায় রয়েছে। অবশিষ্ট বকেয়া ঋণের পরিমাণ প্রায় ৳ ${ctx.totalRemainingDebt.toLocaleString('bn-BD')} টাকা। নিয়মিত কিস্তিতে এটি পরিশোধ চলমান রয়েছে।`
          : `You currently have ${ctx.activeDebtCount} active liabilities with approximately BDT ${ctx.totalRemainingDebt.toLocaleString()} remaining to be paid.`;
      } else if (p.includes('জমি') || p.includes('সম্পদ') || p.includes('খতিয়ান') || p.includes('land') || p.includes('asset')) {
        reply = language === 'bn'
          ? `আপনার সম্পদ বিবরণীতে মোট ${ctx.totalAssets}টি মৌজায় ${ctx.totalPlots}টি দাগ/প্লট নিবন্ধিত রয়েছে। আনুমানিক প্রাক্কলিত আর্থিক মূল্য প্রায় ৳ ${ctx.totalAssetVal.toLocaleString('bn-BD')} টাকা। আপনি "সম্পদ বিবরণী" মডিউলে নতুন দাগ ও মালিক যুক্ত করতে পারেন।`
          : `You have ${ctx.totalAssets} recorded assets across ${ctx.totalPlots} land plots with an estimated valuation of BDT ${ctx.totalAssetVal.toLocaleString()}.`;
      } else if (p.includes('পরিবার') || p.includes('family') || p.includes('সদস্য')) {
        reply = language === 'bn'
          ? `আপনার পরিবার পরিচিতিতে মোট ${ctx.totalFamily} জন সদস্যের পূর্ণাঙ্গ তথ্য সংরক্ষিত আছে: ${ctx.familyNames}। আপনি চাইলে নতুন সদস্যের ছবি, জন্ম নিবন্ধন ও এনআইডি নম্বর সহ যেকোনো সময় আপডেট করতে পারেন।`
          : `You have ${ctx.totalFamily} family members registered: ${ctx.familyNames}.`;
      } else if (p.includes('চাকুরী') || p.includes('job') || p.includes('career')) {
        reply = language === 'bn'
          ? `আপনার বর্তমান চাকুরীর পদবী: "${ctx.currentJob}"। আপনার চাকুরীর ইতিহাসে যোগদানপত্র এবং অভিজ্ঞতা সংক্রান্ত নথিপত্র সংরক্ষিত রয়েছে।`
          : `Your current active role is: "${ctx.currentJob}".`;
      } else if (p.includes('যুক্ত') || p.includes('কিভাবে') || p.includes('how to')) {
        reply = language === 'bn'
          ? `যে কোনো তথ্য যুক্ত করতে সংশ্লিষ্ট মেনুতে যান (যেমন: পরিবার পরিচিতি বা সম্পদ বিবরণী), এরপর উপরের ডানপাশের সবুজ "+ যুক্ত করুন" বাটনে ক্লিক করুন। ফর্মটি পূরণ করে সংরক্ষণ বাটনে চাপ দিলে আপনার তথ্য সাথে সাথে যুক্ত হয়ে পপআপ নিশ্চিতকরণ দেখাবে!`
          : `To add data, navigate to the respective section from the sidebar and click the "+ Add" button. Fill the form and save; a confirmation toast will appear instantly!`;
      } else {
        reply = language === 'bn'
          ? `ধন্যবাদ আপনার প্রশ্নের জন্য! মোঃ রোবিউল ইসলামের এই ইনফরমেশন সিস্টেমে পরিবার (${ctx.totalFamily} জন), জমি সম্পদ (${ctx.totalPlots}টি দাগ), শিক্ষাগত যোগ্যতা ও চাকুরী সংক্রান্ত সকল তথ্য সুন্দরভাবে সংরক্ষিত রয়েছে। কোনো নির্দিষ্ট বিষয় দেখতে বাম পাশের মেনু ব্যবহার করুন অথবা আমাকে বিস্তারিত জিজ্ঞেস করুন।`
          : `Thanks for asking! All records for Md. Robiul Islam including family (${ctx.totalFamily} members), assets (${ctx.totalPlots} plots), education, and employment are safely synced and ready.`;
      }

      setMessages(prev => [
        ...prev,
        {
          id: 'ai_' + Date.now(),
          sender: 'assistant',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsTyping(false);
    }, 600);
  };

  const samplePrompts = language === 'bn' ? [
    'আমার মোট ঋণ ও দেনার পরিমাণ কত?',
    'আমার জমির দাগ ও খতিয়ানের বিবরণ দাও',
    'পরিবারের সদস্যদের তালিকা দেখতে চাই',
    'নতুন তথ্য কিভাবে যুক্ত করব?'
  ] : [
    'What is my total remaining debt?',
    'Summary of registered land plots',
    'List all registered family members',
    'How do I add new records?'
  ];

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-white dark:bg-slate-900 shadow-2xl border-l border-slate-200 dark:border-slate-800 flex flex-col animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">
              {language === 'bn' ? 'এআই স্মার্ট সহকারী' : 'Robiul AI Assistant'}
            </h3>
            <p className="text-[11px] text-emerald-200">
              {language === 'bn' ? 'তাত্ক্ষণিক সহায়তা ও ইনফো গাইড' : 'Instant Q&A and Navigation'}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Suggestion Chips */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
        <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
          {language === 'bn' ? 'সরাসরি প্রশ্ন নির্বাচন করুন:' : 'Suggested Queries:'}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {samplePrompts.map((sp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(sp)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-slate-200 dark:border-slate-700 hover:border-emerald-300 dark:hover:border-emerald-700 text-slate-700 dark:text-slate-200 hover:text-emerald-800 dark:hover:text-emerald-300 transition-colors cursor-pointer"
            >
              {sp}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/50 dark:bg-slate-950/40 text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex items-start gap-2.5 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                m.sender === 'user'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-teal-700 text-teal-100 shadow-xs'
              }`}
            >
              {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div
              className={`max-w-[82%] p-3 rounded-2xl shadow-xs leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-emerald-600 text-white rounded-tr-xs'
                  : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-tl-xs'
              }`}
            >
              <p className="whitespace-pre-wrap">{m.text}</p>
              <span
                className={`block text-[9px] mt-1 text-right ${
                  m.sender === 'user' ? 'text-emerald-100' : 'text-slate-400 dark:text-slate-500'
                }`}
              >
                {m.timestamp}
              </span>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 text-xs p-2">
            <Loader2 className="w-4 h-4 animate-spin text-emerald-600 dark:text-emerald-400" />
            <span>{language === 'bn' ? 'এআই উত্তর তৈরি করছে...' : 'AI is thinking...'}</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={language === 'bn' ? 'যেকোনো প্রশ্ন লিখুন...' : 'Type your question...'}
            className="flex-1 px-3.5 py-2.5 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isTyping}
            className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white disabled:opacity-40 transition-colors cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
