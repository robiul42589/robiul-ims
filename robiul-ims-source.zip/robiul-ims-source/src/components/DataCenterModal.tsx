import React, { useRef, useState } from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  ShieldCheck, 
  CheckCircle2,
  FolderArchive,
  Github
} from 'lucide-react';

interface DataCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataCenterModal: React.FC<DataCenterModalProps> = ({ isOpen, onClose }) => {
  const { 
    familyMembers, 
    education, 
    skills, 
    assets, 
    liabilities, 
    employment, 
    exportDataToJson, 
    importDataFromJson, 
    resetToDemoData 
  } = useData();
  const { language } = useLanguage();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalRecords = 
    familyMembers.length + 
    education.length + 
    skills.length + 
    assets.length + 
    liabilities.length + 
    employment.length;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importDataFromJson(content);
        if (success) {
          setImportStatus(language === 'bn' ? 'ডাটা সফলভাবে রিস্টোর হয়েছে!' : 'Data restored successfully!');
          setTimeout(() => setImportStatus(null), 4000);
        }
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-teal-950 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                {language === 'bn' ? 'ক্লাউড সিঙ্ক ও ডাটা সেন্টার' : 'Cloud Sync & Data Center'}
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn' ? 'তথ্যাদির ব্যাকআপ ও রিস্টোর ব্যবস্থাপনা' : 'Data Persistence & Backup Management'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs">
          {/* Status banner */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
              <div>
                <p className="font-bold text-sm">
                  {language === 'bn' ? 'সিঙ্ক স্ট্যাটাস: সক্রিয় ও নিরাপদ' : 'Sync Status: Active & Secured'}
                </p>
                <p className="text-emerald-700 dark:text-emerald-300 text-[11px] mt-0.5">
                  {language === 'bn' ? 'আপনার সকল তথ্য রিয়েল-টাইমে লোকাল স্টোরেজে সিঙ্ক হচ্ছে।' : 'All information is securely synced in real-time.'}
                </p>
              </div>
            </div>
            <ShieldCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400 shrink-0" />
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400 text-[11px] block">{language === 'bn' ? 'মোট রেকর্ড' : 'Total Records'}</span>
              <span className="text-lg font-bold text-slate-800 dark:text-slate-100">{totalRecords} টি</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400 text-[11px] block">{language === 'bn' ? 'জমি ও প্লট' : 'Land Plots'}</span>
              <span className="text-lg font-bold text-slate-800 dark:text-slate-100">
                {assets.reduce((sum, a) => sum + (a.plots?.length || 0), 0)} টি
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400 text-[11px] block">{language === 'bn' ? 'স্টোরেজ ড্রাইভ' : 'Storage'}</span>
              <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">Local Encrypted</span>
            </div>
          </div>

          {importStatus && (
            <div className="p-3 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              {importStatus}
            </div>
          )}

          {/* Actions */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">
              {language === 'bn' ? 'সোর্স কোড ও ডাটা সংরক্ষণ' : 'Source Code & Data Management'}
            </h4>

            {/* 1. Full Source Code .ZIP Download for GitHub */}
            <div className="p-4 rounded-xl border-2 border-purple-200 dark:border-purple-800/80 bg-purple-50/60 dark:bg-purple-950/30 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-purple-600 text-white shadow-xs shrink-0">
                    <FolderArchive className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-sm text-slate-900 dark:text-white">
                        {language === 'bn' ? 'সম্পূর্ণ প্রজেক্ট সোর্স কোড (.ZIP)' : 'Full Source Code (.ZIP)'}
                      </p>
                      <span className="px-2 py-0.5 rounded-full bg-purple-200 dark:bg-purple-900/80 text-purple-800 dark:text-purple-300 text-[10px] font-bold">
                        GitHub Ready
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">
                      {language === 'bn'
                        ? 'সরাসরি GitHub-এ আপলোড করার জন্য সম্পূর্ণ কোডবেজ জিপ ফাইল হিসেবে ডাউনলোড করুন।'
                        : 'Download complete application codebase package ready for GitHub repository.'}
                    </p>
                  </div>
                </div>

                <a
                  href="/api/download-zip"
                  download="robiul-ims-source.zip"
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-purple-600/25 transition-all text-xs shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>{language === 'bn' ? 'জিপ ডাউনলোড করুন' : 'Download ZIP'}</span>
                </a>
              </div>

              {/* GitHub instructions snippet */}
              <div className="p-2.5 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-purple-100 dark:border-purple-900/60 text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-200">
                  <Github className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'গিটহাবে আপলোড করার নিয়ম:' : 'How to push to GitHub:'}</span>
                </div>
                <p className="font-mono text-[10px] text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-850 p-1.5 rounded">
                  git init &amp;&amp; git add . &amp;&amp; git commit -m &quot;Initial commit&quot; &amp;&amp; git branch -M main &amp;&amp; git remote add origin &lt;URL&gt; &amp;&amp; git push -u origin main
                </p>
              </div>
            </div>

            {/* Export JSON */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-100">
                    {language === 'bn' ? 'ব্যাকআপ ডাউনলোড (JSON)' : 'Download Backup (JSON)'}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                    {language === 'bn' ? 'সকল পারিবারিক, সম্পদ ও আর্থিক তথ্য আপনার কম্পিউটারে সংরক্ষণ করুন' : 'Export complete database to an offline JSON file'}
                  </p>
                </div>
              </div>
              <button
                onClick={exportDataToJson}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold cursor-pointer shrink-0 transition-colors"
              >
                {language === 'bn' ? 'ডাউনলোড' : 'Download'}
              </button>
            </div>

            {/* Import */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-100">
                    {language === 'bn' ? 'ডাটা রিস্টোর (JSON আপলোড)' : 'Restore Data (Upload JSON)'}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                    {language === 'bn' ? 'পূর্বের সংরক্ষিত ব্যাকআপ ফাইল থেকে সকল তথ্য ফিরিয়ে আনুন' : 'Import and restore from a previously downloaded backup file'}
                  </p>
                </div>
              </div>
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".json,application/json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer shrink-0 transition-colors"
                >
                  {language === 'bn' ? 'ফাইল বাছুন' : 'Choose File'}
                </button>
              </div>
            </div>

            {/* Reset */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-rose-100 dark:border-rose-950/60 bg-rose-50/40 dark:bg-rose-950/20">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-100">
                    {language === 'bn' ? 'প্রাথমিক ডেমো তথ্যে রিসেট' : 'Reset to Default Demo Data'}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                    {language === 'bn' ? 'রিসার্চ ও টেস্টিংয়ের জন্য ডেমো ডাটা ফিরিয়ে আনুন' : 'Restores initial test records for demo review'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (confirm(language === 'bn' ? 'আপনি কি ডেমো ডাটাতে রিসেট করতে চান?' : 'Are you sure you want to reset to demo data?')) {
                    resetToDemoData();
                  }
                }}
                className="px-3.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 font-semibold cursor-pointer shrink-0 transition-colors"
              >
                {language === 'bn' ? 'রিসেট' : 'Reset'}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-950/60 px-6 py-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
