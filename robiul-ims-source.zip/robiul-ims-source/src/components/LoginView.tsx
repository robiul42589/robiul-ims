import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  KeyRound, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Globe, 
  Sun, 
  Moon 
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login } = useData();
  const { language, toggleLanguage, t } = useLanguage();
  const { theme, toggleTheme, isDark } = useTheme();

  const [username, setUsername] = useState('robiul');
  const [password, setPassword] = useState('123456');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsLoading(true);
    setTimeout(() => {
      const ok = login(username, password);
      setIsLoading(false);
      if (!ok) {
        setErrorMsg(language === 'bn' ? 'সঠিক ইউজার আইডি এবং পাসওয়ার্ড প্রদান করুন।' : 'Please enter valid credentials.');
      }
    }, 400);
  };

  const handleQuickDemo = () => {
    setUsername('robiul');
    setPassword('123456');
    setIsLoading(true);
    setTimeout(() => {
      login('robiul', '123456');
      setIsLoading(false);
    }, 300);
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between p-4 sm:p-6 lg:p-8 transition-colors duration-300 ${
      isDark 
        ? 'bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-slate-100' 
        : 'bg-gradient-to-br from-slate-100 via-emerald-50/40 to-teal-100/50 text-slate-900'
    }`}>
      {/* Top bar with language and theme switches */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between py-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-bold text-xl">
            R
          </div>
          <div>
            <h1 className={`font-bold text-lg leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
              রবিউল IMS
            </h1>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              Information Management System
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            title={isDark ? (language === 'bn' ? 'লাইট মুড করুন' : 'Light Mode') : (language === 'bn' ? 'ডার্ক মুড করুন' : 'Dark Mode')}
            className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isDark 
                ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-amber-400' 
                : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-xs'
            }`}
          >
            {isDark ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline text-slate-200">{language === 'bn' ? 'লাইট' : 'Light'}</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-slate-600" />
                <span className="hidden sm:inline text-slate-700">{language === 'bn' ? 'ডার্ক' : 'Dark'}</span>
              </>
            )}
          </button>

          {/* Language Switch */}
          <button
            onClick={toggleLanguage}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
              isDark
                ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700/60 text-slate-300'
                : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-xs'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-500" />
            <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>
        </div>
      </div>

      {/* Main container */}
      <div className="max-w-5xl w-full mx-auto my-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center py-6">
        {/* Left Side: Presentation and Feature badges */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            {language === 'bn' ? 'ব্যক্তিগত ও পারিবারিক তথ্য ভাণ্ডার' : 'Personal & Family Information Vault'}
          </div>

          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
            {language === 'bn' ? (
              <>আপনার জীবনের <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500 dark:from-emerald-400 dark:to-teal-300">যাবতীয় তথ্য</span> এক প্ল্যাটফর্মে সুরক্ষিত</>
            ) : (
              <>Keep all your life’s <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500 dark:from-emerald-400 dark:to-teal-300">vital records</span> safely in one place</>
            )}
          </h2>

          <p className={`text-sm sm:text-base leading-relaxed max-w-xl ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
            {language === 'bn'
              ? 'পরিবার পরিচিতি, শিক্ষাগত সনদ ও দক্ষতা, জমি ও খতিয়ান সংক্রান্ত বিবরণী, দায়-দেনা হিসাব এবং চাকুরীর সম্পূর্ণ ইতিহাস সংরক্ষণ ও সহজে রিপোর্টিংয়ের আধুনিক সমাধান।'
              : 'Complete solution for managing family records, academic credentials, land assets with Khatian & Dag numbers, liabilities, career history, and printable reports.'}
          </p>

          {/* Highlights checklist */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {[
              { bn: 'পরিবার সদস্যদের পূর্ণাঙ্গ পরিচিতি ও NID', en: 'Family profiles with NID & addresses' },
              { bn: 'একাধিক মালিক ও দাগসহ জমির সম্পদ বিবরণী', en: 'Land records with multi-owners & plots' },
              { bn: 'দায় ও ঋণ পরিশোধের স্পষ্ট হিসাব', en: 'Liabilities & debt settlement tracking' },
              { bn: 'চাকুরীর ধারাবাহিক ইতিহাস ও যোগদান পত্র', en: 'Employment history with letters' },
              { bn: 'এক ক্লিকে প্রফেশনাল প্রতিবেদন ও প্রিন্ট', en: 'One-click consolidated reports & print' },
              { bn: 'ডার্ক ও লাইট মুড, এআই সহকারী ও ব্যাকআপ', en: 'Dark/Light mode, AI assistant & backup' },
            ].map((item, idx) => (
              <div key={idx} className={`flex items-center gap-2.5 text-xs ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>{language === 'bn' ? item.bn : item.en}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Login Card */}
        <div className="lg:col-span-5">
          <div className={`backdrop-blur-xl border rounded-2xl p-6 sm:p-8 shadow-2xl transition-all ${
            isDark 
              ? 'bg-slate-800/90 border-slate-700/80 shadow-black/40' 
              : 'bg-white/95 border-slate-200/90 shadow-slate-300/40'
          }`}>
            <div className={`flex items-center justify-between pb-4 border-b mb-6 ${
              isDark ? 'border-slate-700/60' : 'border-slate-200'
            }`}>
              <div>
                <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {language === 'bn' ? 'সিস্টেমে লগইন করুন' : 'System Login'}
                </h3>
                <p className={`text-xs mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {language === 'bn' ? 'আপনার অ্যাকাউন্টে প্রবেশ করতে তথ্য দিন' : 'Enter your credentials to continue'}
                </p>
              </div>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDark ? 'bg-slate-700/80 text-emerald-400' : 'bg-emerald-50 text-emerald-600'
              }`}>
                <Lock className="w-5 h-5" />
              </div>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-500 dark:text-rose-400 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  {language === 'bn' ? 'ইউজার আইডি / ইমেইল' : 'User ID / Email'}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl text-sm transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      isDark 
                        ? 'bg-slate-900/80 border border-slate-700 text-white placeholder-slate-500' 
                        : 'bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400'
                    }`}
                    placeholder="যেমন: robiul"
                  />
                </div>
              </div>

              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl text-sm transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      isDark 
                        ? 'bg-slate-900/80 border border-slate-700 text-white placeholder-slate-500' 
                        : 'bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400'
                    }`}
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 font-semibold text-slate-950 text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <span>{language === 'bn' ? 'ড্যাশবোর্ডে প্রবেশ করুন' : 'Login to Dashboard'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Prompt Requirement: Demo ID & Password clearly displayed below */}
            <div className={`mt-6 pt-5 border-t -mx-6 -mb-6 p-6 rounded-b-2xl ${
              isDark 
                ? 'border-slate-700/60 bg-slate-900/60' 
                : 'border-slate-100 bg-slate-50/80'
            }`}>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  {language === 'bn' ? 'ডেমো আইডি ও পাসওয়ার্ড' : 'Demo Credentials'}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                  isDark ? 'bg-slate-800 text-slate-400 border-slate-700' : 'bg-white text-slate-600 border-slate-200'
                }`}>
                  {language === 'bn' ? 'পরীক্ষামূলক ব্যবহার' : 'Testing Access'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                <div className={`p-2.5 rounded-lg border ${
                  isDark ? 'bg-slate-800/80 border-slate-700/60' : 'bg-white border-slate-200'
                }`}>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{language === 'bn' ? 'ইউজার আইডি:' : 'User ID:'}</p>
                  <p className={`font-mono font-bold select-all ${isDark ? 'text-white' : 'text-slate-900'}`}>robiul</p>
                </div>
                <div className={`p-2.5 rounded-lg border ${
                  isDark ? 'bg-slate-800/80 border-slate-700/60' : 'bg-white border-slate-200'
                }`}>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{language === 'bn' ? 'পাসওয়ার্ড:' : 'Password:'}</p>
                  <p className={`font-mono font-bold select-all ${isDark ? 'text-white' : 'text-slate-900'}`}>123456</p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleQuickDemo}
                className="w-full py-2 px-3 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {language === 'bn' ? '১-ক্লিকে সরাসরি ডেমো লগইন করুন' : '1-Click Direct Demo Login'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer copyright */}
      <div className={`max-w-6xl w-full mx-auto text-center py-2 text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
        রোবিউল ইনফরমেশন ম্যানেজমেন্ট সিস্টেম (Robiul IMS) &copy; ২০২৬ । সকল স্বত্ব সংরক্ষিত।
      </div>
    </div>
  );
};
