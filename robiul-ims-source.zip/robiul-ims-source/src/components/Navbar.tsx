import React, { useState, useRef, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { 
  Menu, 
  Search, 
  CloudCheck, 
  HelpCircle, 
  Sparkles, 
  User, 
  LogOut, 
  LayoutDashboard, 
  ChevronDown, 
  Globe,
  Sun,
  Moon,
  FolderArchive
} from 'lucide-react';

interface NavbarProps {
  onToggleSidebar: () => void;
  onOpenUserGuide: () => void;
  onOpenDataCenter: () => void;
  onOpenUserProfile: () => void;
  onOpenAI: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleSidebar,
  onOpenUserGuide,
  onOpenDataCenter,
  onOpenUserProfile,
  onOpenAI
}) => {
  const { userProfile, logout, setActiveTab, globalSearchQuery, setGlobalSearchQuery } = useData();
  const { language, toggleLanguage, t } = useLanguage();
  const { theme, toggleTheme, isDark } = useTheme();

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="no-print sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3 shadow-xs transition-colors duration-200">
      {/* Left: Mobile menu toggle & Title / Search */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Toggle Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Global Search */}
        <div className="relative w-full max-w-md hidden sm:block">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-slate-500">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={globalSearchQuery}
            onChange={(e) => setGlobalSearchQuery(e.target.value)}
            placeholder={t('searchPlaceholder', 'যেকোনো তথ্য খুঁজুন (নাম, মৌজা, খতিয়ান, প্রতিষ্ঠান)...')}
            className="w-full pl-9 pr-3.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 transition-all"
          />
          {globalSearchQuery && (
            <button
              onClick={() => setGlobalSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Right Controls: Dark Mode, Language, Cloud Sync, Guide, AI Assistant, User Dropdown */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Dark / Light Mode Toggle */}
        <button
          onClick={toggleTheme}
          title={isDark ? (language === 'bn' ? 'লাইট মুড সক্রিয় করুন' : 'Switch to Light Mode') : (language === 'bn' ? 'ডার্ক মুড সক্রিয় করুন' : 'Switch to Dark Mode')}
          aria-label="Toggle Dark Mode"
          className="p-2 sm:px-2.5 sm:py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-amber-400 transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
        >
          {isDark ? (
            <>
              <Sun className="w-4 h-4 text-amber-400 animate-in spin-in-90 duration-300" />
              <span className="hidden xl:inline text-xs font-semibold text-slate-200">
                {language === 'bn' ? 'লাইট' : 'Light'}
              </span>
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 text-slate-600 dark:text-slate-300 animate-in spin-in-90 duration-300" />
              <span className="hidden xl:inline text-xs font-semibold text-slate-700">
                {language === 'bn' ? 'ডার্ক' : 'Dark'}
              </span>
            </>
          )}
        </button>

        {/* Language switch */}
        <button
          onClick={toggleLanguage}
          title={language === 'bn' ? 'Switch to English' : 'বাংলায় পরিবর্তন করুন'}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span className="hidden md:inline">{language === 'bn' ? 'English' : 'বাংলা'}</span>
        </button>

        {/* Cloud Sync / Data Center Button */}
        <button
          onClick={onOpenDataCenter}
          title={t('dataCenter', 'ক্লাউড সিঙ্ক / ডাটা সেন্টার')}
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/70 hover:bg-teal-100/80 dark:hover:bg-teal-900/80 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-300 text-xs font-semibold transition-colors cursor-pointer"
        >
          <CloudCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span className="hidden sm:inline">
            {language === 'bn' ? 'ক্লাউড সিঙ্ক' : 'Cloud Sync'}
          </span>
        </button>

        {/* User Guide Button */}
        <button
          onClick={onOpenUserGuide}
          title={t('userGuide', 'ব্যবহার নির্দেশিকা')}
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
        >
          <HelpCircle className="w-4 h-4 text-slate-500 dark:text-slate-400" />
          <span className="hidden sm:inline">
            {language === 'bn' ? 'ব্যবহার নির্দেশিকা' : 'User Guide'}
          </span>
        </button>

        {/* Source Code ZIP Download Button for GitHub */}
        <a
          href="/api/download-zip"
          download="robiul-ims-source.zip"
          title={language === 'bn' ? 'সম্পূর্ণ সোর্স কোড ডাউনলোড (.ZIP) - GitHub এর জন্য' : 'Download Full Source Code (.ZIP) for GitHub'}
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-purple-50 dark:bg-purple-950/70 hover:bg-purple-100/80 dark:hover:bg-purple-900/80 border border-purple-200 dark:border-purple-800 text-purple-800 dark:text-purple-300 text-xs font-semibold transition-colors cursor-pointer"
        >
          <FolderArchive className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          <span className="hidden lg:inline">
            {language === 'bn' ? 'সোর্স কোড .ZIP' : 'Source .ZIP'}
          </span>
        </a>

        {/* AI Assistant Button */}
        <button
          onClick={onOpenAI}
          title={t('aiAssistant', 'এআই সহকারী')}
          className="relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs shadow-emerald-600/30 transition-all cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden md:inline">
            {language === 'bn' ? 'এআই সহকারী' : 'AI Helper'}
          </span>
          <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-300"></span>
          </span>
        </button>

        {/* User Info & Navigation Dropdown as requested */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-2 p-1 sm:pl-2 sm:pr-2.5 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all cursor-pointer"
          >
            <img
              src={userProfile.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
              alt={userProfile.nameBn}
              className="w-8 h-8 rounded-lg object-cover border border-emerald-500"
            />
            <div className="text-left hidden lg:block">
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100 leading-tight line-clamp-1">{userProfile.nameBn}</p>
              <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium leading-tight">
                {language === 'bn' ? 'ব্যবহারকারীর তথ্য' : 'User Info'}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Navigation Dropdown Menu */}
          {isDropdownOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 text-xs text-slate-700 dark:text-slate-200 z-50 animate-in fade-in slide-in-from-top-2">
              <div className="px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <p className="font-bold text-slate-900 dark:text-white text-xs">{userProfile.nameBn}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{userProfile.email}</p>
              </div>

              {/* 1. ড্যাশবোর্ড */}
              <button
                onClick={() => {
                  setActiveTab('dashboard');
                  setIsDropdownOpen(false);
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-800 dark:hover:text-emerald-300 transition-colors cursor-pointer"
              >
                <LayoutDashboard className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="font-medium">{t('dashboard', 'ড্যাশবোর্ড')}</span>
              </button>

              {/* 2. ইউজারের তথ্য দেখুন (View & Edit User Profile) */}
              <button
                onClick={() => {
                  onOpenUserProfile();
                  setIsDropdownOpen(false);
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-800 dark:hover:text-emerald-300 transition-colors cursor-pointer"
              >
                <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="font-medium">{t('viewProfile', 'ইউজারের তথ্য দেখুন')}</span>
              </button>

              {/* সোর্স কোড ডাউনলোড (.ZIP) */}
              <a
                href="/api/download-zip"
                download="robiul-ims-source.zip"
                onClick={() => setIsDropdownOpen(false)}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-purple-50 dark:hover:bg-purple-950/40 text-purple-700 dark:text-purple-300 transition-colors cursor-pointer"
              >
                <FolderArchive className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span className="font-medium">{language === 'bn' ? 'সোর্স কোড .ZIP ডাউনলোড' : 'Download Source .ZIP'}</span>
              </a>

              {/* Quick Dark Mode toggle in Dropdown */}
              <button
                onClick={() => {
                  toggleTheme();
                  setIsDropdownOpen(false);
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                {isDark ? (
                  <>
                    <Sun className="w-4 h-4 text-amber-400" />
                    <span className="font-medium">{language === 'bn' ? 'লাইট মুড করুন' : 'Light Mode'}</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-4 h-4 text-slate-500" />
                    <span className="font-medium">{language === 'bn' ? 'ডার্ক মুড করুন' : 'Dark Mode'}</span>
                  </>
                )}
              </button>

              <div className="my-1 border-t border-slate-100 dark:border-slate-800"></div>

              {/* 3. লগআউট */}
              <button
                onClick={() => {
                  setIsDropdownOpen(false);
                  logout();
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 transition-colors cursor-pointer font-medium"
              >
                <LogOut className="w-4 h-4" />
                <span>{t('logout', 'লগআউট')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
