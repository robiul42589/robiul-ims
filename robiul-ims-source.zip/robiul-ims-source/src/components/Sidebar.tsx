import React from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  Landmark, 
  WalletCards, 
  Briefcase, 
  FileSpreadsheet, 
  Database,
  Sparkles,
  LogOut,
  Sun,
  Moon,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenUserProfile: () => void;
  onOpenAI: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  onOpenUserProfile,
  onOpenAI
}) => {
  const { 
    activeTab, 
    setActiveTab, 
    userProfile, 
    logout,
    familyMembers,
    education,
    skills,
    assets,
    liabilities,
    employment
  } = useData();
  const { language, t } = useLanguage();
  const { isDark, toggleTheme } = useTheme();

  const menuItems = [
    {
      id: 'dashboard',
      labelBn: 'ড্যাশবোর্ড',
      labelEn: 'Dashboard',
      icon: <LayoutDashboard className="w-5 h-5" />,
      badge: null
    },
    {
      id: 'family',
      labelBn: 'পরিবার পরিচিতি',
      labelEn: 'Family Profile',
      icon: <Users className="w-5 h-5" />,
      badge: familyMembers.length
    },
    {
      id: 'education-skills',
      labelBn: 'শিক্ষা ও দক্ষতা',
      labelEn: 'Education & Skills',
      icon: <GraduationCap className="w-5 h-5" />,
      badge: education.length + skills.length
    },
    {
      id: 'assets',
      labelBn: 'সম্পদ বিবরণী',
      labelEn: 'Asset & Land Statement',
      icon: <Landmark className="w-5 h-5" />,
      badge: assets.length
    },
    {
      id: 'liabilities',
      labelBn: 'দায় সমূহ',
      labelEn: 'Liabilities & Loans',
      icon: <WalletCards className="w-5 h-5" />,
      badge: liabilities.filter(l => l.status === 'চলমান').length || null
    },
    {
      id: 'employment',
      labelBn: 'চাকুরীর ইতিহাস',
      labelEn: 'Employment History',
      icon: <Briefcase className="w-5 h-5" />,
      badge: employment.length
    },
    {
      id: 'reports',
      labelBn: 'রিপোর্ট',
      labelEn: 'Reports & Analytics',
      icon: <FileSpreadsheet className="w-5 h-5" />,
      badge: null
    },
    {
      id: 'data-center',
      labelBn: 'ক্লাউড সিঙ্ক / ডাটা সেন্টার',
      labelEn: 'Data Center & Backup',
      icon: <Database className="w-5 h-5" />,
      badge: null
    }
  ];

  const handleSelect = (id: string) => {
    setActiveTab(id);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`no-print fixed lg:static top-0 bottom-0 left-0 z-40 w-64 sm:w-72 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-300 flex flex-col justify-between transition-transform duration-300 ease-in-out border-r border-slate-200 dark:border-slate-850 shadow-xl lg:shadow-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top Brand Logo */}
        <div>
          <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-extrabold text-xl shadow-lg shadow-emerald-500/20">
                R
              </div>
              <div>
                <h1 className="font-extrabold text-base text-slate-900 dark:text-white tracking-tight">
                  {language === 'bn' ? 'রবিউল IMS' : 'Robiul IMS'}
                </h1>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                  {language === 'bn' ? 'ইনফরমেশন ম্যানেজমেন্ট সিস্টেম' : 'Info Management System'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-270px)]">
            <p className="px-3 pt-2 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {language === 'bn' ? 'প্রধান মেনু' : 'Main Menu'}
            </p>

            {menuItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}>
                      {item.icon}
                    </span>
                    <span>{language === 'bn' ? item.labelBn : item.labelEn}</span>
                  </div>

                  {item.badge !== null && (
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Profile and Quick Action card */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-850 bg-slate-50/80 dark:bg-slate-950/40 space-y-2">
          {/* Quick Theme Toggle & AI help row */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-xs"
              title={isDark ? 'Light Mode' : 'Dark Mode'}
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'bn' ? 'লাইট মুড' : 'Light'}</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600" />
                  <span>{language === 'bn' ? 'ডার্ক মুড' : 'Dark'}</span>
                </>
              )}
            </button>

            <button
              onClick={onOpenAI}
              className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-500/15 hover:bg-emerald-100 dark:hover:bg-emerald-500/25 border border-emerald-200 dark:border-emerald-500/30 text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{language === 'bn' ? 'এআই গাইড' : 'AI Help'}</span>
            </button>
          </div>

          {/* User mini card */}
          <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
            <button
              onClick={() => {
                onOpenUserProfile();
                if (window.innerWidth < 1024) onClose();
              }}
              className="flex items-center gap-2.5 text-left flex-1 min-w-0 cursor-pointer"
            >
              <img
                src={userProfile.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                alt={userProfile.nameBn}
                className="w-8 h-8 rounded-lg object-cover border border-emerald-500 shrink-0"
              />
              <div className="min-w-0">
                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{userProfile.nameBn}</p>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 truncate">{userProfile.designation}</p>
              </div>
            </button>

            <button
              onClick={logout}
              title={t('logout', 'লগআউট')}
              className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
