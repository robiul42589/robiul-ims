import React from 'react';
import { useData } from '../context/DataContext';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useData();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-5 right-5 z-[100] flex flex-col gap-2.5 max-w-sm w-full pointer-events-none transition-all">
      {toasts.map((toast) => {
        let bgColor = 'bg-emerald-600 text-white';
        let icon = <CheckCircle2 className="w-5 h-5 text-white shrink-0 mt-0.5" />;

        if (toast.type === 'error') {
          bgColor = 'bg-rose-600 text-white';
          icon = <AlertCircle className="w-5 h-5 text-white shrink-0 mt-0.5" />;
        } else if (toast.type === 'warning') {
          bgColor = 'bg-amber-600 text-white';
          icon = <AlertTriangle className="w-5 h-5 text-white shrink-0 mt-0.5" />;
        } else if (toast.type === 'info') {
          bgColor = 'bg-blue-600 text-white';
          icon = <Info className="w-5 h-5 text-white shrink-0 mt-0.5" />;
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-xl shadow-slate-900/10 border border-white/20 backdrop-blur-md transform transition-all duration-300 animate-in slide-in-from-top-3 fade-in ${bgColor}`}
          >
            {icon}
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold tracking-wide">{toast.title}</h4>
              <p className="text-xs text-white/90 mt-0.5 leading-relaxed">{toast.message}</p>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-white/70 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/10"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
