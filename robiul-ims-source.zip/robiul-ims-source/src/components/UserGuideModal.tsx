import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  HelpCircle, 
  Users, 
  GraduationCap, 
  Landmark, 
  WalletCards, 
  Briefcase, 
  FileSpreadsheet, 
  Database, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface UserGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserGuideModal: React.FC<UserGuideModalProps> = ({ isOpen, onClose }) => {
  const { language } = useLanguage();

  if (!isOpen) return null;

  const sections = [
    {
      icon: <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      titleBn: 'পরিবার পরিচিতি মডিউল',
      titleEn: 'Family Profile Module',
      descBn: 'পরিবারের প্রত্যেক সদস্যের বাংলা ও ইংরেজি নাম, জন্ম তারিখ, পিতা-মাতার নাম, জন্ম নিবন্ধন, এনআইডি এবং বর্তমান ঠিকানা পূরণ করে ছবিসহ তথ্য যোগ করুন। সংরক্ষিত কার্ডের ডানপাশের ৩টি বাটন (দেখুন, তথ্য সংশোধন, মুছে ফেলুন) দিয়ে সহজেই নিয়ন্ত্রণ করুন।',
      descEn: 'Add family members with names, DoB, parents names, birth cert & NID numbers, address and photo. Manage easily using the 3 action buttons: Show, Edit, and Delete.'
    },
    {
      icon: <GraduationCap className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      titleBn: 'শিক্ষা ও দক্ষতা মডিউল',
      titleEn: 'Education & Skills Module',
      descBn: 'এখানে দুটি পৃথক বাটন রয়েছে: "শিক্ষাগত যোগ্যতা যুক্ত করুন" (ডিগ্রি, পাশের সন, বোর্ড, সিজিপিএ, সনদের কপি) এবং "দক্ষতা যুক্ত করুন" (দক্ষতার স্তর, অভিজ্ঞতা ও বিবরণ)।',
      descEn: 'Two distinct buttons for "Add Education" (Degree, Passing Year, Board, CGPA, Certificate) and "Add Skill" (Proficiency, Experience & Details).'
    },
    {
      icon: <Landmark className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
      titleBn: 'সম্পদ বিবরণী (জমি ও ভূমি রেকর্ড)',
      titleEn: 'Asset & Land Statement',
      descBn: '৪টি সুনির্দিষ্ট সেকশন: সাধারণ তথ্য (মৌজা, জেএল, খতিয়ান), একাধিক মালিক যুক্ত করার সুবিধা ("আরো মালিক যুক্ত করুন"), একাধিক দাগ/প্লট যুক্ত করার সুবিধা ("আরো দাগ/প্লট যুক্ত করুন") এবং দলিল ও খতিয়ান আপলোড।',
      descEn: 'Organized into 4 sections: General Info (Mouza, JL, Khatian), dynamic multi-owner support, dynamic multi-plot support, and deed/khatian upload.'
    },
    {
      icon: <WalletCards className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      titleBn: 'দায় সমূহ (ঋণ ও দেনা ব্যবস্থাপনা)',
      titleEn: 'Liabilities & Debt Management',
      descBn: 'ব্যাংক লোন বা ব্যক্তিগত ঋণের পরিমাণ, কারণ, গ্রহণের তারিখ, পরিশোধের সম্ভাব্য তারিখ এবং বর্তমান স্থিতি (চলমান / পরিশোধিত) হিসাব রাখার সুনির্দিষ্ট ব্যবস্থা।',
      descEn: 'Track loan amounts in BDT, creditor institutions, dates, estimated repayment dates, and payment status (Active / Paid).'
    },
    {
      icon: <Briefcase className="w-5 h-5 text-purple-600 dark:text-purple-400" />,
      titleBn: 'চাকুরীর ইতিহাস (ক্যারিয়ার টাইমলাইন)',
      titleEn: 'Employment History',
      descBn: 'প্রতিষ্ঠান, পদবী, যোগদানের তারিখ এবং বিশেষ "চলমান" চেকবক্স (চেক করলে অব্যাহতির তারিখ ঘরটি স্বয়ংক্রিয়ভাবে ডিসেবল বা নিষ্ক্রিয় হয়ে যাবে)। নিয়োগ ও যোগদান পত্র সংরক্ষণ করুন।',
      descEn: 'Log career history with company, designation, joining date, and the "Currently Working" checkbox (auto-disables release date). Attach letters.'
    },
    {
      icon: <FileSpreadsheet className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
      titleBn: 'রিপোর্ট ও জীবনবৃত্তান্ত প্রিন্ট',
      titleEn: 'Comprehensive Reports & Print',
      descBn: 'বায়োডাটা, সম্পদ ও দায় ব্যালান্স শিট এবং কর্মজীবনের পূর্ণাঙ্গ প্রতিবেদন এক ক্লিকে দেখা এবং প্রফেশনাল ফরমেটে প্রিন্ট বা পিডিএফ সংরক্ষণের সুবিধা।',
      descEn: 'Generate consolidated biodata, asset-liability balance sheets, and career reports ready for clean A4 printing.'
    },
    {
      icon: <Database className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
      titleBn: 'ক্লাউড সিঙ্ক ও ডাটা সেন্টার',
      titleEn: 'Cloud Sync & Data Center',
      descBn: 'আপনার সকল তথ্য ব্রাউজারে সুরক্ষিত থাকে। যে কোনো সময় "ব্যাকআপ ডাউনলোড" করে JSON ফাইল সেভ করে রাখতে পারেন এবং প্রয়োজনে "ডাটা রিস্টোর" করতে পারবেন।',
      descEn: 'All records are safely stored locally. Download JSON backup anytime and restore data with one click.'
    },
    {
      icon: <Sparkles className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />,
      titleBn: 'এআই সহকারী (Smart AI Chat)',
      titleEn: 'AI Assistant',
      descBn: 'যেকোনো সময় এআই সহকারীকে জিজ্ঞেস করে আপনার তথ্যের সারাংশ জানতে পারেন, কোনো তথ্য কোথায় যুক্ত করবেন বা তাৎক্ষণিক সাহায্য পাবেন।',
      descEn: 'Instant AI answers about your total assets, liabilities, family summary, and interactive system guidance.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
        {/* Header */}
        <div className="bg-slate-900 dark:bg-slate-950 px-6 py-4 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                {language === 'bn' ? 'ব্যবহার নির্দেশিকা' : 'System User Guide'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'bn' ? 'রোবিউল IMS ব্যবহারের নিয়ম ও প্রয়োজনীয় দিকনির্দেশনা' : 'Instructions & Features Overview'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="font-bold">
                {language === 'bn' ? 'দ্রুত জেনে রাখুন:' : 'Quick Note:'}
              </strong>{' '}
              {language === 'bn'
                ? 'সিস্টেমের যেকোনো মডিউলে তথ্য যোগ, সম্পাদন বা মুছে ফেলার পর সাথে সাথে সবুজ/অ্যাম্বার পপআপ সতর্কতা প্রদর্শিত হবে। আপনার ডেটা ব্রাউজারের সুরক্ষিত ডাটাবেজে স্বয়ংক্রিয়ভাবে সিঙ্ক থাকবে।'
                : 'Whenever you add, edit, or delete any record, real-time toast popups will confirm the action. All records are automatically synced and persisted.'}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sections.map((sec, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800/70 transition-colors space-y-2"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-900 shadow-xs border border-slate-100 dark:border-slate-700/60">
                    {sec.icon}
                  </div>
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">
                    {language === 'bn' ? sec.titleBn : sec.titleEn}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {language === 'bn' ? sec.descBn : sec.descEn}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-950/60 px-6 py-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-md shadow-emerald-600/20"
          >
            {language === 'bn' ? 'বুঝেছি, ধন্যবাদ' : 'Got it, thanks!'}
          </button>
        </div>
      </div>
    </div>
  );
};
