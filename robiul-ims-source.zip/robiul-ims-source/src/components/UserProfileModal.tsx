import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import { X, User, Mail, Phone, MapPin, Calendar, Shield, Save, Edit3, Camera } from 'lucide-react';
import { UserProfile } from '../types';
import { FileUploadInput } from './common/FileUploadInput';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, updateUserProfile } = useData();
  const { language } = useLanguage();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserProfile>(userProfile);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(formData);
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-emerald-950 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                {language === 'bn' ? 'ব্যবহারকারীর তথ্য ও প্রোফাইল' : 'User Profile Details'}
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn' ? 'মূল অ্যাকাউন্ট ব্যবহারকারীর ব্যক্তিগত তথ্য' : 'Primary Account Master Information'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Avatar and Top Info */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div className="relative group">
              <img
                src={formData.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                alt={formData.nameBn}
                className="w-24 h-24 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
              />
              {isEditing && (
                <div 
                  onClick={() => {
                    const input = document.getElementById('user-avatar-upload') as HTMLInputElement;
                    input?.click();
                  }}
                  className="absolute inset-0 bg-black/50 hover:bg-black/60 rounded-2xl flex flex-col items-center justify-center text-white text-[10px] font-medium cursor-pointer transition-colors"
                >
                  <Camera className="w-5 h-5 mb-0.5" />
                  <span>{language === 'bn' ? 'ছবি বদলান' : 'Change'}</span>
                </div>
              )}
              <input
                id="user-avatar-upload"
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = (ev) => {
                    const res = ev.target?.result as string;
                    if (res) setFormData(prev => ({ ...prev, avatarUrl: res }));
                  };
                  reader.readAsDataURL(file);
                }}
                className="hidden"
              />
            </div>

            <div className="flex-1 text-center sm:text-left space-y-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-xl font-bold text-slate-900 dark:text-white">{formData.nameBn}</h4>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{formData.nameEn}</p>
                </div>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold transition-colors cursor-pointer self-center sm:self-auto"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    {language === 'bn' ? 'তথ্য সম্পাদন করুন' : 'Edit Information'}
                  </button>
                ) : (
                  <span className="text-xs bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 px-2 py-1 rounded font-medium">
                    {language === 'bn' ? 'সম্পাদন মোড সক্রিয়' : 'Edit Mode Active'}
                  </span>
                )}
              </div>
              <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/60 inline-block px-2.5 py-0.5 rounded-md mt-1">
                {formData.designation}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 pt-1 leading-relaxed">{formData.bio}</p>
            </div>
          </div>

          {/* Form / Details View */}
          {!isEditing ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/60 space-y-2">
                <span className="text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'ইমেইল ঠিকানা' : 'Email Address'}
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">{formData.email}</p>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/60 space-y-2">
                <span className="text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'মোবাইল নম্বর' : 'Phone Number'}
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">{formData.phone}</p>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/60 space-y-2">
                <span className="text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'জাতীয় পরিচয় পত্র (NID)' : 'National ID'}
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200 font-mono">{formData.nid}</p>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/60 space-y-2">
                <span className="text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'জন্ম তারিখ ও রক্তের গ্রুপ' : 'Date of Birth & Blood Group'}
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.dob} (গ্রুপ: <span className="text-rose-600 dark:text-rose-400 font-bold">{formData.bloodGroup}</span>)
                </p>
              </div>

              <div className="md:col-span-2 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/60 space-y-2">
                <span className="text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'স্থায়ী / বর্তমান ঠিকানা' : 'Address'}
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200 leading-relaxed">
                  গ্রাম: {formData.address.village}, ডাকঘর: {formData.address.postOffice} ({formData.address.postalCode}), উপজেলা: {formData.address.upazila}, জেলা: {formData.address.district}
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <FileUploadInput
                label={language === 'bn' ? 'প্রোফাইল ছবি আপলোড / পরিবর্তন করুন' : 'Upload / Change Profile Picture'}
                value={formData.avatarUrl || ''}
                onChange={(val) => setFormData({ ...formData, avatarUrl: val })}
                accept="image/*"
                isImage={true}
                placeholder="https://..."
                helperText={language === 'bn' ? 'আপনার কম্পিউটার বা মোবাইল থেকে ছবি আপলোড করুন' : 'Upload photo from device or provide web image URL'}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'নাম (বাংলায়)' : 'Name (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={formData.nameBn}
                    onChange={e => setFormData({ ...formData, nameBn: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'নাম (ইংরেজিতে)' : 'Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={formData.nameEn}
                    onChange={e => setFormData({ ...formData, nameEn: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'ইমেইল' : 'Email'}
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'মোবাইল নম্বর' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'পদবী / পেশা' : 'Designation'}
                  </label>
                  <input
                    type="text"
                    value={formData.designation}
                    onChange={e => setFormData({ ...formData, designation: e.target.value })}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'জাতীয় পরিচয় পত্র নম্বর (NID)' : 'NID No'}
                  </label>
                  <input
                    type="text"
                    value={formData.nid}
                    onChange={e => setFormData({ ...formData, nid: e.target.value })}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'রক্তের গ্রুপ' : 'Blood Group'}
                  </label>
                  <input
                    type="text"
                    value={formData.bloodGroup}
                    onChange={e => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder="B+"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'সংক্ষিপ্ত জীবনবৃত্তান্ত / পরিচিতি' : 'Bio'}
                </label>
                <textarea
                  rows={2}
                  value={formData.bio}
                  onChange={e => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Address Section */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <p className="font-semibold text-slate-700 dark:text-slate-200">
                  {language === 'bn' ? 'বর্তমান ঠিকানা বিবরণ' : 'Address Details'}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={formData.address.village}
                    onChange={e => setFormData({ ...formData, address: { ...formData.address, village: e.target.value } })}
                    placeholder="গ্রাম"
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-lg"
                  />
                  <input
                    type="text"
                    value={formData.address.postOffice}
                    onChange={e => setFormData({ ...formData, address: { ...formData.address, postOffice: e.target.value } })}
                    placeholder="ডাকঘর"
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-lg"
                  />
                  <input
                    type="text"
                    value={formData.address.postalCode}
                    onChange={e => setFormData({ ...formData, address: { ...formData.address, postalCode: e.target.value } })}
                    placeholder="পোস্ট কোড"
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-lg"
                  />
                  <input
                    type="text"
                    value={formData.address.upazila}
                    onChange={e => setFormData({ ...formData, address: { ...formData.address, upazila: e.target.value } })}
                    placeholder="উপজেলা"
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-lg"
                  />
                  <input
                    type="text"
                    value={formData.address.district}
                    onChange={e => setFormData({ ...formData, address: { ...formData.address, district: e.target.value } })}
                    placeholder="জেলা"
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-lg"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg font-medium"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium flex items-center gap-1.5 shadow-md shadow-emerald-600/20"
                >
                  <Save className="w-4 h-4" />
                  {language === 'bn' ? 'তথ্য সংরক্ষণ করুন' : 'Save Details'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-950/60 px-6 py-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
