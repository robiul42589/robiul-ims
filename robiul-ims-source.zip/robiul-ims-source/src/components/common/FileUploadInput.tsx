import React, { useRef, useState } from 'react';
import { Upload, X, Image as ImageIcon, FileText, CheckCircle2, Link as LinkIcon, Eye } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface FileUploadInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  accept?: string;
  placeholder?: string;
  isImage?: boolean;
  required?: boolean;
  helperText?: string;
}

export const FileUploadInput: React.FC<FileUploadInputProps> = ({
  label,
  value,
  onChange,
  accept = 'image/*,application/pdf',
  placeholder,
  isImage = true,
  required = false,
  helperText
}) => {
  const { language } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [fileName, setFileName] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        onChange(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleClear = () => {
    onChange('');
    setFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const isDataUrl = value && value.startsWith('data:');
  const isImageFile = isImage || (value && (value.startsWith('data:image') || /\.(jpg|jpeg|png|webp|gif|svg)$/i.test(value)));

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="block font-semibold text-slate-700 dark:text-slate-300 text-xs">
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
        >
          <LinkIcon className="w-3 h-3" />
          <span>{showUrlInput ? (language === 'bn' ? 'ফাইল আপলোড মোড' : 'Upload file mode') : (language === 'bn' ? 'অনলাইন লিঙ্ক দিন' : 'Enter URL')}</span>
        </button>
      </div>

      {helperText && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400">{helperText}</p>
      )}

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        accept={accept}
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Mode 1: URL Input Mode */}
      {showUrlInput ? (
        <div className="flex gap-2">
          <input
            type="url"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder || (language === 'bn' ? 'https://... ফাইল বা ছবির লিঙ্ক' : 'https://... URL link')}
            className="flex-1 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-xs focus:ring-2 focus:ring-emerald-500"
          />
          {value && (
            <button
              type="button"
              onClick={handleClear}
              className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg border border-rose-200 dark:border-rose-900 cursor-pointer"
              title={language === 'bn' ? 'মুছে ফেলুন' : 'Clear'}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      ) : (
        /* Mode 2: File Upload / Preview Area */
        <div>
          {value ? (
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {isImageFile ? (
                  <img
                    src={value}
                    alt="Preview"
                    className="w-12 h-12 rounded-lg object-cover border border-emerald-500 shrink-0 bg-white"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0 border border-emerald-300 dark:border-emerald-700">
                    <FileText className="w-6 h-6" />
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {fileName || (isDataUrl ? (language === 'bn' ? 'সংযুক্ত ফাইল (আপলোডকৃত)' : 'Uploaded File') : value)}
                  </p>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-semibold mt-0.5">
                    <CheckCircle2 className="w-3 h-3" />
                    {language === 'bn' ? 'ফাইল সফলভাবে সংযুক্ত' : 'File attached'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer"
                >
                  {language === 'bn' ? 'পরিবর্তন' : 'Change'}
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                  title={language === 'bn' ? 'মুছে ফেলুন' : 'Remove'}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="group p-4 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 bg-white dark:bg-slate-800/50 hover:bg-emerald-50/30 dark:hover:bg-slate-800 transition-all cursor-pointer text-center"
            >
              <div className="flex flex-col items-center justify-center space-y-1.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {language === 'bn' ? 'ডিভাইস থেকে ফাইল বা ছবি আপলোড করুন' : 'Click to upload file or photo'}
                  </p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                    {language === 'bn' 
                      ? 'JPG, PNG, WebP বা PDF ফাইল নির্বাচন করুন' 
                      : 'Supports JPG, PNG, WebP or PDF'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
