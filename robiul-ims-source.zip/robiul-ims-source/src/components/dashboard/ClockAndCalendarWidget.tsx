import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { 
  Clock, 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Sun, 
  Moon, 
  Sunrise, 
  Sunset, 
  Gift, 
  AlertCircle, 
  CalendarDays,
  Sparkles,
  RotateCcw
} from 'lucide-react';

const toBengaliDigits = (num: number | string): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return num.toString().replace(/\d/g, d => bnDigits[parseInt(d, 10)]);
};

export const ClockAndCalendarWidget: React.FC = () => {
  const { language } = useLanguage();
  const { familyMembers, liabilities } = useData();

  // Clock State
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [is24Hour, setIs24Hour] = useState<boolean>(false);

  // Calendar State
  const [calendarDate, setCalendarDate] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Time format calculations
  const hours24 = currentTime.getHours();
  const minutes = currentTime.getMinutes();
  const seconds = currentTime.getSeconds();
  
  let hours = hours24;
  let ampmEn = hours24 >= 12 ? 'PM' : 'AM';
  let ampmBn = hours24 >= 12 ? 'অপরাহ্ন' : 'পূর্বাহ্ন';
  
  if (!is24Hour) {
    hours = hours % 12;
    hours = hours ? hours : 12;
  }

  const padZero = (n: number) => (n < 10 ? `0${n}` : `${n}`);

  const formattedHours = is24Hour ? padZero(hours24) : padZero(hours);
  const formattedMinutes = padZero(minutes);
  const formattedSeconds = padZero(seconds);

  // Time of day greeting and icon
  const getTimePhase = (h: number) => {
    if (h >= 4 && h < 6) {
      return { 
        nameBn: 'ভোর', 
        nameEn: 'Dawn', 
        icon: <Sunrise className="w-4 h-4 text-amber-400" />,
        bgGlow: 'from-amber-500/10 to-orange-500/5'
      };
    } else if (h >= 6 && h < 12) {
      return { 
        nameBn: 'সকাল', 
        nameEn: 'Morning', 
        icon: <Sun className="w-4 h-4 text-amber-500" />,
        bgGlow: 'from-amber-500/10 to-yellow-500/5'
      };
    } else if (h >= 12 && h < 15) {
      return { 
        nameBn: 'দুপুর', 
        nameEn: 'Noon', 
        icon: <Sun className="w-4 h-4 text-orange-500" />,
        bgGlow: 'from-orange-500/10 to-emerald-500/5'
      };
    } else if (h >= 15 && h < 18) {
      return { 
        nameBn: 'বিকাল', 
        nameEn: 'Afternoon', 
        icon: <Sunset className="w-4 h-4 text-rose-400" />,
        bgGlow: 'from-rose-500/10 to-purple-500/5'
      };
    } else if (h >= 18 && h < 20) {
      return { 
        nameBn: 'সন্ধ্যা', 
        nameEn: 'Dusk', 
        icon: <Sunset className="w-4 h-4 text-purple-400" />,
        bgGlow: 'from-purple-500/10 to-indigo-500/5'
      };
    } else {
      return { 
        nameBn: 'রাত', 
        nameEn: 'Night', 
        icon: <Moon className="w-4 h-4 text-indigo-400" />,
        bgGlow: 'from-indigo-500/10 to-slate-500/5'
      };
    }
  };

  const currentPhase = getTimePhase(hours24);

  // Calendar calculations
  const currentYear = calendarDate.getFullYear();
  const currentMonth = calendarDate.getMonth(); // 0 - 11

  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekdayNamesBn = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র'];
  const weekdayNamesEn = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

  // Days in month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  
  // Starting day of month (Saturday = 0, ..., Friday = 6 in our custom order)
  // Standard JS: 0=Sun, 1=Mon, ..., 6=Sat
  // To convert to Sat=0, Sun=1, Mon=2, Tue=3, Wed=4, Thu=5, Fri=6:
  const firstDayStandard = new Date(currentYear, currentMonth, 1).getDay();
  const firstDayIndex = (firstDayStandard + 1) % 7;

  // Previous month days to pad
  const prevMonthDaysCount = new Date(currentYear, currentMonth, 0).getDate();

  // Navigation handlers
  const handlePrevMonth = () => {
    setCalendarDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const handleNextMonth = () => {
    setCalendarDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const handleTodayJump = () => {
    const now = new Date();
    setCalendarDate(now);
    setSelectedDate(now);
  };

  // Find events on dates (Birthdays and Liabilities)
  const getEventsForDate = (year: number, month: number, day: number) => {
    const formattedDay = day < 10 ? `0${day}` : `${day}`;
    const formattedMonth = month + 1 < 10 ? `0${month + 1}` : `${month + 1}`;
    const dateStr = `${year}-${formattedMonth}-${formattedDay}`;
    const monthDayStr = `${formattedMonth}-${formattedDay}`;

    // Birthdays from family
    const birthdays = familyMembers.filter(m => {
      if (!m.dob) return false;
      return m.dob.endsWith(monthDayStr);
    });

    // Liabilities due on this date
    const dues = liabilities.filter(l => {
      if (!l.expectedRepaymentDate || l.status === 'পরিশোধিত') return false;
      return l.expectedRepaymentDate === dateStr;
    });

    return { birthdays, dues };
  };

  // Check if a day is today
  const today = new Date();
  const isToday = (day: number) => {
    return (
      today.getFullYear() === currentYear &&
      today.getMonth() === currentMonth &&
      today.getDate() === day
    );
  };

  // Check if a day is selected
  const isSelected = (day: number) => {
    return (
      selectedDate.getFullYear() === currentYear &&
      selectedDate.getMonth() === currentMonth &&
      selectedDate.getDate() === day
    );
  };

  // Events on the currently selected date
  const selectedDateEvents = getEventsForDate(
    selectedDate.getFullYear(),
    selectedDate.getMonth(),
    selectedDate.getDate()
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* 1. Digital Clock Widget (5 columns on large screens) */}
      <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between relative overflow-hidden">
        {/* Subtle background glow depending on phase */}
        <div className={`absolute top-0 right-0 w-56 h-56 bg-gradient-to-br ${currentPhase.bgGlow} rounded-full blur-3xl pointer-events-none`}></div>

        <div>
          {/* Header row */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 relative z-10">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {language === 'bn' ? 'ডিজিটাল ঘড়ি' : 'Digital Clock'}
                </h3>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">
                  {language === 'bn' ? 'বাংলাদেশ মান সময় (BST)' : 'Bangladesh Standard Time'}
                </span>
              </div>
            </div>

            {/* 12h / 24h Toggle */}
            <button
              onClick={() => setIs24Hour(!is24Hour)}
              className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
              title={language === 'bn' ? 'ঘড়ির ফরম্যাট পরিবর্তন করুন' : 'Toggle 12h/24h'}
            >
              {is24Hour ? '24H' : '12H'}
            </button>
          </div>

          {/* Big Clock Display */}
          <div className="my-5 p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 text-white border border-slate-800 shadow-lg relative overflow-hidden">
            {/* Ambient emerald edge line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600"></div>

            <div className="flex flex-col items-center justify-center text-center">
              {/* Time digits */}
              <div className="flex items-baseline justify-center gap-1.5 sm:gap-2 font-mono tabular-nums text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white">
                <span className="p-1 sm:p-1.5 rounded-lg bg-slate-800/80 border border-slate-700/60 shadow-inner">
                  {language === 'bn' ? toBengaliDigits(formattedHours) : formattedHours}
                </span>
                <span className="text-emerald-400 animate-pulse font-normal">:</span>
                <span className="p-1 sm:p-1.5 rounded-lg bg-slate-800/80 border border-slate-700/60 shadow-inner">
                  {language === 'bn' ? toBengaliDigits(formattedMinutes) : formattedMinutes}
                </span>
                <span className="text-emerald-400 animate-pulse font-normal">:</span>
                <span className="p-1 sm:p-1.5 rounded-lg bg-slate-800/80 border border-slate-700/60 shadow-inner text-emerald-400">
                  {language === 'bn' ? toBengaliDigits(formattedSeconds) : formattedSeconds}
                </span>

                {!is24Hour && (
                  <span className="text-xs sm:text-sm font-sans font-bold text-emerald-300 ml-1 self-end pb-1.5 uppercase">
                    {language === 'bn' ? ampmBn : ampmEn}
                  </span>
                )}
              </div>

              {/* Day Phase & Greeting */}
              <div className="mt-3.5 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-slate-200 text-xs font-medium border border-white/15">
                {currentPhase.icon}
                <span>
                  {language === 'bn' 
                    ? `বর্তমান প্রহর: ${currentPhase.nameBn}` 
                    : `Time phase: ${currentPhase.nameEn}`}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Live Date Strip in Clock card */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300 font-medium">
            <CalendarIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              {language === 'bn'
                ? currentTime.toLocaleDateString('bn-BD', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })
                : currentTime.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
            </span>
          </div>

          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 font-bold shrink-0">
            {language === 'bn' ? 'সরাসরি লাইভ' : 'Live'}
          </span>
        </div>
      </div>

      {/* 2. Interactive Monthly Calendar Widget (7 columns on large screens) */}
      <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
        <div>
          {/* Calendar Header with Navigation */}
          <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
                <CalendarDays className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <span>
                    {language === 'bn' 
                      ? `${monthNamesBn[currentMonth]} ${toBengaliDigits(currentYear)}` 
                      : `${monthNamesEn[currentMonth]} ${currentYear}`}
                  </span>
                </h3>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">
                  {language === 'bn' ? 'তারিখে ক্লিক করে বিস্তারিত তথ্য দেখুন' : 'Click a date to see reminders'}
                </span>
              </div>
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleTodayJump}
                className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/80 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors cursor-pointer"
                title={language === 'bn' ? 'আজকের তারিখে ফিরে যান' : 'Go to Today'}
              >
                {language === 'bn' ? 'আজ' : 'Today'}
              </button>

              <button
                onClick={handlePrevMonth}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                aria-label="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button
                onClick={handleNextMonth}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                aria-label="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday Row */}
          <div className="grid grid-cols-7 gap-1 mt-3 mb-1.5 text-center">
            {(language === 'bn' ? weekdayNamesBn : weekdayNamesEn).map((dayName, idx) => {
              const isFriday = idx === 6; // Friday is last day in Sat-Fri
              return (
                <div
                  key={idx}
                  className={`py-1 text-[11px] font-bold ${
                    isFriday 
                      ? 'text-rose-600 dark:text-rose-400' 
                      : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {dayName}
                </div>
              );
            })}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs">
            {/* Previous month padding days */}
            {Array.from({ length: firstDayIndex }).map((_, idx) => {
              const prevDay = prevMonthDaysCount - firstDayIndex + idx + 1;
              return (
                <div
                  key={`prev-${idx}`}
                  className="py-2 rounded-xl text-slate-300 dark:text-slate-600 cursor-not-allowed select-none text-[11px]"
                >
                  {language === 'bn' ? toBengaliDigits(prevDay) : prevDay}
                </div>
              );
            })}

            {/* Current month days */}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const day = idx + 1;
              const todayFlag = isToday(day);
              const selectedFlag = isSelected(day);
              const dayEvents = getEventsForDate(currentYear, currentMonth, day);
              const hasBirthdays = dayEvents.birthdays.length > 0;
              const hasDues = dayEvents.dues.length > 0;
              const hasEvents = hasBirthdays || hasDues;

              // Check if Friday (weekly holiday)
              const dayOfWeek = (firstDayIndex + idx) % 7;
              const isFriday = dayOfWeek === 6;

              return (
                <button
                  key={`day-${day}`}
                  onClick={() => setSelectedDate(new Date(currentYear, currentMonth, day))}
                  className={`relative py-1.5 px-1 rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
                    selectedFlag
                      ? 'bg-slate-900 dark:bg-emerald-600 text-white font-bold shadow-md ring-2 ring-emerald-500'
                      : todayFlag
                      ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-200 font-bold border border-emerald-300 dark:border-emerald-700'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                  } ${isFriday && !selectedFlag && !todayFlag ? 'text-rose-600 dark:text-rose-400 font-semibold' : ''}`}
                >
                  <span className="text-[12px] tabular-nums leading-none">
                    {language === 'bn' ? toBengaliDigits(day) : day}
                  </span>

                  {/* Indicator Dots for Events */}
                  <div className="flex items-center gap-1 mt-1 h-1.5">
                    {hasBirthdays && (
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-pink-500"
                        title={language === 'bn' ? 'সদস্যের জন্মদিন' : 'Birthday'}
                      />
                    )}
                    {hasDues && (
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-amber-500"
                        title={language === 'bn' ? 'দায়ের কিস্তি পরিশোধ' : 'Debt repayment due'}
                      />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Date Context Footer */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-300">
              <span className="font-bold text-slate-900 dark:text-white">
                {language === 'bn' ? 'নির্বাচিত তারিখ:' : 'Selected Date:'}
              </span>
              <span>
                {language === 'bn'
                  ? selectedDate.toLocaleDateString('bn-BD', {
                      weekday: 'short',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })
                  : selectedDate.toLocaleDateString('en-US', {
                      weekday: 'short',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
              </span>
            </div>

            {/* Quick legend */}
            <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                {language === 'bn' ? 'জন্মদিন' : 'Birthday'}
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                {language === 'bn' ? 'লোন কিস্তি' : 'Loan Due'}
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                {language === 'bn' ? 'আজ' : 'Today'}
              </span>
            </div>
          </div>

          {/* Notice if events exist on selected date */}
          {(selectedDateEvents.birthdays.length > 0 || selectedDateEvents.dues.length > 0) && (
            <div className="mt-2.5 p-2.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 text-xs text-emerald-950 dark:text-emerald-200 space-y-1">
              {selectedDateEvents.birthdays.map((b) => (
                <div key={b.id} className="flex items-center gap-1.5 font-medium">
                  <Gift className="w-3.5 h-3.5 text-pink-600 dark:text-pink-400 shrink-0" />
                  <span>
                    {language === 'bn'
                      ? `আজ পরিবারের সদস্য "${b.nameBn}" এর শুভ জন্মদিন!`
                      : `Birthday of family member "${b.nameEn}" today!`}
                  </span>
                </div>
              ))}
              {selectedDateEvents.dues.map((d) => (
                <div key={d.id} className="flex items-center gap-1.5 font-medium text-amber-800 dark:text-amber-300">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>
                    {language === 'bn'
                      ? `দায় পরিশোধের সম্ভাব্য তারিখ: "${d.liabilityReason}" (৳ ${d.loanAmountBDT.toLocaleString('bn-BD')})`
                      : `Repayment Due: "${d.liabilityReason}" (BDT ${d.loanAmountBDT.toLocaleString()})`}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
