import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Landmark, 
  PlusCircle, 
  Eye, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  MapPin, 
  Users, 
  FileText, 
  Layers, 
  Plus, 
  ExternalLink 
} from 'lucide-react';
import { AssetItem, LandPlot } from '../../types';
import { FileUploadInput } from '../common/FileUploadInput';

export const AssetsView: React.FC = () => {
  const { assets, addAsset, updateAsset, deleteAsset, globalSearchQuery } = useData();
  const { language, t } = useLanguage();

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<AssetItem | null>(null);
  const [viewingAsset, setViewingAsset] = useState<AssetItem | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<AssetItem | null>(null);

  // Form State structured into the 4 sections
  const initialFormState: Omit<AssetItem, 'id' | 'createdAt'> = {
    district: '',
    upazila: '',
    landOffice: '',
    mouza: '',
    jlNo: '',
    holdingNo: '',
    khatianNo: '',
    owners: [
      { id: 'own_' + Date.now() + '_1', name: 'মোঃ রোবিউল ইসলাম', share: '১৬ আনা (১০০%)' }
    ],
    plots: [
      { id: 'plt_' + Date.now() + '_1', dagPlotNo: '', landCategory: 'নাল (কৃষি)', landArea: '', unit: 'শতক' }
    ],
    deedDocumentUrl: '',
    deedDocumentName: '',
    khatianDocumentUrl: '',
    khatianDocumentName: '',
    estimatedValueBDT: 0,
    remarks: ''
  };

  const [formData, setFormData] = useState<Omit<AssetItem, 'id' | 'createdAt'>>(initialFormState);

  // Dynamic Owners: আরো মালিক যুক্ত করুন
  const handleAddOwner = () => {
    setFormData(prev => ({
      ...prev,
      owners: [
        ...prev.owners,
        { id: 'own_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5), name: '', share: '' }
      ]
    }));
  };

  const handleRemoveOwner = (id: string) => {
    if (formData.owners.length === 1) return;
    setFormData(prev => ({
      ...prev,
      owners: prev.owners.filter(o => o.id !== id)
    }));
  };

  const handleOwnerChange = (id: string, field: 'name' | 'share', value: string) => {
    setFormData(prev => ({
      ...prev,
      owners: prev.owners.map(o => o.id === id ? { ...o, [field]: value } : o)
    }));
  };

  // Dynamic Plots: আরো দাগ/প্লট যুক্ত করুন
  const handleAddPlot = () => {
    setFormData(prev => ({
      ...prev,
      plots: [
        ...prev.plots,
        { id: 'plt_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5), dagPlotNo: '', landCategory: 'নাল', landArea: '', unit: 'শতক' }
      ]
    }));
  };

  const handleRemovePlot = (id: string) => {
    if (formData.plots.length === 1) return;
    setFormData(prev => ({
      ...prev,
      plots: prev.plots.filter(p => p.id !== id)
    }));
  };

  const handlePlotChange = (id: string, field: keyof LandPlot, value: string) => {
    setFormData(prev => ({
      ...prev,
      plots: prev.plots.map(p => p.id === id ? { ...p, [field]: value } : p)
    }));
  };

  const handleOpenAdd = () => {
    setFormData(initialFormState);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (item: AssetItem) => {
    setEditingAsset(item);
    setFormData({
      district: item.district,
      upazila: item.upazila,
      landOffice: item.landOffice,
      mouza: item.mouza,
      jlNo: item.jlNo,
      holdingNo: item.holdingNo,
      khatianNo: item.khatianNo,
      owners: item.owners && item.owners.length > 0 ? item.owners : initialFormState.owners,
      plots: item.plots && item.plots.length > 0 ? item.plots : initialFormState.plots,
      deedDocumentUrl: item.deedDocumentUrl || '',
      deedDocumentName: item.deedDocumentName || '',
      khatianDocumentUrl: item.khatianDocumentUrl || '',
      khatianDocumentName: item.khatianDocumentName || '',
      estimatedValueBDT: item.estimatedValueBDT || 0,
      remarks: item.remarks || ''
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAsset) {
      updateAsset(editingAsset.id, formData);
      setEditingAsset(null);
    } else {
      addAsset(formData);
      setIsAddModalOpen(false);
    }
  };

  const filteredAssets = assets.filter(a => {
    if (!globalSearchQuery) return true;
    const q = globalSearchQuery.toLowerCase();
    return (
      a.mouza.toLowerCase().includes(q) ||
      a.khatianNo.toLowerCase().includes(q) ||
      a.jlNo.includes(q) ||
      a.holdingNo.includes(q) ||
      a.district.toLowerCase().includes(q) ||
      a.upazila.toLowerCase().includes(q) ||
      a.owners?.some(o => o.name.toLowerCase().includes(q)) ||
      a.plots?.some(p => p.dagPlotNo.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header & Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-100 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300">
            <Landmark className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {language === 'bn' ? 'সম্পদ বিবরণী' : 'Asset & Land Statement'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'bn'
                ? 'ভূমি, খতিয়ান, দাগ নম্বর, যৌথ মালিকানা ও দলিলের সুনির্দিষ্ট ডিজিটাল রেকর্ড'
                : 'Manage land deeds, khatian, plot numbers, co-owners and valuation'}
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-teal-600/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{language === 'bn' ? 'সম্পদের তথ্য যুক্ত করুন' : 'Add Asset Info'}</span>
        </button>
      </div>

      {/* Summary Cards of Assets */}
      {filteredAssets.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
            <Landmark className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-700 dark:text-slate-300">
            {language === 'bn' ? 'কোন সম্পদের তথ্য পাওয়া যায়নি' : 'No asset records found'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {language === 'bn'
              ? 'উপরের "সম্পদের তথ্য যুক্ত করুন" বাটনে ক্লিক করে জমির খতিয়ান ও দাগ বিবরণী যুক্ত করুন।'
              : 'Click the button above to register land and property assets.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredAssets.map((asset) => {
            const totalPlots = asset.plots?.length || 0;
            const totalAreaDecimals = asset.plots?.reduce((sum, p) => sum + (parseFloat(p.landArea) || 0), 0) || 0;

            return (
              <div
                key={asset.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-teal-300 dark:hover:border-teal-600 hover:shadow-md transition-all p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                {/* Left side details */}
                <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                  <div className="p-3.5 rounded-2xl bg-teal-100 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 shrink-0 border border-teal-200 dark:border-teal-800">
                    <Landmark className="w-6 h-6" />
                  </div>

                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 font-bold border border-teal-200 dark:border-teal-800">
                        {language === 'bn' ? 'খতিয়ান নং:' : 'Khatian:'} {asset.khatianNo}
                      </span>
                      <h3 className="font-bold text-base text-slate-900 dark:text-white truncate">
                        {language === 'bn' ? 'মৌজা:' : 'Mouza:'} {asset.mouza} (জেএল নং {asset.jlNo})
                      </h3>
                      {asset.estimatedValueBDT ? (
                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800">
                          ৳ {asset.estimatedValueBDT.toLocaleString('bn-BD')}
                        </span>
                      ) : null}
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{asset.landOffice}, {asset.upazila}, {asset.district}</span>
                    </p>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300 pt-1">
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                        <strong>{language === 'bn' ? 'মালিক:' : 'Owners:'}</strong>
                        <span className="text-slate-700 dark:text-slate-200">
                          {asset.owners?.map((o) => `${o.name} (${o.share})`).join(', ') || 'নেই'}
                        </span>
                      </span>

                      <span className="flex items-center gap-1">
                        <Layers className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                        <strong>{language === 'bn' ? 'দাগ ও পরিমাণ:' : 'Plots:'}</strong>
                        <span>
                          {totalPlots}টি দাগ, মোট {totalAreaDecimals.toFixed(1)} শতক
                        </span>
                      </span>

                      {(asset.deedDocumentUrl || asset.khatianDocumentUrl) && (
                        <span className="flex items-center gap-1 text-blue-600 dark:text-blue-400 font-medium">
                          <FileText className="w-3.5 h-3.5 shrink-0" />
                          <span>{language === 'bn' ? 'দলিল/খতিয়ান সংযুক্ত' : 'Doc Attached'}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right side: 3 Action buttons */}
                <div className="flex items-center justify-end gap-1.5 shrink-0 border-t lg:border-t-0 border-slate-100 dark:border-slate-800 pt-3 lg:pt-0">
                  <button
                    onClick={() => setViewingAsset(asset)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    <span>{t('show', 'দেখুন')}</span>
                  </button>

                  <button
                    onClick={() => handleOpenEdit(asset)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="তথ্য সংশোধন"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>{t('edit', 'তথ্য সংশোধন')}</span>
                  </button>

                  <button
                    onClick={() => setDeleteCandidate(asset)}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    <span>{t('delete', 'মুছে ফেলুন')}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Asset Modal structured exactly into the 4 requested sections */}
      {(isAddModalOpen || editingAsset) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-900 to-teal-950 px-6 py-4 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white">
                  {editingAsset
                    ? (language === 'bn' ? 'সম্পদের তথ্য সংশোধন করুন' : 'Edit Land Asset Record')
                    : (language === 'bn' ? 'নতুন সম্পদের তথ্য যুক্ত করুন' : 'Add New Land Asset Record')}
                </h3>
                <p className="text-xs text-teal-300">
                  {language === 'bn' ? 'সাধারণ তথ্য, মালিকানা, জমির দাগ ও সংযুক্তি পূরণ করুন' : 'General info, owners, land plots, and documents'}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingAsset(null);
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-xs text-slate-800 dark:text-slate-200">
              {/* সেকশন ১: সাধারণ তথ্য */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center gap-2 text-teal-800 dark:text-teal-300 font-bold text-sm border-b border-slate-200 dark:border-slate-700 pb-2">
                  <MapPin className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সেকশন ১: সাধারণ তথ্য' : 'Section 1: General Information'}</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">জেলা *</label>
                    <input
                      type="text"
                      required
                      value={formData.district}
                      onChange={e => setFormData({ ...formData, district: e.target.value })}
                      placeholder="যেমন: পাবনা"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">উপজেলা *</label>
                    <input
                      type="text"
                      required
                      value={formData.upazila}
                      onChange={e => setFormData({ ...formData, upazila: e.target.value })}
                      placeholder="যেমন: ঈশ্বরদী"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">ইউনিয়ন/পৌর. ভূমি অফিস *</label>
                    <input
                      type="text"
                      required
                      value={formData.landOffice}
                      onChange={e => setFormData({ ...formData, landOffice: e.target.value })}
                      placeholder="পাকশী ভূমি অফিস"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">মৌজা *</label>
                    <input
                      type="text"
                      required
                      value={formData.mouza}
                      onChange={e => setFormData({ ...formData, mouza: e.target.value })}
                      placeholder="মৌজার নাম"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">জেএল নং *</label>
                    <input
                      type="text"
                      required
                      value={formData.jlNo}
                      onChange={e => setFormData({ ...formData, jlNo: e.target.value })}
                      placeholder="যেমন: ৭২"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">হোল্ডিং নং *</label>
                    <input
                      type="text"
                      required
                      value={formData.holdingNo}
                      onChange={e => setFormData({ ...formData, holdingNo: e.target.value })}
                      placeholder="যেমন: ৫৪৮"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg font-mono"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">খতিয়ান নং *</label>
                    <input
                      type="text"
                      required
                      value={formData.khatianNo}
                      onChange={e => setFormData({ ...formData, khatianNo: e.target.value })}
                      placeholder="যেমন: বি.এস. ১২০৪"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg font-mono"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">আনুমানিক প্রাক্কলিত মূল্য (টাকায়)</label>
                    <input
                      type="number"
                      value={formData.estimatedValueBDT || ''}
                      onChange={e => setFormData({ ...formData, estimatedValueBDT: parseFloat(e.target.value) || 0 })}
                      placeholder="যেমন: ২৫০০০০০"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* সেকশন ২: মালিকের তথ্য */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                  <div className="flex items-center gap-2 text-teal-800 dark:text-teal-300 font-bold text-sm">
                    <Users className="w-4 h-4" />
                    <span>{language === 'bn' ? 'সেকশন ২: মালিকের তথ্য' : 'Section 2: Owner Details'}</span>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddOwner}
                    className="px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'আরো মালিক যুক্ত করুন' : 'Add More Owner'}</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {formData.owners.map((owner, idx) => (
                    <div key={owner.id} className="flex items-center gap-2 bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                      <span className="text-[11px] font-bold text-slate-400 w-6">#{idx + 1}</span>
                      <div className="flex-1">
                        <input
                          type="text"
                          required
                          value={owner.name}
                          onChange={e => handleOwnerChange(owner.id, 'name', e.target.value)}
                          placeholder={language === 'bn' ? 'মালিকের নাম' : 'Owner Name'}
                          className="w-full px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 text-slate-900 dark:text-white rounded-lg text-xs"
                        />
                      </div>
                      <div className="w-36">
                        <input
                          type="text"
                          required
                          value={owner.share}
                          onChange={e => handleOwnerChange(owner.id, 'share', e.target.value)}
                          placeholder={language === 'bn' ? 'অংশ (যেমন: ১৬ আনা বা ৫০%)' : 'Share (e.g. 50%)'}
                          className="w-full px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 text-slate-900 dark:text-white rounded-lg text-xs"
                        />
                      </div>
                      {formData.owners.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveOwner(owner.id)}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded-lg cursor-pointer"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* সেকশন ৩: জমির তথ্য */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                  <div className="flex items-center gap-2 text-teal-800 dark:text-teal-300 font-bold text-sm">
                    <Layers className="w-4 h-4" />
                    <span>{language === 'bn' ? 'সেকশন ৩: জমির তথ্য' : 'Section 3: Land Plots & Area'}</span>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddPlot}
                    className="px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'আরো দাগ/প্লট যুক্ত করুন' : 'Add More Plot'}</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {formData.plots.map((plot) => (
                    <div key={plot.id} className="grid grid-cols-12 gap-2 items-center bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div className="col-span-12 sm:col-span-4">
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">দাগ/প্লট নং *</label>
                        <input
                          type="text"
                          required
                          value={plot.dagPlotNo}
                          onChange={e => handlePlotChange(plot.id, 'dagPlotNo', e.target.value)}
                          placeholder="যেমন: দাগ নং ৩৫০২"
                          className="w-full px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 text-slate-900 dark:text-white rounded-lg text-xs font-mono"
                        />
                      </div>
                      <div className="col-span-12 sm:col-span-4">
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">জমির শ্রেণী *</label>
                        <input
                          type="text"
                          required
                          value={plot.landCategory}
                          onChange={e => handlePlotChange(plot.id, 'landCategory', e.target.value)}
                          placeholder="নাল, ধানী, ভিটি, পুকুর, বাড়ি"
                          className="w-full px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 text-slate-900 dark:text-white rounded-lg text-xs"
                        />
                      </div>
                      <div className="col-span-8 sm:col-span-3">
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">জমির পরিমাণ *</label>
                        <div className="flex gap-1">
                          <input
                            type="text"
                            required
                            value={plot.landArea}
                            onChange={e => handlePlotChange(plot.id, 'landArea', e.target.value)}
                            placeholder="যেমন: ১৪.৫"
                            className="w-full px-2 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 text-slate-900 dark:text-white rounded-lg text-xs"
                          />
                          <select
                            value={plot.unit}
                            onChange={e => handlePlotChange(plot.id, 'unit', e.target.value)}
                            className="px-2 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                          >
                            <option value="শতক">শতক</option>
                            <option value="একর">একর</option>
                            <option value="কাঠা">কাঠা</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-span-4 sm:col-span-1 text-right sm:text-center pt-3">
                        {formData.plots.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemovePlot(plot.id)}
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded-lg cursor-pointer"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* সেকশন ৪: সংযুক্তি */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center gap-2 text-teal-800 dark:text-teal-300 font-bold text-sm border-b border-slate-200 dark:border-slate-700 pb-2">
                  <FileText className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সেকশন ৪: সংযুক্তি (দলিল ও খতিয়ান)' : 'Section 4: Attachments'}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <FileUploadInput
                    label={language === 'bn' ? 'দলিল আপলোড / সংযুক্ত করুন' : 'Upload / Attach Deed Document'}
                    value={formData.deedDocumentUrl || ''}
                    onChange={(val) => setFormData({ ...formData, deedDocumentUrl: val })}
                    accept="image/*,application/pdf"
                    isImage={false}
                    placeholder="https://..."
                    helperText={language === 'bn' ? 'দলিলের স্ক্যান কপি বা ছবি আপলোড করুন' : 'Upload scanned deed document or photo'}
                  />
                  <FileUploadInput
                    label={language === 'bn' ? 'খতিয়ান আপলোড / সংযুক্ত করুন' : 'Upload / Attach Khatian Document'}
                    value={formData.khatianDocumentUrl || ''}
                    onChange={(val) => setFormData({ ...formData, khatianDocumentUrl: val })}
                    accept="image/*,application/pdf"
                    isImage={false}
                    placeholder="https://..."
                    helperText={language === 'bn' ? 'খতিয়ানের স্ক্যান কপি বা ছবি আপলোড করুন' : 'Upload scanned khatian document or photo'}
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">মন্তব্য ও পরিচিতি</label>
                  <textarea
                    rows={2}
                    value={formData.remarks}
                    onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                    placeholder="জমির অবস্থান বা বিশেষ বৈশিষ্ট্য"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                  />
                </div>
              </div>

              {/* Form buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingAsset(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-md shadow-teal-600/20 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সম্পদ সংরক্ষণ করুন' : 'Save Asset'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. শো (Show) Modal */}
      {viewingAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Landmark className="w-5 h-5 text-teal-400" />
                <span>মৌজা: {viewingAsset.mouza} (খতিয়ান নং {viewingAsset.khatianNo})</span>
              </h3>
              <button onClick={() => setViewingAsset(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-800 dark:text-slate-200">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70">
                <div>
                  <span className="text-slate-400 block text-[11px]">জেলা</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingAsset.district}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">উপজেলা</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingAsset.upazila}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">ভূমি অফিস</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingAsset.landOffice}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">জেএল নং</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingAsset.jlNo}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">হোল্ডিং নং</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingAsset.holdingNo}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">আনুমানিক মূল্য</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">৳ {viewingAsset.estimatedValueBDT?.toLocaleString('bn-BD')}</span>
                </div>
              </div>

              {/* Owners */}
              <div>
                <h4 className="font-bold text-slate-800 dark:text-white mb-2">মালিকগণের বিবরণ:</h4>
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl overflow-hidden">
                  {viewingAsset.owners?.map((o, idx) => (
                    <div key={idx} className="p-2.5 flex justify-between bg-white dark:bg-slate-850 text-xs">
                      <span className="font-semibold text-slate-800 dark:text-slate-100">{o.name}</span>
                      <span className="text-teal-700 dark:text-teal-400 font-bold">{o.share}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Plots */}
              <div>
                <h4 className="font-bold text-slate-800 dark:text-white mb-2">দাগ ও জমির পরিমাণ:</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {viewingAsset.plots?.map((p, idx) => (
                    <div key={idx} className="p-3 rounded-lg border border-teal-100 dark:border-teal-800/60 bg-teal-50/50 dark:bg-teal-950/40 flex justify-between">
                      <div>
                        <span className="font-bold text-teal-950 dark:text-teal-200 block">{p.dagPlotNo}</span>
                        <span className="text-slate-500 dark:text-slate-400 text-[11px]">{p.landCategory}</span>
                      </div>
                      <span className="font-bold text-teal-800 dark:text-teal-300">{p.landArea} {p.unit}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Documents preview */}
              {(viewingAsset.deedDocumentUrl || viewingAsset.khatianDocumentUrl) && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                  <h4 className="font-bold text-slate-800 dark:text-white mb-2">সংযুক্ত দলিল ও খতিয়ান:</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {viewingAsset.deedDocumentUrl && (
                      <a
                        href={viewingAsset.deedDocumentUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 flex items-center justify-between text-slate-700 dark:text-slate-200"
                      >
                        <span className="font-medium">সাব-রেজিস্ট্রি দলিল</span>
                        <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                      </a>
                    )}
                    {viewingAsset.khatianDocumentUrl && (
                      <a
                        href={viewingAsset.khatianDocumentUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 flex items-center justify-between text-slate-700 dark:text-slate-200"
                      >
                        <span className="font-medium">খতিয়ান পরচা</span>
                        <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/80 px-6 py-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setViewingAsset(null)}
                className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white rounded-lg font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 max-w-sm w-full text-center space-y-3 border border-slate-100 dark:border-slate-800">
            <Trash2 className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'সম্পদের তথ্য মুছে ফেলতে চান?' : 'Delete Asset Record?'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              মৌজা: {deleteCandidate.mouza}, খতিয়ান নং: {deleteCandidate.khatianNo} স্থায়ীভাবে মুছে যাবে।
            </p>
            <div className="flex justify-center gap-2 pt-2">
              <button onClick={() => setDeleteCandidate(null)} className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs cursor-pointer">
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  deleteAsset(deleteCandidate.id);
                  setDeleteCandidate(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
