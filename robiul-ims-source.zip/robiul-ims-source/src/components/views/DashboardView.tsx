import React from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Users, 
  GraduationCap, 
  Landmark, 
  WalletCards, 
  Briefcase, 
  TrendingUp, 
  PlusCircle, 
  ShieldCheck, 
  FileText, 
  Clock, 
  ArrowUpRight,
  ExternalLink,
  Sparkles,
  MapPin,
  Calendar,
  CheckCircle2,
  Building2
} from 'lucide-react';
import { ClockAndCalendarWidget } from '../dashboard/ClockAndCalendarWidget';

export const DashboardView: React.FC = () => {
  const { 
    userProfile, 
    familyMembers, 
    education, 
    skills, 
    assets, 
    liabilities, 
    employment, 
    activityLogs, 
    setActiveTab 
  } = useData();
  const { language } = useLanguage();

  // Calculations
  const totalFamilyCount = familyMembers.length;
  const totalPlotsCount = assets.reduce((sum, a) => sum + (a.plots?.length || 0), 0);
  const totalAssetsValuation = assets.reduce((sum, a) => sum + (a.estimatedValueBDT || 0), 0);
  const activeLiabilities = liabilities.filter(l => l.status === 'চলমান');
  const totalLiabilityBDT = activeLiabilities.reduce((sum, l) => sum + (l.loanAmountBDT - (l.paidAmountBDT || 0)), 0);
  const currentEmployment = employment.find(e => e.isCurrent);
  const netWorth = totalAssetsValuation - totalLiabilityBDT;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 p-6 sm:p-8 text-white shadow-xl border border-emerald-900/40">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              {language === 'bn' ? 'সিস্টেম সক্রিয় ও সুরক্ষিত' : 'System Active & Secure'}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              {language === 'bn' ? `স্বাগতম, ${userProfile.nameBn}!` : `Welcome, ${userProfile.nameEn}!`}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-xl leading-relaxed">
              {language === 'bn'
                ? 'আপনার ব্যক্তিগত ও পারিবারিক ইনফরমেশন ম্যানেজমেন্ট সিস্টেম ড্যাশবোর্ডে সকল গুরুত্বপূর্ণ তথ্যের সারসংক্ষেপ এখানে প্রদর্শিত হচ্ছে।'
                : 'Here is your central overview of family records, land assets, education, employment, and liabilities.'}
            </p>
          </div>

          {/* Quick Shortcuts */}
          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={() => setActiveTab('family')}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer backdrop-blur-xs"
            >
              <Users className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? 'পরিবার তালিকা' : 'Family'}</span>
            </button>
            <button
              onClick={() => setActiveTab('assets')}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer backdrop-blur-xs"
            >
              <Landmark className="w-4 h-4 text-teal-400" />
              <span>{language === 'bn' ? 'সম্পদ ও জমি' : 'Assets'}</span>
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-500/20"
            >
              <FileText className="w-4 h-4" />
              <span>{language === 'bn' ? 'পূর্ণাঙ্গ রিপোর্ট' : 'View Report'}</span>
            </button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* Live Digital Clock & Interactive Calendar */}
      <ClockAndCalendarWidget />

      {/* Main Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Family Card */}
        <div 
          onClick={() => setActiveTab('family')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-600 hover:shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'পরিবার সদস্য' : 'Family Members'}
            </span>
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">{totalFamilyCount}</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 ml-1.5 font-medium">{language === 'bn' ? 'জন নিবন্ধিত' : 'registered'}</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
            <span>{language === 'bn' ? 'বিবরণ দেখুন' : 'View Details'}</span>
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>

        {/* Land Assets Card */}
        <div 
          onClick={() => setActiveTab('assets')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-teal-300 dark:hover:border-teal-600 hover:shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'জমি ও সম্পদ' : 'Land & Assets'}
            </span>
            <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 group-hover:bg-teal-600 group-hover:text-white transition-colors">
              <Landmark className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">{assets.length}</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 ml-1.5 font-medium">
              {language === 'bn' ? `খতিয়ান (${totalPlotsCount} দাগ)` : `Khatians (${totalPlotsCount} plots)`}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-teal-600 dark:text-teal-400 font-semibold">
            <span>{language === 'bn' ? `মূল্য: ৳ ${(totalAssetsValuation / 100000).toFixed(1)} লাখ` : `Valuation: ৳ ${totalAssetsValuation.toLocaleString()}`}</span>
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>

        {/* Liabilities Card */}
        <div 
          onClick={() => setActiveTab('liabilities')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-600 hover:shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'চলমান দায় / ঋণ' : 'Active Liabilities'}
            </span>
            <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <WalletCards className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">
              ৳ {totalLiabilityBDT.toLocaleString('bn-BD')}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-amber-600 dark:text-amber-400 font-semibold">
            <span>{language === 'bn' ? `${activeLiabilities.length}টি লোন চলমান` : `${activeLiabilities.length} active loans`}</span>
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>

        {/* Career & Qualifications Card */}
        <div 
          onClick={() => setActiveTab('employment')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-purple-300 dark:hover:border-purple-600 hover:shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'বর্তমান কর্মসংস্থান' : 'Current Job'}
            </span>
            <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
              {currentEmployment?.companyName || (language === 'bn' ? 'কোন তথ্য নেই' : 'None')}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
              {currentEmployment?.designation || (language === 'bn' ? 'পদবী প্রযোজ্য নয়' : 'N/A')}
            </p>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-purple-600 dark:text-purple-400 font-semibold">
            <span>{language === 'bn' ? 'চাকুরীর ইতিহাস দেখুন' : 'View Timeline'}</span>
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Financial Health & Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Financial Statement Card */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {language === 'bn' ? 'আর্থিক বিবরণী ও ভারসাম্য (Assets vs Liabilities)' : 'Financial Balance Sheet'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {language === 'bn' ? 'স্থাবর সম্পদের আনুমানিক মূল্য ও বকেয়া দেনা' : 'Estimated property values and remaining debts'}
              </p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800">
              {language === 'bn' ? 'পজিটিভ নেট সম্পদ' : 'Positive Net Worth'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            <div className="p-4 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800/60">
              <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 block">
                {language === 'bn' ? 'মোট সম্পদের মূল্য' : 'Total Asset Value'}
              </span>
              <span className="text-lg sm:text-xl font-bold text-emerald-950 dark:text-emerald-100 mt-1 block">
                ৳ {totalAssetsValuation.toLocaleString('bn-BD')}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-rose-50/70 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-800/60">
              <span className="text-xs font-semibold text-rose-800 dark:text-rose-300 block">
                {language === 'bn' ? 'মোট বকেয়া দায়' : 'Remaining Debts'}
              </span>
              <span className="text-lg sm:text-xl font-bold text-rose-950 dark:text-rose-100 mt-1 block">
                ৳ {totalLiabilityBDT.toLocaleString('bn-BD')}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white border border-slate-800 dark:border-slate-700">
              <span className="text-xs font-semibold text-slate-300 dark:text-slate-400 block">
                {language === 'bn' ? 'নিট সম্পদ (Net Worth)' : 'Net Worth'}
              </span>
              <span className="text-lg sm:text-xl font-bold text-emerald-400 mt-1 block">
                ৳ {netWorth.toLocaleString('bn-BD')}
              </span>
            </div>
          </div>

          {/* Quick family cards preview */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {language === 'bn' ? 'পরিবারের সদস্যবৃন্দ' : 'Registered Family Members'}
              </h4>
              <button
                onClick={() => setActiveTab('family')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'সকল সদস্য দেখুন →' : 'View all →'}
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {familyMembers.slice(0, 4).map((m) => (
                <div
                  key={m.id}
                  onClick={() => setActiveTab('family')}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 flex flex-col items-center text-center hover:bg-emerald-50/50 dark:hover:bg-slate-800 hover:border-emerald-200 dark:hover:border-emerald-600 transition-colors cursor-pointer"
                >
                  <img
                    src={m.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                    alt={m.nameBn}
                    className="w-12 h-12 rounded-xl object-cover border border-emerald-500/50 mb-2"
                  />
                  <p className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-1">{m.nameBn}</p>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-medium mt-1">
                    {m.relation}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Recent System Activities */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {language === 'bn' ? 'সাম্প্রতিক কার্যক্রম লগ' : 'Recent Activity Log'}
                </h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium border border-slate-200 dark:border-slate-700">
                {language === 'bn' ? 'লাইভ সিঙ্ক' : 'Live Sync'}
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto max-h-72 mt-2">
              {activityLogs.slice(0, 6).map((log) => (
                <div key={log.id} className="py-2.5 flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0"></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                      {language === 'bn' ? log.descriptionBn : log.descriptionEn}
                    </p>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500">
                      {new Date(log.timestamp).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick tip box */}
          <div className="mt-4 p-3.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200/60 dark:border-teal-800/60 text-xs text-teal-900 dark:text-teal-200 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed text-[11px]">
              {language === 'bn'
                ? 'যেকোনো সময় তথ্যাদি ব্যাকআপ নিতে উপরের "ক্লাউড সিঙ্ক" বাটনে ক্লিক করুন অথবা "রিপোর্ট" থেকে প্রিন্ট করুন।'
                : 'Download backup via the Cloud Sync button or print reports directly from the Reports tab.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
