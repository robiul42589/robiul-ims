import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  GraduationCap, 
  Award, 
  PlusCircle, 
  Eye, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  Building, 
  BookOpen
} from 'lucide-react';
import { EducationItem, SkillItem } from '../../types';
import { FileUploadInput } from '../common/FileUploadInput';

export const EducationSkillsView: React.FC = () => {
  const { 
    education, 
    addEducation, 
    updateEducation, 
    deleteEducation, 
    skills, 
    addSkill, 
    updateSkill, 
    deleteSkill 
  } = useData();
  const { language, t } = useLanguage();

  // Modals
  const [isAddEduModalOpen, setIsAddEduModalOpen] = useState(false);
  const [editingEdu, setEditingEdu] = useState<EducationItem | null>(null);
  const [viewingEdu, setViewingEdu] = useState<EducationItem | null>(null);
  const [deleteEduCandidate, setDeleteEduCandidate] = useState<EducationItem | null>(null);

  const [isAddSkillModalOpen, setIsAddSkillModalOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState<SkillItem | null>(null);
  const [viewingSkill, setViewingSkill] = useState<SkillItem | null>(null);
  const [deleteSkillCandidate, setDeleteSkillCandidate] = useState<SkillItem | null>(null);

  // Education Form
  const initialEduState: Omit<EducationItem, 'id' | 'createdAt'> = {
    examName: '',
    passingYear: '',
    boardUniversity: '',
    institutionName: '',
    gpa: '',
    certificateUrl: 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?auto=format&fit=crop&w=600&q=80',
    certificateFileName: '',
    majorGroup: '',
    notes: ''
  };
  const [eduFormData, setEduFormData] = useState<Omit<EducationItem, 'id' | 'createdAt'>>(initialEduState);

  // Skill Form
  const initialSkillState: Omit<SkillItem, 'id' | 'createdAt'> = {
    skillName: '',
    proficiencyLevel: 'দক্ষ',
    experienceYears: '২ বছর',
    description: '',
    category: 'কারিগরি'
  };
  const [skillFormData, setSkillFormData] = useState<Omit<SkillItem, 'id' | 'createdAt'>>(initialSkillState);

  // Handlers
  const handleOpenAddEdu = () => {
    setEduFormData(initialEduState);
    setIsAddEduModalOpen(true);
  };

  const handleOpenEditEdu = (item: EducationItem) => {
    setEditingEdu(item);
    setEduFormData({
      examName: item.examName,
      passingYear: item.passingYear,
      boardUniversity: item.boardUniversity,
      institutionName: item.institutionName,
      gpa: item.gpa,
      certificateUrl: item.certificateUrl,
      certificateFileName: item.certificateFileName || '',
      majorGroup: item.majorGroup || '',
      notes: item.notes || ''
    });
  };

  const handleSubmitEdu = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEdu) {
      updateEducation(editingEdu.id, eduFormData);
      setEditingEdu(null);
    } else {
      addEducation(eduFormData);
      setIsAddEduModalOpen(false);
    }
  };

  const handleOpenAddSkill = () => {
    setSkillFormData(initialSkillState);
    setIsAddSkillModalOpen(true);
  };

  const handleOpenEditSkill = (item: SkillItem) => {
    setEditingSkill(item);
    setSkillFormData({
      skillName: item.skillName,
      proficiencyLevel: item.proficiencyLevel,
      experienceYears: item.experienceYears,
      description: item.description,
      category: item.category || ''
    });
  };

  const handleSubmitSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSkill) {
      updateSkill(editingSkill.id, skillFormData);
      setEditingSkill(null);
    } else {
      addSkill(skillFormData);
      setIsAddSkillModalOpen(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header and 2 Distinct Add Buttons as explicitly required */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-800 dark:text-blue-300">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {language === 'bn' ? 'শিক্ষা ও দক্ষতা' : 'Education & Skills'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'bn'
                ? 'শিক্ষাগত যোগ্যতা, সনদপত্র এবং পেশাগত দক্ষতার পূর্ণাঙ্গ ডাটাবেজ'
                : 'Educational qualifications, certificates and professional expertise'}
            </p>
          </div>
        </div>

        {/* Prompt requirement: "শিক্ষাগত যোগ্যতা ও দক্ষতার তথ্য যুক্ত করার ২টি বাটন থাকবে।" */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Button 1: শিক্ষাগত যোগ্যতা যুক্ত করুন */}
          <button
            onClick={handleOpenAddEdu}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{language === 'bn' ? 'শিক্ষাগত যোগ্যতা যুক্ত করুন' : 'Add Education'}</span>
          </button>

          {/* Button 2: দক্ষতা যুক্ত করুন */}
          <button
            onClick={handleOpenAddSkill}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-teal-600/20 transition-all cursor-pointer"
          >
            <Award className="w-4 h-4" />
            <span>{language === 'bn' ? 'দক্ষতা যুক্ত করুন' : 'Add Skill'}</span>
          </button>
        </div>
      </div>

      {/* Section 1: শিক্ষাগত যোগ্যতা */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{language === 'bn' ? 'শিক্ষাগত সনদ ও ডিগ্রী বিবরণী' : 'Educational Qualifications'}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 font-bold">
              {education.length} টি
            </span>
          </h3>
        </div>

        {education.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-400">
              {language === 'bn' ? 'কোন শিক্ষাগত তথ্য যুক্ত করা হয়নি।' : 'No education records yet.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {education.map((item) => (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-600 hover:shadow-md transition-all p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Left: Info */}
                <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                  <div className="p-3 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 shrink-0">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-bold text-base text-slate-900 dark:text-white truncate">
                        {item.examName}
                      </h4>
                      <span className="text-xs px-2.5 py-0.5 rounded-lg bg-blue-50 dark:bg-blue-950/70 text-blue-800 dark:text-blue-300 font-bold border border-blue-100 dark:border-blue-800">
                        {item.passingYear} {language === 'bn' ? 'সন' : 'Year'}
                      </span>
                      <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/70 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                        GPA: {item.gpa}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{item.institutionName}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-500 dark:text-slate-400">{item.boardUniversity}</span>
                    </p>
                  </div>
                </div>

                {/* Right: 3 Action Buttons */}
                <div className="flex items-center justify-end gap-1.5 shrink-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                  <button
                    onClick={() => setViewingEdu(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    <span>{t('show', 'দেখুন')}</span>
                  </button>

                  <button
                    onClick={() => handleOpenEditEdu(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="তথ্য সংশোধন"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>{t('edit', 'তথ্য সংশোধন')}</span>
                  </button>

                  <button
                    onClick={() => setDeleteEduCandidate(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    <span>{t('delete', 'মুছে ফেলুন')}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section 2: দক্ষতা সমূহ */}
      <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>{language === 'bn' ? 'দক্ষতা ও পেশাগত অভিজ্ঞতা' : 'Skills & Professional Expertise'}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 font-bold">
              {skills.length} টি
            </span>
          </h3>
        </div>

        {skills.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-400">
              {language === 'bn' ? 'কোন দক্ষতা যুক্ত করা হয়নি।' : 'No skills recorded yet.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {skills.map((skill) => (
              <div
                key={skill.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-teal-300 dark:hover:border-teal-600 hover:shadow-md transition-all p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Left: Info */}
                <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                  <div className="p-3 rounded-2xl bg-teal-100 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 shrink-0">
                    <Award className="w-6 h-6" />
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-bold text-base text-slate-900 dark:text-white truncate">{skill.skillName}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                        {skill.category || 'দক্ষতা'}
                      </span>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 font-bold">
                        {skill.proficiencyLevel}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">অভিজ্ঞতা: {skill.experienceYears}</p>
                    {skill.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-1 leading-relaxed">
                        {skill.description}
                      </p>
                    )}
                  </div>
                </div>

                {/* Right: 3 Action Buttons */}
                <div className="flex items-center justify-end gap-1.5 shrink-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                  <button
                    onClick={() => setViewingSkill(skill)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    <span>{t('show', 'দেখুন')}</span>
                  </button>
                  <button
                    onClick={() => handleOpenEditSkill(skill)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="তথ্য সংশোধন"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>{t('edit', 'তথ্য সংশোধন')}</span>
                  </button>
                  <button
                    onClick={() => setDeleteSkillCandidate(skill)}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    <span>{t('delete', 'মুছে ফেলুন')}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add / Edit Education Modal */}
      {(isAddEduModalOpen || editingEdu) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editingEdu
                  ? (language === 'bn' ? 'শিক্ষাগত যোগ্যতা সংশোধন' : 'Edit Education')
                  : (language === 'bn' ? 'শিক্ষাগত যোগ্যতা যুক্ত করুন' : 'Add Education')}
              </h3>
              <button
                onClick={() => {
                  setIsAddEduModalOpen(false);
                  setEditingEdu(null);
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitEdu} className="p-6 overflow-y-auto space-y-3.5 text-xs text-slate-800 dark:text-slate-200">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'পরীক্ষার নাম *' : 'Exam / Degree Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={eduFormData.examName}
                  onChange={e => setEduFormData({ ...eduFormData, examName: e.target.value })}
                  placeholder="যেমন: এস.এস.সি, এইচ.এস.সি, বি.এসসি ইত্যাদি"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'পাশের সন *' : 'Passing Year *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={eduFormData.passingYear}
                    onChange={e => setEduFormData({ ...eduFormData, passingYear: e.target.value })}
                    placeholder="যেমন: ২০১৭"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'জিপিএ / সিজিপিএ *' : 'GPA / CGPA *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={eduFormData.gpa}
                    onChange={e => setEduFormData({ ...eduFormData, gpa: e.target.value })}
                    placeholder="যেমন: ৫.০০ অথবা ৩.৬৫"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'বোর্ড / বিশ্ববিদ্যালয় *' : 'Board / University *'}
                </label>
                <input
                  type="text"
                  required
                  value={eduFormData.boardUniversity}
                  onChange={e => setEduFormData({ ...eduFormData, boardUniversity: e.target.value })}
                  placeholder="যেমন: রাজশাহী বোর্ড / ঢাকা বিশ্ববিদ্যালয়"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'প্রতিষ্ঠানের নাম *' : 'Institution Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={eduFormData.institutionName}
                  onChange={e => setEduFormData({ ...eduFormData, institutionName: e.target.value })}
                  placeholder="স্কুল, কলেজ বা ভার্সিটির নাম"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                />
              </div>

              <FileUploadInput
                label={language === 'bn' ? 'সনদের কপি আপলোড / সংযুক্ত করুন' : 'Upload / Attach Certificate'}
                value={eduFormData.certificateUrl || ''}
                onChange={(val) => setEduFormData({ ...eduFormData, certificateUrl: val })}
                accept="image/*,application/pdf"
                isImage={false}
                placeholder="https://..."
                helperText={language === 'bn' ? 'সনদের ছবি (JPG, PNG) অথবা পিডিএফ (PDF) আপলোড করুন' : 'Upload certificate photo or PDF document'}
              />

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddEduModalOpen(false);
                    setEditingEdu(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সংরক্ষণ করুন' : 'Save'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Skill Modal */}
      {(isAddSkillModalOpen || editingSkill) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {editingSkill
                  ? (language === 'bn' ? 'দক্ষতার তথ্য সংশোধন' : 'Edit Skill')
                  : (language === 'bn' ? 'দক্ষতা যুক্ত করুন' : 'Add Skill')}
              </h3>
              <button
                onClick={() => {
                  setIsAddSkillModalOpen(false);
                  setEditingSkill(null);
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitSkill} className="space-y-3.5">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'দক্ষতার নাম *' : 'Skill Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={skillFormData.skillName}
                  onChange={e => setSkillFormData({ ...skillFormData, skillName: e.target.value })}
                  placeholder="যেমন: ওয়েব ডেভেলপমেন্ট, কম্পিউটার অফিস প্রোগ্রাম"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'দক্ষতার স্তর *' : 'Proficiency Level *'}
                  </label>
                  <select
                    value={skillFormData.proficiencyLevel}
                    onChange={e => setSkillFormData({ ...skillFormData, proficiencyLevel: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="শিক্ষানবিস">শিক্ষানবিস (Beginner)</option>
                    <option value="মধ্যম">মধ্যম (Intermediate)</option>
                    <option value="দক্ষ">দক্ষ (Skilled)</option>
                    <option value="বিশেষজ্ঞ">বিশেষজ্ঞ (Expert)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'অভিজ্ঞতা *' : 'Experience *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={skillFormData.experienceYears}
                    onChange={e => setSkillFormData({ ...skillFormData, experienceYears: e.target.value })}
                    placeholder="যেমন: ৫ বছর"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'সংক্ষিপ্ত বিবরণ' : 'Description'}
                </label>
                <textarea
                  rows={3}
                  value={skillFormData.description}
                  onChange={e => setSkillFormData({ ...skillFormData, description: e.target.value })}
                  placeholder="কাজের ধরণ ও বিস্তারিত অভিজ্ঞতা"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddSkillModalOpen(false);
                    setEditingSkill(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সংরক্ষণ করুন' : 'Save'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Show Education Detail Modal */}
      {viewingEdu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100 dark:border-slate-800 space-y-4 text-xs text-slate-800 dark:text-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>{viewingEdu.examName}</span>
              </h3>
              <button onClick={() => setViewingEdu(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-750">
                <div>
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'পাশের সন' : 'Year'}</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingEdu.passingYear}</span>
                </div>
                <div>
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'প্রাপ্ত জিপিএ' : 'GPA'}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{viewingEdu.gpa}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'শিক্ষা প্রতিষ্ঠান' : 'Institution'}</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingEdu.institutionName}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'বোর্ড / বিশ্ববিদ্যালয়' : 'Board'}</span>
                  <span className="font-bold text-slate-800 dark:text-white">{viewingEdu.boardUniversity}</span>
                </div>
              </div>

              {viewingEdu.certificateUrl && (
                <div>
                  <p className="font-bold text-slate-700 dark:text-slate-300 mb-1.5">{language === 'bn' ? 'সনদের কপি প্রিভিউ:' : 'Certificate Preview:'}</p>
                  <img
                    src={viewingEdu.certificateUrl}
                    alt="Certificate"
                    className="w-full h-48 object-cover rounded-xl border border-slate-200 dark:border-slate-700"
                  />
                </div>
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setViewingEdu(null)}
                className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white rounded-lg font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Show Skill Detail Modal */}
      {viewingSkill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-sm w-full p-6 border border-slate-100 dark:border-slate-800 space-y-4 text-xs text-slate-800 dark:text-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <span>{viewingSkill.skillName}</span>
              </h3>
              <button onClick={() => setViewingSkill(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70">
              <p><span className="text-slate-400">দক্ষতার স্তর:</span> <strong className="text-teal-700 dark:text-teal-300">{viewingSkill.proficiencyLevel}</strong></p>
              <p><span className="text-slate-400">অভিজ্ঞতা:</span> <strong className="text-slate-800 dark:text-white">{viewingSkill.experienceYears}</strong></p>
              <p className="pt-2 text-slate-700 dark:text-slate-300 leading-relaxed">{viewingSkill.description}</p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingSkill(null)}
                className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white rounded-lg font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Edu Confirmation */}
      {deleteEduCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 max-w-sm w-full text-center space-y-3 border border-slate-100 dark:border-slate-800">
            <Trash2 className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'শিক্ষাগত যোগ্যতা মুছে ফেলতে চান?' : 'Delete Education Record?'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              "{deleteEduCandidate.examName}" স্থায়ীভাবে মুছে যাবে।
            </p>
            <div className="flex justify-center gap-2 pt-2">
              <button onClick={() => setDeleteEduCandidate(null)} className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs cursor-pointer">
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  deleteEducation(deleteEduCandidate.id);
                  setDeleteEduCandidate(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Skill Confirmation */}
      {deleteSkillCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 max-w-sm w-full text-center space-y-3 border border-slate-100 dark:border-slate-800">
            <Trash2 className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'দক্ষতার তথ্য মুছে ফেলতে চান?' : 'Delete Skill?'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              "{deleteSkillCandidate.skillName}" মুছে যাবে।
            </p>
            <div className="flex justify-center gap-2 pt-2">
              <button onClick={() => setDeleteSkillCandidate(null)} className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs cursor-pointer">
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  deleteSkill(deleteSkillCandidate.id);
                  setDeleteSkillCandidate(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
