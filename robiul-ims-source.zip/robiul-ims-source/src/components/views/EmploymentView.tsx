import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Briefcase, 
  PlusCircle, 
  Eye, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  Calendar, 
  Building, 
  ExternalLink,
  Clock
} from 'lucide-react';
import { EmploymentItem } from '../../types';
import { FileUploadInput } from '../common/FileUploadInput';

export const EmploymentView: React.FC = () => {
  const { employment, addEmployment, updateEmployment, deleteEmployment, globalSearchQuery } = useData();
  const { language, t } = useLanguage();

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<EmploymentItem | null>(null);
  const [viewingJob, setViewingJob] = useState<EmploymentItem | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<EmploymentItem | null>(null);

  // Form state
  const initialFormState: Omit<EmploymentItem, 'id' | 'createdAt'> = {
    companyName: '',
    designation: '',
    joiningDate: '',
    isCurrent: true, // চলমান একটি চেকবক্স
    releaseDate: '', // অব্যাহতির তারিখ (চলমান থাকলে disabled)
    department: '',
    location: '',
    salaryBDT: 0,
    remarks: '',
    joiningLetterUrl: '',
    appointmentLetterUrl: ''
  };

  const [formData, setFormData] = useState<Omit<EmploymentItem, 'id' | 'createdAt'>>(initialFormState);

  const handleOpenAdd = () => {
    setFormData(initialFormState);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (item: EmploymentItem) => {
    setEditingJob(item);
    setFormData({
      companyName: item.companyName,
      designation: item.designation,
      joiningDate: item.joiningDate,
      isCurrent: item.isCurrent,
      releaseDate: item.releaseDate || '',
      department: item.department || '',
      location: item.location || '',
      salaryBDT: item.salaryBDT || 0,
      remarks: item.remarks || '',
      joiningLetterUrl: item.joiningLetterUrl || '',
      appointmentLetterUrl: item.appointmentLetterUrl || ''
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSave = {
      ...formData,
      releaseDate: formData.isCurrent ? '' : formData.releaseDate
    };

    if (editingJob) {
      updateEmployment(editingJob.id, dataToSave);
      setEditingJob(null);
    } else {
      addEmployment(dataToSave);
      setIsAddModalOpen(false);
    }
  };

  const filteredEmployment = employment.filter(e => {
    if (!globalSearchQuery) return true;
    const q = globalSearchQuery.toLowerCase();
    return (
      e.companyName.toLowerCase().includes(q) ||
      e.designation.toLowerCase().includes(q) ||
      (e.remarks && e.remarks.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300">
            <Briefcase className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {language === 'bn' ? 'চাকুরীর ইতিহাস' : 'Employment History'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'bn'
                ? 'বর্তমান কর্মসংস্থান, পূর্ববর্তী চাকুরীর রেকর্ড ও নিয়োগপত্রের নথিপত্র'
                : 'Current position, career timeline, joining and appointment letters'}
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-purple-600/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{language === 'bn' ? 'চাকুরীর তথ্য যুক্ত করুন' : 'Add Employment'}</span>
        </button>
      </div>

      {/* Career Timeline / Cards */}
      {filteredEmployment.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 dark:text-slate-500">
            <Briefcase className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-700 dark:text-slate-200">
            {language === 'bn' ? 'কোন চাকুরীর তথ্য পাওয়া যায়নি' : 'No employment records found'}
          </h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 max-w-sm mx-auto">
            {language === 'bn'
              ? 'নতুন কর্মসংস্থান বা চাকুরীর ইতিহাস যুক্ত করতে উপরের "চাকুরীর তথ্য যুক্ত করুন" বাটনে ক্লিক করুন।'
              : 'Click the button above to add job records.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredEmployment.map((job) => (
            <div
              key={job.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-purple-300 dark:hover:border-purple-700/60 hover:shadow-md transition-all p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              {/* Job Info */}
              <div className="flex items-start gap-4 flex-1">
                <div className={`p-3 rounded-2xl shrink-0 ${job.isCurrent ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                  <Briefcase className="w-6 h-6" />
                </div>

                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                      {job.designation}
                    </h3>
                    {job.isCurrent ? (
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        {language === 'bn' ? 'বর্তমান চাকুরী' : 'Current Job'}
                      </span>
                    ) : (
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-medium">
                        {language === 'bn' ? 'অব্যাহতিপ্রাপ্ত' : 'Former'}
                      </span>
                    )}
                  </div>

                  <p className="text-sm font-semibold text-purple-700 dark:text-purple-400 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                    <span>{job.companyName}</span>
                  </p>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 pt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                      {language === 'bn' ? 'যোগদান:' : 'Joined:'} {job.joiningDate}
                    </span>
                    {!job.isCurrent && job.releaseDate && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                        {language === 'bn' ? 'অব্যাহতি:' : 'Released:'} {job.releaseDate}
                      </span>
                    )}
                  </div>

                  {job.remarks && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 pt-1.5 line-clamp-1 leading-relaxed">
                      {job.remarks}
                    </p>
                  )}
                </div>
              </div>

              {/* Exact Prompt Requirement: ডানপাশে ৩টি অপসন থাকবে শো, তথ্য সংশোধন, মুছে ফেলুন বাটন */}
              <div className="flex items-center justify-end gap-1.5 shrink-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                {/* 1. দেখুন বাটন */}
                <button
                  onClick={() => setViewingJob(job)}
                  className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-900/70 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="দেখুন"
                >
                  <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>{t('show', 'দেখুন')}</span>
                </button>

                {/* 2. তথ্য সংশোধন বাটন */}
                <button
                  onClick={() => handleOpenEdit(job)}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-900/70 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="তথ্য সংশোধন"
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>{t('edit', 'তথ্য সংশোধন')}</span>
                </button>

                {/* 3. মুছে ফেলুন বাটন */}
                <button
                  onClick={() => setDeleteCandidate(job)}
                  className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/70 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="মুছে ফেলুন"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                  <span>{t('delete', 'মুছে ফেলুন')}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Employment Modal */}
      {(isAddModalOpen || editingJob) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[88vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            <div className="bg-gradient-to-r from-slate-900 to-purple-950 px-6 py-4 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white">
                  {editingJob
                    ? (language === 'bn' ? 'চাকুরীর তথ্য সংশোধন' : 'Edit Employment')
                    : (language === 'bn' ? 'চাকুরীর তথ্য যুক্ত করুন' : 'Add Employment Record')}
                </h3>
                <p className="text-xs text-purple-300">
                  {language === 'bn' ? 'প্রতিষ্ঠানের নাম, পদবী, তারিখ ও নিয়োগপত্র পূরণ করুন' : 'Fill company, designation, dates and letters'}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingJob(null);
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-3.5 text-xs">
              {/* প্রতিষ্ঠানের নাম */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'প্রতিষ্ঠানের নাম *' : 'Company / Institution Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.companyName}
                  onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                  placeholder="যেমন: টেকনোভার্স বাংলাদেশ লিমিটেড"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* পদবী */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'পদবী *' : 'Designation *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.designation}
                  onChange={e => setFormData({ ...formData, designation: e.target.value })}
                  placeholder="যেমন: সিনিয়র সিস্টেম অ্যানালিস্ট"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* চাকুরীতে যোগদানের তারিখ */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'চাকুরীতে যোগদানের তারিখ *' : 'Joining Date *'}
                </label>
                <input
                  type="date"
                  required
                  value={formData.joiningDate}
                  onChange={e => setFormData({ ...formData, joiningDate: e.target.value })}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* Prompt explicit requirement:
                  "চলমান একটি চেকবক্স থাকবে এখানে ক্লিক করলে অব্যাহতির তারিখ ঘরটি ডিসেবল হয়ে যাবে আর ক্লিক না করলে অব্যাহতির তারিখ ঘরটি স্বাভাবিক থাকবে, অব্যাহতির তারিখ" */}
              <div className="p-3.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200/80 dark:border-purple-900/50 space-y-2.5">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.isCurrent}
                    onChange={e => setFormData({ ...formData, isCurrent: e.target.checked })}
                    className="w-4 h-4 text-purple-600 rounded-sm border-slate-300 dark:border-slate-700 focus:ring-purple-500"
                  />
                  <span className="font-bold text-purple-950 dark:text-purple-200 text-xs">
                    {language === 'bn' ? 'বর্তমানে চাকুরীরত অবস্থায় আছি (চলমান)' : 'Currently working here (Ongoing)'}
                  </span>
                </label>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'অব্যাহতির তারিখ' : 'Release / End Date'}
                    {formData.isCurrent && (
                      <span className="text-[10px] text-purple-700 dark:text-purple-400 ml-1.5 font-normal">
                        ({language === 'bn' ? 'চলমান থাকায় ঘরটি নিষ্ক্রিয়' : 'Disabled as currently working'})
                      </span>
                    )}
                  </label>
                  <input
                    type="date"
                    disabled={formData.isCurrent}
                    value={formData.isCurrent ? '' : formData.releaseDate}
                    onChange={e => setFormData({ ...formData, releaseDate: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg transition-all ${
                      formData.isCurrent
                        ? 'bg-slate-100/90 dark:bg-slate-800/50 text-slate-400 dark:text-slate-500 border-slate-200 dark:border-slate-700 cursor-not-allowed'
                        : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-purple-500'
                    }`}
                  />
                </div>
              </div>

              {/* যোগদান পত্র ও নিয়োগপত্র আপলোড করুন */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FileUploadInput
                  label={language === 'bn' ? 'যোগদান পত্র আপলোড / সংযুক্ত করুন' : 'Upload / Attach Joining Letter'}
                  value={formData.joiningLetterUrl || ''}
                  onChange={(val) => setFormData({ ...formData, joiningLetterUrl: val })}
                  accept="image/*,application/pdf"
                  isImage={false}
                  placeholder="https://..."
                  helperText={language === 'bn' ? 'যোগদান পত্রের কপি বা ছবি আপলোড করুন' : 'Upload joining letter document or photo'}
                />
                <FileUploadInput
                  label={language === 'bn' ? 'নিয়োগপত্র আপলোড / সংযুক্ত করুন' : 'Upload / Attach Appointment Letter'}
                  value={formData.appointmentLetterUrl || ''}
                  onChange={(val) => setFormData({ ...formData, appointmentLetterUrl: val })}
                  accept="image/*,application/pdf"
                  isImage={false}
                  placeholder="https://..."
                  helperText={language === 'bn' ? 'অফিসিয়াল নিয়োগপত্রের কপি বা ছবি আপলোড করুন' : 'Upload appointment letter document or photo'}
                />
              </div>

              {/* মন্তব্য */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'মন্তব্য (কাজের বিবরণ ও দায়িত্ব)' : 'Remarks / Responsibilities'}
                </label>
                <textarea
                  rows={2}
                  value={formData.remarks}
                  onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                  placeholder="প্রধান দায়িত্ব ও অর্জনের বিবরণ"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* Action buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingJob(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-md shadow-purple-600/20"
                >
                  <Save className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সংরক্ষণ করুন' : 'Save'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Show Job Modal */}
      {viewingJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-100 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span>{viewingJob.designation}</span>
              </h3>
              <button onClick={() => setViewingJob(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">প্রতিষ্ঠান:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{viewingJob.companyName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">যোগদানের তারিখ:</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">{viewingJob.joiningDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">অবস্থা:</span>
                <span className="font-bold text-purple-800 dark:text-purple-300">
                  {viewingJob.isCurrent ? 'বর্তমানে চাকুরীরত' : `অব্যাহতি (${viewingJob.releaseDate || 'নেই'})`}
                </span>
              </div>
              {viewingJob.remarks && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-slate-400 block mb-0.5">মন্তব্য / দায়িত্ব:</span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{viewingJob.remarks}</p>
                </div>
              )}
            </div>

            {/* Document Links */}
            {(viewingJob.joiningLetterUrl || viewingJob.appointmentLetterUrl) && (
              <div className="space-y-2 pt-2">
                <span className="font-bold text-slate-700 dark:text-slate-300">সংযুক্ত নথিপত্র:</span>
                <div className="grid grid-cols-2 gap-2">
                  {viewingJob.joiningLetterUrl && (
                    <a
                      href={viewingJob.joiningLetterUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center justify-between font-medium text-slate-700 dark:text-slate-200"
                    >
                      <span>যোগদান পত্র</span>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </a>
                  )}
                  {viewingJob.appointmentLetterUrl && (
                    <a
                      href={viewingJob.appointmentLetterUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 flex items-center justify-between font-medium text-slate-700 dark:text-slate-200"
                    >
                      <span>নিয়োগপত্র</span>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </a>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingJob(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-semibold"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full text-center space-y-3">
            <Trash2 className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'চাকুরীর তথ্য মুছে ফেলতে চান?' : 'Delete Employment Record?'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              "{deleteCandidate.companyName}" এর তথ্য মুছে যাবে।
            </p>
            <div className="flex justify-center gap-2 pt-2">
              <button onClick={() => setDeleteCandidate(null)} className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs">
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  deleteEmployment(deleteCandidate.id);
                  setDeleteCandidate(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
