import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Users, 
  UserPlus, 
  Eye, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  MapPin, 
  Calendar, 
  Shield, 
  Printer
} from 'lucide-react';
import { FamilyMember, FamilyRelation } from '../../types';
import { FileUploadInput } from '../common/FileUploadInput';

export const FamilyView: React.FC = () => {
  const { familyMembers, addFamilyMember, updateFamilyMember, deleteFamilyMember, globalSearchQuery } = useData();
  const { language, t } = useLanguage();

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [viewingMember, setViewingMember] = useState<FamilyMember | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<FamilyMember | null>(null);

  // Form state
  const initialFormState: Omit<FamilyMember, 'id' | 'createdAt'> = {
    nameBn: '',
    nameEn: '',
    dob: '',
    fatherNameBn: '',
    motherNameBn: '',
    birthRegNo: '',
    nidNo: '',
    village: '',
    postOffice: '',
    postalCode: '',
    upazila: '',
    district: '',
    relation: 'ভাই',
    photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bloodGroup: 'B+',
    phone: '',
    occupation: '',
    notes: ''
  };

  const [formData, setFormData] = useState<Omit<FamilyMember, 'id' | 'createdAt'>>(initialFormState);

  const relationsList: FamilyRelation[] = [
    'নিজ',
    'পিতা',
    'মাতা',
    'ভাই',
    'বোন',
    'স্ত্রী',
    'স্বামী',
    'সন্তান(কন্যা)',
    'সন্তান(পুত্র)',
    'দাদা',
    'দাদী',
    'অন্যান্য'
  ];

  const filteredMembers = familyMembers.filter(m => {
    if (!globalSearchQuery) return true;
    const q = globalSearchQuery.toLowerCase();
    return (
      m.nameBn.toLowerCase().includes(q) ||
      m.nameEn.toLowerCase().includes(q) ||
      m.nidNo.includes(q) ||
      m.birthRegNo.includes(q) ||
      m.relation.toLowerCase().includes(q) ||
      m.village.toLowerCase().includes(q) ||
      m.district.toLowerCase().includes(q)
    );
  });

  const handleOpenAdd = () => {
    setFormData(initialFormState);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (member: FamilyMember) => {
    setEditingMember(member);
    setFormData({
      nameBn: member.nameBn,
      nameEn: member.nameEn,
      dob: member.dob,
      fatherNameBn: member.fatherNameBn,
      motherNameBn: member.motherNameBn,
      birthRegNo: member.birthRegNo,
      nidNo: member.nidNo,
      village: member.village,
      postOffice: member.postOffice,
      postalCode: member.postalCode,
      upazila: member.upazila,
      district: member.district,
      relation: member.relation,
      photoUrl: member.photoUrl,
      bloodGroup: member.bloodGroup || '',
      phone: member.phone || '',
      occupation: member.occupation || '',
      notes: member.notes || ''
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMember) {
      updateFamilyMember(editingMember.id, formData);
      setEditingMember(null);
    } else {
      addFamilyMember(formData);
      setIsAddModalOpen(false);
    }
  };

  const confirmDelete = () => {
    if (deleteCandidate) {
      deleteFamilyMember(deleteCandidate.id);
      setDeleteCandidate(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header & Add button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {language === 'bn' ? 'পরিবার পরিচিতি' : 'Family Profile'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {language === 'bn'
                  ? 'পরিবারের সকল সদস্যদের ব্যক্তিগত, পরিচয়পত্র ও ঠিকানার পূর্ণাঙ্গ তালিকা'
                  : 'Manage family member records, NID, birth registration and addresses'}
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>{language === 'bn' ? 'পরিবারের সদস্য যুক্ত করুন' : 'Add Family Member'}</span>
        </button>
      </div>

      {/* Member summary table / cards */}
      {filteredMembers.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-700 dark:text-slate-300">
            {language === 'bn' ? 'কোন সদস্য পাওয়া যায়নি' : 'No family members found'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {language === 'bn'
              ? 'নতুন সদস্য যুক্ত করতে উপরের সবুজ "পরিবারের সদস্য যুক্ত করুন" বাটনে ক্লিক করুন।'
              : 'Click the button above to add family members.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-600 hover:shadow-md transition-all p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              {/* Member Left Info */}
              <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                <img
                  src={member.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'}
                  alt={member.nameBn}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border-2 border-emerald-500/50 shadow-xs shrink-0"
                />
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-bold text-base text-slate-900 dark:text-white truncate">
                      {member.nameBn}
                    </h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold">
                      {member.relation}
                    </span>
                    {member.bloodGroup && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold border border-rose-200 dark:border-rose-800">
                        {member.bloodGroup}
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {member.nameEn} {member.occupation ? `· ${member.occupation}` : ''}
                  </p>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300 pt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{language === 'bn' ? 'জন্ম তারিখ:' : 'DoB:'} {member.dob || 'তথ্য নেই'}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Shield className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{language === 'bn' ? 'এনআইডি:' : 'NID:'} <span className="font-mono">{member.nidNo || 'নেই'}</span></span>
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{member.village}, {member.upazila}, {member.district}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Exact Prompt Requirement: ডানপাশে ৩টি অপসন থাকবে দেখুন, তথ্য সংশোধন, মুছে ফেলুন বাটন */}
              <div className="flex items-center justify-end gap-1.5 shrink-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                {/* 1. দেখুন বাটন */}
                <button
                  onClick={() => setViewingMember(member)}
                  className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="দেখুন"
                >
                  <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>{t('show', 'দেখুন')}</span>
                </button>

                {/* 2. তথ্য সংশোধন বাটন */}
                <button
                  onClick={() => handleOpenEdit(member)}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="তথ্য সংশোধন (Edit)"
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>{t('edit', 'তথ্য সংশোধন')}</span>
                </button>

                {/* 3. মুছে ফেলুন বাটন */}
                <button
                  onClick={() => setDeleteCandidate(member)}
                  className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  title="মুছে ফেলুন (Delete)"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                  <span>{t('delete', 'মুছে ফেলুন')}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Member Modal with all required fields */}
      {(isAddModalOpen || editingMember) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-900 to-emerald-950 px-6 py-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {editingMember
                      ? (language === 'bn' ? 'সদস্যের তথ্য সংশোধন করুন' : 'Edit Member Details')
                      : (language === 'bn' ? 'পরিবারে নতুন সদস্য যুক্ত করুন' : 'Add New Family Member')}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {language === 'bn' ? 'সকল ঘর সঠিকভাবে পূরণ করুন' : 'Please fill all required details carefully'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingMember(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
              {/* Photo & Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'নাম (বাংলায়) *' : 'Name (Bangla) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nameBn}
                    onChange={e => setFormData({ ...formData, nameBn: e.target.value })}
                    placeholder="যেমন: মোঃ রফিকুল ইসলাম"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'নাম (ইংরেজিতে) *' : 'Name (English) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nameEn}
                    onChange={e => setFormData({ ...formData, nameEn: e.target.value })}
                    placeholder="e.g. Md. Rafiqul Islam"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Parents Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'পিতার নাম (বাংলায়) *' : "Father's Name (Bangla) *"}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fatherNameBn}
                    onChange={e => setFormData({ ...formData, fatherNameBn: e.target.value })}
                    placeholder="পিতার নাম বাংলায় লিখুন"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'মাতার নাম (বাংলায়) *' : "Mother's Name (Bangla) *"}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.motherNameBn}
                    onChange={e => setFormData({ ...formData, motherNameBn: e.target.value })}
                    placeholder="মাতার নাম বাংলায় লিখুন"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Relation & DoB */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'ব্যবহারকারীর সাথে সম্পর্ক *' : 'Relation *'}
                  </label>
                  <select
                    value={formData.relation}
                    onChange={e => setFormData({ ...formData, relation: e.target.value as FamilyRelation })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {relationsList.map(rel => (
                      <option key={rel} value={rel}>{rel}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'জন্ম তারিখ *' : 'Date of Birth *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.dob}
                    onChange={e => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'রক্তের গ্রুপ' : 'Blood Group'}
                  </label>
                  <select
                    value={formData.bloodGroup}
                    onChange={e => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="">বাছাই করুন</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
              </div>

              {/* ID numbers: NID & Birth Registration */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'জাতীয় পরিচয় পত্র নম্বর (NID)' : 'National ID (NID)'}
                  </label>
                  <input
                    type="text"
                    value={formData.nidNo}
                    onChange={e => setFormData({ ...formData, nidNo: e.target.value })}
                    placeholder="১০ বা ১৭ ডিজিটের এনআইডি"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'জন্ম নিবন্ধন সনদ নম্বর' : 'Birth Registration No'}
                  </label>
                  <input
                    type="text"
                    value={formData.birthRegNo}
                    onChange={e => setFormData({ ...formData, birthRegNo: e.target.value })}
                    placeholder="১৭ ডিজিটের জন্ম নিবন্ধন নম্বর"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Address Section */}
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <p className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'ঠিকানা সেকশন (বর্তমান ঠিকানা)' : 'Address Section (Present Address)'}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                      {language === 'bn' ? 'গ্রাম *' : 'Village *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.village}
                      onChange={e => setFormData({ ...formData, village: e.target.value })}
                      placeholder="গ্রামের নাম"
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                      {language === 'bn' ? 'ডাকঘর *' : 'Post Office *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.postOffice}
                      onChange={e => setFormData({ ...formData, postOffice: e.target.value })}
                      placeholder="ডাকঘর"
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                      {language === 'bn' ? 'পোস্ট কোড *' : 'Postal Code *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.postalCode}
                      onChange={e => setFormData({ ...formData, postalCode: e.target.value })}
                      placeholder="যেমন: ৬৬২০"
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                      {language === 'bn' ? 'উপজেলা *' : 'Upazila *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.upazila}
                      onChange={e => setFormData({ ...formData, upazila: e.target.value })}
                      placeholder="উপজেলা"
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                      {language === 'bn' ? 'জেলা *' : 'District *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.district}
                      onChange={e => setFormData({ ...formData, district: e.target.value })}
                      placeholder="জেলা"
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Photo Attachment & Notes */}
              <div className="space-y-3">
                <FileUploadInput
                  label={language === 'bn' ? 'সদস্যের ছবি আপলোড / সংযুক্ত করুন' : 'Upload / Attach Member Photo'}
                  value={formData.photoUrl || ''}
                  onChange={(val) => setFormData({ ...formData, photoUrl: val })}
                  accept="image/*"
                  isImage={true}
                  placeholder="https://..."
                  helperText={language === 'bn' ? 'ডিভাইস থেকে সরাসরি ছবি বেছে নিন অথবা অনলাইন ছবির লিঙ্ক প্রদান করুন' : 'Choose photo from device or enter an image link'}
                />

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'পেশা / মন্তব্য (ঐচ্ছিক)' : 'Occupation / Notes'}
                  </label>
                  <input
                    type="text"
                    value={formData.occupation}
                    onChange={e => setFormData({ ...formData, occupation: e.target.value })}
                    placeholder="যেমন: ছাত্র, চাকুরীজীবী, গৃহিণী"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingMember(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg font-medium cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>
                    {editingMember
                      ? (language === 'bn' ? 'সংশোধন সংরক্ষণ করুন' : 'Update Member')
                      : (language === 'bn' ? 'তথ্য যুক্ত করুন' : 'Save Member')}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. শো (Show) Modal */}
      {viewingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            {/* Header */}
            <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Eye className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">
                  {language === 'bn' ? 'পারিবারিক সদস্যের পূর্ণাঙ্গ বিবরণ' : 'Family Member Details Card'}
                </h3>
              </div>
              <button
                onClick={() => setViewingMember(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-800 dark:text-slate-100">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-700">
                <img
                  src={viewingMember.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'}
                  alt={viewingMember.nameBn}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold">
                      {viewingMember.relation}
                    </span>
                    {viewingMember.bloodGroup && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold border border-rose-200 dark:border-rose-800">
                        গ্রুপ: {viewingMember.bloodGroup}
                      </span>
                    )}
                  </div>
                  <h4 className="text-lg font-bold text-slate-900 dark:text-white mt-1">{viewingMember.nameBn}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{viewingMember.nameEn}</p>
                  {viewingMember.occupation && (
                    <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mt-0.5">{viewingMember.occupation}</p>
                  )}
                </div>
              </div>

              {/* Data Table */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'পিতার নাম' : "Father's Name"}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100">{viewingMember.fatherNameBn}</span>
                </div>
                <div className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'মাতার নাম' : "Mother's Name"}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100">{viewingMember.motherNameBn}</span>
                </div>
                <div className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'জন্ম তারিখ' : 'Date of Birth'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100">{viewingMember.dob}</span>
                </div>
                <div className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'জাতীয় পরিচয় পত্র (NID)' : 'National ID'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100 font-mono">{viewingMember.nidNo || 'প্রযোজ্য নয়'}</span>
                </div>
                <div className="sm:col-span-2 p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'জন্ম নিবন্ধন সনদ নম্বর' : 'Birth Registration No'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100 font-mono">{viewingMember.birthRegNo || 'প্রযোজ্য নয়'}</span>
                </div>
                <div className="sm:col-span-2 p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-850">
                  <span className="text-slate-400 dark:text-slate-400 block text-[11px]">{language === 'bn' ? 'বর্তমান ঠিকানা' : 'Present Address'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-100 leading-relaxed">
                    গ্রাম: {viewingMember.village}, ডাকঘর: {viewingMember.postOffice} ({viewingMember.postalCode}), উপজেলা: {viewingMember.upazila}, জেলা: {viewingMember.district}
                  </span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 dark:bg-slate-800/80 px-6 py-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-medium text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'প্রিন্ট করুন' : 'Print'}</span>
              </button>
              <button
                onClick={() => setViewingMember(null)}
                className="px-4 py-1.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. মুছে ফেলুন (Delete) Confirmation Dialog */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-sm w-full p-6 text-center border border-slate-100 dark:border-slate-800 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {language === 'bn' ? 'তথ্যটি মুছে ফেলতে চান?' : 'Delete Family Member?'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                {language === 'bn'
                  ? `আপনি কি নিশ্চিতভাবে "${deleteCandidate.nameBn}" এর তথ্য স্থায়ীভাবে মুছে ফেলতে চান?`
                  : `Are you sure you want to permanently delete "${deleteCandidate.nameEn || deleteCandidate.nameBn}"?`}
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold rounded-lg cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow-md shadow-rose-600/20 cursor-pointer"
              >
                {language === 'bn' ? 'হ্যাঁ, মুছে ফেলুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
