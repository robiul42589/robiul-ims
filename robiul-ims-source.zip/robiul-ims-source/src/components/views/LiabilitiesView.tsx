import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  WalletCards, 
  PlusCircle, 
  Eye, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  Building2,
  Calendar,
  Clock
} from 'lucide-react';
import { LiabilityItem } from '../../types';
import { FileUploadInput } from '../common/FileUploadInput';

export const LiabilitiesView: React.FC = () => {
  const { liabilities, addLiability, updateLiability, deleteLiability, globalSearchQuery } = useData();
  const { language, t } = useLanguage();

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingLiability, setEditingLiability] = useState<LiabilityItem | null>(null);
  const [viewingLiability, setViewingLiability] = useState<LiabilityItem | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<LiabilityItem | null>(null);

  // Form State
  const initialFormState: Omit<LiabilityItem, 'id' | 'createdAt'> = {
    liabilityReason: '',
    creditorName: '',
    incurredDate: '',
    loanAmountBDT: 0,
    expectedRepaymentDate: '',
    paidAmountBDT: 0,
    status: 'চলমান',
    remarks: '',
    attachmentUrl: ''
  };

  const [formData, setFormData] = useState<Omit<LiabilityItem, 'id' | 'createdAt'>>(initialFormState);

  const handleOpenAdd = () => {
    setFormData(initialFormState);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (item: LiabilityItem) => {
    setEditingLiability(item);
    setFormData({
      liabilityReason: item.liabilityReason,
      creditorName: item.creditorName,
      incurredDate: item.incurredDate,
      loanAmountBDT: item.loanAmountBDT,
      expectedRepaymentDate: item.expectedRepaymentDate,
      paidAmountBDT: item.paidAmountBDT || 0,
      status: item.status,
      remarks: item.remarks || '',
      attachmentUrl: item.attachmentUrl || ''
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingLiability) {
      updateLiability(editingLiability.id, formData);
      setEditingLiability(null);
    } else {
      addLiability(formData);
      setIsAddModalOpen(false);
    }
  };

  const filteredLiabilities = liabilities.filter(l => {
    if (!globalSearchQuery) return true;
    const q = globalSearchQuery.toLowerCase();
    return (
      l.liabilityReason.toLowerCase().includes(q) ||
      l.creditorName.toLowerCase().includes(q) ||
      l.status.toLowerCase().includes(q) ||
      (l.remarks && l.remarks.toLowerCase().includes(q))
    );
  });

  const totalActiveLoan = liabilities
    .filter(l => l.status === 'চলমান')
    .reduce((sum, l) => sum + (l.loanAmountBDT - (l.paidAmountBDT || 0)), 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
            <WalletCards className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {language === 'bn' ? 'দায় সমূহ (ঋণ ও দেনা)' : 'Liabilities & Debts'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'bn'
                ? 'বিগত সময়ের ও চলমান সকল ব্যাংক ঋণ, ব্যক্তিগত ধার ও দায়-দেনার হিসাব'
                : 'Track financial liabilities, creditors, loan tenure and settlement status'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <div className="hidden sm:block text-right">
            <span className="text-[10px] text-slate-400 dark:text-slate-500 block">{language === 'bn' ? 'অবশিষ্ট বকেয়া ঋণ' : 'Remaining Debt'}</span>
            <span className="text-sm font-extrabold text-rose-600 dark:text-rose-400">
              ৳ {totalActiveLoan.toLocaleString('bn-BD')}
            </span>
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-amber-600/20 transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{language === 'bn' ? 'দায় যুক্ত করুন' : 'Add Liability'}</span>
          </button>
        </div>
      </div>

      {/* Cards List */}
      {filteredLiabilities.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 dark:text-slate-500">
            <WalletCards className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-700 dark:text-slate-200">
            {language === 'bn' ? 'কোন দায়ের তথ্য পাওয়া যায়নি' : 'No liability records found'}
          </h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 max-w-sm mx-auto">
            {language === 'bn'
              ? 'নতুন ঋণ বা দায়ের তথ্য সংরক্ষণ করতে উপরের "দায় যুক্ত করুন" বাটনে ক্লিক করুন।'
              : 'Click the button above to record debt obligations.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredLiabilities.map((item) => {
            const remaining = item.loanAmountBDT - (item.paidAmountBDT || 0);
            const isPaid = item.status === 'পরিশোধিত';

            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-700/60 hover:shadow-md transition-all p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Left Side Info */}
                <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                  <div
                    className={`p-3.5 rounded-2xl shrink-0 border ${
                      isPaid
                        ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                        : 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                    }`}
                  >
                    <WalletCards className="w-6 h-6" />
                  </div>

                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${
                          isPaid
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                            : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                        }`}
                      >
                        {item.status}
                      </span>

                      <h3 className="font-bold text-base text-slate-900 dark:text-white truncate">
                        {item.liabilityReason}
                      </h3>

                      <span className="text-sm font-extrabold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                        ৳ {item.loanAmountBDT.toLocaleString('bn-BD')}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
                      <span className="truncate">{item.creditorName}</span>
                    </p>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 pt-1">
                      {item.incurredDate && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{language === 'bn' ? 'গ্রহণের তারিখ:' : 'Incurred:'}</span>
                          <span className="font-medium text-slate-700 dark:text-slate-200">{item.incurredDate}</span>
                        </span>
                      )}

                      {item.expectedRepaymentDate && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{language === 'bn' ? 'সম্ভাব্য পরিশোধ:' : 'Due Date:'}</span>
                          <span className="font-medium text-slate-700 dark:text-slate-200">{item.expectedRepaymentDate}</span>
                        </span>
                      )}

                      <span className="flex items-center gap-1 font-semibold">
                        <span className="text-slate-600 dark:text-slate-400">{language === 'bn' ? 'অবশিষ্ট পাওনা:' : 'Balance:'}</span>
                        <span className={remaining <= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}>
                          ৳ {remaining > 0 ? remaining.toLocaleString('bn-BD') : '০ (পরিশোধিত)'}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Side: 3 Action buttons */}
                <div className="flex items-center justify-end gap-1.5 shrink-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                  <button
                    onClick={() => setViewingLiability(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-900/70 text-blue-800 dark:text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    <span>{t('show', 'দেখুন')}</span>
                  </button>

                  <button
                    onClick={() => handleOpenEdit(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-900/70 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="তথ্য সংশোধন"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>{t('edit', 'তথ্য সংশোধন')}</span>
                  </button>

                  <button
                    onClick={() => setDeleteCandidate(item)}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/70 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    <span>{t('delete', 'মুছে ফেলুন')}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Modal with exact required fields */}
      {(isAddModalOpen || editingLiability) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[88vh] flex flex-col overflow-hidden border border-slate-100 dark:border-slate-800">
            <div className="bg-gradient-to-r from-slate-900 to-amber-950 px-6 py-4 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white">
                  {editingLiability
                    ? (language === 'bn' ? 'দায়ের তথ্য সংশোধন' : 'Edit Liability Record')
                    : (language === 'bn' ? 'নতুন দায় যুক্ত করুন' : 'Add New Liability')}
                </h3>
                <p className="text-xs text-amber-300">
                  {language === 'bn' ? 'ঋণের উদ্দেশ্য, পরিমাণ ও পরিশোধের তারিখ উল্লেখ করুন' : 'Enter creditor, amount and settlement details'}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingLiability(null);
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-3.5 text-xs">
              {/* যে বাবদ দায় রয়েছে */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'যে বাবদ দায় রয়েছে *' : 'Liability Purpose / Reason *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.liabilityReason}
                  onChange={e => setFormData({ ...formData, liabilityReason: e.target.value })}
                  placeholder="যেমন: গৃহ ঋণ, মোটরসাইকেল লোন, ব্যক্তিগত ধার"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* যে প্রতিষ্ঠান/ব্যক্তির নিকট দায় রয়েছে */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'যে প্রতিষ্ঠান/ব্যক্তির নিকট দায় রয়েছে *' : 'Creditor Name / Institution *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.creditorName}
                  onChange={e => setFormData({ ...formData, creditorName: e.target.value })}
                  placeholder="যেমন: ডাচ-বাংলা ব্যাংক লিমিটেড / জনাব রহিম"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* ঋণের পরিমান (টাকায়) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'ঋণের পরিমান (টাকায়) *' : 'Loan Amount (BDT) *'}
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.loanAmountBDT || ''}
                    onChange={e => setFormData({ ...formData, loanAmountBDT: parseFloat(e.target.value) || 0 })}
                    placeholder="যেমন: ১৮০০০০"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 font-mono focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'পরিশোধিত টাকা (যদি থাকে)' : 'Paid Amount (BDT)'}
                  </label>
                  <input
                    type="number"
                    value={formData.paidAmountBDT || ''}
                    onChange={e => setFormData({ ...formData, paidAmountBDT: parseFloat(e.target.value) || 0 })}
                    placeholder="যেমন: ১৪০০০০"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 font-mono focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* দায় গ্রহনের তারিখ ও সম্ভব্য পরিশোধের তারিখ */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'দায় গ্রহণের তারিখ *' : 'Incurred Date *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.incurredDate}
                    onChange={e => setFormData({ ...formData, incurredDate: e.target.value })}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'bn' ? 'সম্ভাব্য পরিশোধের তারিখ *' : 'Expected Repayment Date *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.expectedRepaymentDate}
                    onChange={e => setFormData({ ...formData, expectedRepaymentDate: e.target.value })}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* বর্তমান স্থিতি */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'বর্তমান স্থিতি *' : 'Current Status *'}
                </label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
                >
                  <option value="চলমান">চলমান (Active)</option>
                  <option value="আংশিক পরিশোধিত">আংশিক পরিশোধিত (Partially Paid)</option>
                  <option value="পরিশোধিত">পরিশোধিত (Fully Settled)</option>
                </select>
              </div>

              <FileUploadInput
                label={language === 'bn' ? 'সংযুক্তি আপলোড / যুক্ত করুন' : 'Upload / Attach Document'}
                value={formData.attachmentUrl || ''}
                onChange={(val) => setFormData({ ...formData, attachmentUrl: val })}
                accept="image/*,application/pdf"
                isImage={false}
                placeholder="https://..."
                helperText={language === 'bn' ? 'চুক্তিপত্র বা লোনের কাগজ আপলোড করুন (ছবি বা পিডিএফ)' : 'Upload loan agreement or debt slip'}
              />

              {/* মন্তব্য */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'মন্তব্য' : 'Remarks'}
                </label>
                <textarea
                  rows={2}
                  value={formData.remarks}
                  onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                  placeholder="কিস্তির বিবরণ বা অন্যান্য তথ্য"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Action buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingLiability(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-md shadow-amber-600/20"
                >
                  <Save className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সংরক্ষণ করুন' : 'Save'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Show Detail Modal */}
      {viewingLiability && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-100 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <WalletCards className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                <span>{viewingLiability.liabilityReason}</span>
              </h3>
              <button onClick={() => setViewingLiability(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">প্রতিষ্ঠান / ব্যক্তি:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{viewingLiability.creditorName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">মোট ঋণের পরিমাণ:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳ {viewingLiability.loanAmountBDT.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">পরিশোধিত অংশ:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">৳ {(viewingLiability.paidAmountBDT || 0).toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">গ্রহণের তারিখ:</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">{viewingLiability.incurredDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">সম্ভাব্য পরিশোধ:</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">{viewingLiability.expectedRepaymentDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">বর্তমান স্ট্যাটাস:</span>
                <span className="font-bold text-amber-800 dark:text-amber-300">{viewingLiability.status}</span>
              </div>
              {viewingLiability.remarks && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-slate-400 block mb-0.5">মন্তব্য:</span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{viewingLiability.remarks}</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingLiability(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-semibold"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full text-center space-y-3">
            <Trash2 className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              {language === 'bn' ? 'দায়ের তথ্য মুছে ফেলতে চান?' : 'Delete Liability?'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              "{deleteCandidate.liabilityReason}" মুছে যাবে।
            </p>
            <div className="flex justify-center gap-2 pt-2">
              <button onClick={() => setDeleteCandidate(null)} className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs">
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  deleteLiability(deleteCandidate.id);
                  setDeleteCandidate(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
              >
                {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
