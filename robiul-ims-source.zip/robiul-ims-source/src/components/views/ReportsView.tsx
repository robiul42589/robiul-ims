import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Users, 
  Landmark, 
  Briefcase
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { 
    userProfile, 
    familyMembers, 
    education, 
    assets, 
    liabilities, 
    employment, 
    exportDataToJson 
  } = useData();
  const { language } = useLanguage();

  const [activeReportTab, setActiveReportTab] = useState<'all' | 'financial' | 'family' | 'career'>('all');

  // Calculations
  const totalPlots = assets.reduce((s, a) => s + (a.plots?.length || 0), 0);
  const totalAssetVal = assets.reduce((s, a) => s + (a.estimatedValueBDT || 0), 0);
  const totalArea = assets.reduce((s, a) => s + (a.plots?.reduce((ps, p) => ps + (parseFloat(p.landArea) || 0), 0) || 0), 0);
  const totalLoanBDT = liabilities.reduce((s, l) => s + l.loanAmountBDT, 0);
  const totalPaidBDT = liabilities.reduce((s, l) => s + (l.paidAmountBDT || 0), 0);
  const totalRemainingDebt = totalLoanBDT - totalPaidBDT;
  const netWorth = totalAssetVal - totalRemainingDebt;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Controls (Hidden during print) */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {language === 'bn' ? 'সকল বিষয়ের সমন্বিত রিপোর্ট' : 'Consolidated Reports & Analytics'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'bn'
                ? 'পরিবার, শিক্ষা, সম্পত্তি, দায় ও চাকুরীর সামগ্রিক প্রতিবেদন প্রস্তুত ও প্রিন্ট করুন'
                : 'Master overview and printable A4 statements'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={exportDataToJson}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span>{language === 'bn' ? 'JSON ব্যাকআপ' : 'Export JSON'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'bn' ? 'রিপোর্ট প্রিন্ট করুন' : 'Print Statement'}</span>
          </button>
        </div>
      </div>

      {/* Report Category Filter Tabs (Hidden during print) */}
      <div className="no-print flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveReportTab('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            activeReportTab === 'all'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {language === 'bn' ? 'পূর্ণাঙ্গ সমন্বিত রিপোর্ট' : 'Master Consolidated'}
        </button>
        <button
          onClick={() => setActiveReportTab('financial')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            activeReportTab === 'financial'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {language === 'bn' ? 'সম্পদ ও দায় ব্যালান্স শিট' : 'Assets vs Liabilities'}
        </button>
        <button
          onClick={() => setActiveReportTab('family')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            activeReportTab === 'family'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {language === 'bn' ? 'পারিবারিক তথ্য বিবরণী' : 'Family Register'}
        </button>
        <button
          onClick={() => setActiveReportTab('career')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            activeReportTab === 'career'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {language === 'bn' ? 'শিক্ষা ও কর্মজীবন (CV)' : 'Education & Career'}
        </button>
      </div>

      {/* Printable Master Report Canvas */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-sm p-6 sm:p-10 space-y-8 text-slate-800 dark:text-slate-100 print:bg-white print:text-black print:border-none">
        {/* Printable Header */}
        <div className="border-b-2 border-slate-900 dark:border-slate-700 print:border-slate-900 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 dark:bg-emerald-600 print:bg-slate-900 text-white font-extrabold text-2xl flex items-center justify-center">
              R
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white print:text-slate-900 tracking-tight">
                {language === 'bn' ? 'রোবিউল ইনফরমেশন ম্যানেজমেন্ট সিস্টেম' : 'Robiul Information Management System'}
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 print:text-slate-600 font-medium">
                {language === 'bn'
                  ? 'ব্যক্তিগত, পারিবারিক, ভূমি ও আর্থিক হিসাবের প্রত্যয়ন প্রতিবেদন'
                  : 'Certified Personal, Family, Land & Financial Registry Statement'}
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-500 dark:text-slate-400 print:text-slate-600">
            <p className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">
              {language === 'bn' ? 'প্রতিবেদন তৈরির তারিখ:' : 'Generated Date:'}
            </p>
            <p className="font-mono">{new Date().toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}</p>
          </div>
        </div>

        {/* User Biodata Section */}
        <div className="print-break-inside-avoid p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 print:bg-slate-50 border border-slate-200/80 dark:border-slate-800">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 print:text-slate-600 mb-3 flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{language === 'bn' ? '১. মূল অ্যাকাউন্ট ব্যবহারকারীর পরিচিতি' : '1. Primary Profile Information'}</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'নাম (বাংলা)' : 'Name (Bangla)'}</span>
              <span className="font-bold text-slate-900 dark:text-white print:text-slate-900">{userProfile.nameBn}</span>
            </div>
            <div>
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'নাম (ইংরেজি)' : 'Name (English)'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">{userProfile.nameEn}</span>
            </div>
            <div>
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'জাতীয় পরিচয় পত্র (NID)' : 'National ID'}</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white print:text-slate-900">{userProfile.nid}</span>
            </div>
            <div>
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'রক্তের গ্রুপ ও জন্ম তারিখ' : 'Blood & DoB'}</span>
              <span className="font-bold text-slate-900 dark:text-white print:text-slate-900">{userProfile.bloodGroup} | {userProfile.dob}</span>
            </div>
            <div className="col-span-2">
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'বর্তমান পদবী ও কর্মসংস্থান' : 'Designation'}</span>
              <span className="font-semibold text-emerald-700 dark:text-emerald-400 print:text-emerald-700">{userProfile.designation}</span>
            </div>
            <div className="col-span-2">
              <span className="text-slate-400 dark:text-slate-500 block text-[11px]">{language === 'bn' ? 'স্থায়ী ঠিকানা' : 'Address'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">
                গ্রাম: {userProfile.address.village}, ডাকঘর: {userProfile.address.postOffice} ({userProfile.address.postalCode}), উপজেলা: {userProfile.address.upazila}, জেলা: {userProfile.address.district}
              </span>
            </div>
          </div>
        </div>

        {/* Financial Assets & Liabilities Balance Sheet */}
        {(activeReportTab === 'all' || activeReportTab === 'financial') && (
          <div className="print-break-inside-avoid space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 print:text-slate-600 flex items-center gap-2">
              <Landmark className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>{language === 'bn' ? '২. সম্পদ ও দায় বিবরণী (Assets & Liabilities Balance Sheet)' : '2. Balance Sheet'}</span>
            </h3>

            {/* Financial summary numbers */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 rounded-xl border border-teal-200 dark:border-teal-900/50 bg-teal-50/50 dark:bg-teal-950/30 print:bg-teal-50">
                <span className="text-teal-800 dark:text-teal-300 block text-[11px]">{language === 'bn' ? 'মোট জমি (শতক)' : 'Total Land'}</span>
                <span className="text-lg font-bold text-teal-950 dark:text-teal-100 print:text-teal-950">{totalArea.toFixed(1)} শতক ({totalPlots}টি দাগ)</span>
              </div>
              <div className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900/50 bg-emerald-50/50 dark:bg-emerald-950/30 print:bg-emerald-50">
                <span className="text-emerald-800 dark:text-emerald-300 block text-[11px]">{language === 'bn' ? 'প্রাক্কলিত মোট সম্পদ' : 'Total Asset Value'}</span>
                <span className="text-lg font-bold text-emerald-950 dark:text-emerald-100 print:text-emerald-950">৳ {totalAssetVal.toLocaleString('bn-BD')}</span>
              </div>
              <div className="p-3.5 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/30 print:bg-rose-50">
                <span className="text-rose-800 dark:text-rose-300 block text-[11px]">{language === 'bn' ? 'অবশিষ্ট বকেয়া দায়' : 'Remaining Debts'}</span>
                <span className="text-lg font-bold text-rose-950 dark:text-rose-100 print:text-rose-950">৳ {totalRemainingDebt.toLocaleString('bn-BD')}</span>
              </div>
              <div className="p-3.5 rounded-xl border border-slate-900 dark:border-slate-700 bg-slate-900 dark:bg-slate-800 text-white print:bg-slate-900">
                <span className="text-slate-300 block text-[11px]">{language === 'bn' ? 'নেট সম্পদ (Net Worth)' : 'Net Worth'}</span>
                <span className="text-lg font-bold text-emerald-400">৳ {netWorth.toLocaleString('bn-BD')}</span>
              </div>
            </div>

            {/* Land Assets detail table */}
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">মৌজা ও জেএল</th>
                    <th className="p-2.5">খতিয়ান ও হোল্ডিং</th>
                    <th className="p-2.5">মালিকানা অংশ</th>
                    <th className="p-2.5">দাগ নম্বর ও শ্রেণী</th>
                    <th className="p-2.5">পরিমাণ</th>
                    <th className="p-2.5 text-right">মূল্য (টাকা)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {assets.map((ast) => (
                    <tr key={ast.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold text-slate-900 dark:text-white print:text-slate-900">
                        {ast.mouza} <span className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">(জেএল: {ast.jlNo})</span>
                      </td>
                      <td className="p-2.5 font-mono text-slate-800 dark:text-slate-200">
                        {ast.khatianNo} / {ast.holdingNo}
                      </td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-300">
                        {ast.owners?.map(o => `${o.name} (${o.share})`).join(', ')}
                      </td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-300">
                        {ast.plots?.map(p => `${p.dagPlotNo} - ${p.landCategory}`).join('; ')}
                      </td>
                      <td className="p-2.5 font-bold text-teal-800 dark:text-teal-300">
                        {ast.plots?.map(p => `${p.landArea} ${p.unit}`).join(', ')}
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold text-slate-900 dark:text-white print:text-slate-900">
                        ৳ {ast.estimatedValueBDT?.toLocaleString('bn-BD')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Liabilities Detail Table */}
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">দায়ের বিবরণ</th>
                    <th className="p-2.5">প্রতিষ্ঠান / ব্যক্তি</th>
                    <th className="p-2.5">গ্রহণের তারিখ</th>
                    <th className="p-2.5">সম্ভাব্য পরিশোধ</th>
                    <th className="p-2.5">মূল ঋণ</th>
                    <th className="p-2.5">অবশিষ্ট দেনা</th>
                    <th className="p-2.5">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {liabilities.map((lia) => (
                    <tr key={lia.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold text-slate-900 dark:text-white print:text-slate-900">{lia.liabilityReason}</td>
                      <td className="p-2.5 text-slate-800 dark:text-slate-200">{lia.creditorName}</td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-300">{lia.incurredDate}</td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-300">{lia.expectedRepaymentDate}</td>
                      <td className="p-2.5 font-mono text-slate-800 dark:text-slate-200">৳ {lia.loanAmountBDT.toLocaleString('bn-BD')}</td>
                      <td className="p-2.5 font-mono font-bold text-rose-600 dark:text-rose-400">
                        ৳ {(lia.loanAmountBDT - (lia.paidAmountBDT || 0)).toLocaleString('bn-BD')}
                      </td>
                      <td className="p-2.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          lia.status === 'পরিশোধিত' 
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' 
                            : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                        }`}>
                          {lia.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Family Registry Section */}
        {(activeReportTab === 'all' || activeReportTab === 'family') && (
          <div className="print-break-inside-avoid space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 print:text-slate-600 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{language === 'bn' ? '৩. পরিবার পরিচিতি রেজিস্টার' : '3. Family Register'}</span>
            </h3>

            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">সদস্যের নাম</th>
                    <th className="p-2.5">সম্পর্ক</th>
                    <th className="p-2.5">পিতা ও মাতা</th>
                    <th className="p-2.5">জন্ম তারিখ</th>
                    <th className="p-2.5">জাতীয় পরিচয় পত্র (NID)</th>
                    <th className="p-2.5">জন্ম নিবন্ধন</th>
                    <th className="p-2.5">ঠিকানা</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {familyMembers.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold text-slate-900 dark:text-white print:text-slate-900">
                        {m.nameBn} <span className="text-[10px] text-slate-400 dark:text-slate-500 block font-normal">{m.nameEn}</span>
                      </td>
                      <td className="p-2.5">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold">
                          {m.relation}
                        </span>
                      </td>
                      <td className="p-2.5 text-[11px] text-slate-600 dark:text-slate-300">
                        {m.fatherNameBn} <br /> {m.motherNameBn}
                      </td>
                      <td className="p-2.5 text-slate-700 dark:text-slate-300">{m.dob}</td>
                      <td className="p-2.5 font-mono text-slate-800 dark:text-slate-200">{m.nidNo || 'নেই'}</td>
                      <td className="p-2.5 font-mono text-slate-800 dark:text-slate-200">{m.birthRegNo || 'নেই'}</td>
                      <td className="p-2.5 text-[11px] text-slate-700 dark:text-slate-300">
                        {m.village}, {m.upazila}, {m.district}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Education & Employment History Section */}
        {(activeReportTab === 'all' || activeReportTab === 'career') && (
          <div className="print-break-inside-avoid space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 print:text-slate-600 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>{language === 'bn' ? '৪. শিক্ষাগত যোগ্যতা ও চাকুরীর জীবনবৃত্তান্ত' : '4. Career & Qualifications'}</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Education list */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 print:bg-slate-50 space-y-2.5">
                <h4 className="font-bold text-xs uppercase text-slate-500 dark:text-slate-400">শিক্ষাগত সনদ সমূহ</h4>
                <div className="space-y-2">
                  {education.map((e) => (
                    <div key={e.id} className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-xs">
                      <div className="flex justify-between font-bold text-slate-900 dark:text-white print:text-slate-900">
                        <span>{e.examName} ({e.passingYear})</span>
                        <span className="text-emerald-700 dark:text-emerald-400">জিপিএ: {e.gpa}</span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">{e.institutionName} - {e.boardUniversity}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Employment list */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 print:bg-slate-50 space-y-2.5">
                <h4 className="font-bold text-xs uppercase text-slate-500 dark:text-slate-400">চাকুরীর অভিজ্ঞতা ও বর্তমান পদবী</h4>
                <div className="space-y-2">
                  {employment.map((job) => (
                    <div key={job.id} className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-xs">
                      <div className="flex justify-between font-bold text-slate-900 dark:text-white print:text-slate-900">
                        <span>{job.designation}</span>
                        <span className="text-purple-700 dark:text-purple-400 text-[10px]">{job.isCurrent ? 'বর্তমান' : job.releaseDate}</span>
                      </div>
                      <p className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mt-0.5">{job.companyName}</p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">যোগদান: {job.joiningDate}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Verification and signature block for official print */}
        <div className="print-break-inside-avoid pt-12 mt-8 border-t border-slate-200 dark:border-slate-800 print:border-slate-300 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 print:text-slate-600">
          <div>
            <p className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">স্বত্বাধিকারীর স্বাক্ষর ও তারিখ</p>
            <div className="w-48 h-0.5 bg-slate-400 dark:bg-slate-600 print:bg-slate-400 mt-8 mb-1"></div>
            <p className="font-bold text-slate-900 dark:text-white print:text-slate-900">মোঃ রোবিউল ইসলাম</p>
          </div>

          <div className="text-right">
            <p className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">সিস্টেম ভেরিফিকেশন কোড</p>
            <p className="font-mono text-slate-400 dark:text-slate-500 print:text-slate-500 mt-1">IMS-VERIFIED-{Date.now().toString(36).toUpperCase()}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
