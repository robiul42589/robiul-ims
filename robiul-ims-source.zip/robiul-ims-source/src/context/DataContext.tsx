import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  UserProfile, 
  FamilyMember, 
  EducationItem, 
  SkillItem, 
  AssetItem, 
  LiabilityItem, 
  EmploymentItem, 
  ActivityLog, 
  ToastMessage, 
  ToastType 
} from '../types';
import { 
  initialUserProfile, 
  initialFamilyMembers, 
  initialEducation, 
  initialSkills, 
  initialAssets, 
  initialLiabilities, 
  initialEmployment, 
  initialActivities 
} from '../data/initialData';

interface DataContextType {
  // Auth
  isAuthenticated: boolean;
  login: (idOrEmail: string, pass: string) => boolean;
  logout: () => void;

  // Profile
  userProfile: UserProfile;
  updateUserProfile: (profile: Partial<UserProfile>) => void;

  // Family
  familyMembers: FamilyMember[];
  addFamilyMember: (member: Omit<FamilyMember, 'id' | 'createdAt'>) => void;
  updateFamilyMember: (id: string, member: Partial<FamilyMember>) => void;
  deleteFamilyMember: (id: string) => void;

  // Education
  education: EducationItem[];
  addEducation: (edu: Omit<EducationItem, 'id' | 'createdAt'>) => void;
  updateEducation: (id: string, edu: Partial<EducationItem>) => void;
  deleteEducation: (id: string) => void;

  // Skills
  skills: SkillItem[];
  addSkill: (skill: Omit<SkillItem, 'id' | 'createdAt'>) => void;
  updateSkill: (id: string, skill: Partial<SkillItem>) => void;
  deleteSkill: (id: string) => void;

  // Assets
  assets: AssetItem[];
  addAsset: (asset: Omit<AssetItem, 'id' | 'createdAt'>) => void;
  updateAsset: (id: string, asset: Partial<AssetItem>) => void;
  deleteAsset: (id: string) => void;

  // Liabilities
  liabilities: LiabilityItem[];
  addLiability: (liability: Omit<LiabilityItem, 'id' | 'createdAt'>) => void;
  updateLiability: (id: string, liability: Partial<LiabilityItem>) => void;
  deleteLiability: (id: string) => void;

  // Employment
  employment: EmploymentItem[];
  addEmployment: (emp: Omit<EmploymentItem, 'id' | 'createdAt'>) => void;
  updateEmployment: (id: string, emp: Partial<EmploymentItem>) => void;
  deleteEmployment: (id: string) => void;

  // Logs & Data Center
  activityLogs: ActivityLog[];
  exportDataToJson: () => void;
  importDataFromJson: (jsonStr: string) => boolean;
  resetToDemoData: () => void;

  // Toasts
  toasts: ToastMessage[];
  showToast: (type: ToastType, title: string, message: string) => void;
  removeToast: (id: string) => void;

  // Search & Navigation
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const STORAGE_KEY = 'robiul_ims_data_v2';
const AUTH_KEY = 'robiul_ims_auth_v2';

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem(AUTH_KEY) === 'true';
  });

  // Navigation state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>('');

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const showToast = useCallback((type: ToastType, title: string, message: string) => {
    const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  }, [removeToast]);

  // Main stored state
  const [userProfile, setUserProfile] = useState<UserProfile>(initialUserProfile);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(initialFamilyMembers);
  const [education, setEducation] = useState<EducationItem[]>(initialEducation);
  const [skills, setSkills] = useState<SkillItem[]>(initialSkills);
  const [assets, setAssets] = useState<AssetItem[]>(initialAssets);
  const [liabilities, setLiabilities] = useState<LiabilityItem[]>(initialLiabilities);
  const [employment, setEmployment] = useState<EmploymentItem[]>(initialEmployment);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(initialActivities);

  // Load from local storage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.userProfile) setUserProfile(parsed.userProfile);
        if (parsed.familyMembers) setFamilyMembers(parsed.familyMembers);
        if (parsed.education) setEducation(parsed.education);
        if (parsed.skills) setSkills(parsed.skills);
        if (parsed.assets) setAssets(parsed.assets);
        if (parsed.liabilities) setLiabilities(parsed.liabilities);
        if (parsed.employment) setEmployment(parsed.employment);
        if (parsed.activityLogs) setActivityLogs(parsed.activityLogs);
      }
    } catch (e) {
      console.error('Failed to load IMS data from localStorage', e);
    }
  }, []);

  // Save to local storage whenever state changes
  useEffect(() => {
    try {
      const dataToSave = {
        userProfile,
        familyMembers,
        education,
        skills,
        assets,
        liabilities,
        employment,
        activityLogs,
        lastSaved: new Date().toISOString()
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    } catch (e) {
      console.error('Failed to persist IMS data to localStorage', e);
    }
  }, [userProfile, familyMembers, education, skills, assets, liabilities, employment, activityLogs]);

  // Activity logger helper
  const addLog = useCallback((
    action: ActivityLog['action'], 
    module: ActivityLog['module'], 
    descriptionBn: string, 
    descriptionEn: string
  ) => {
    const newLog: ActivityLog = {
      id: 'act_' + Date.now(),
      action,
      module,
      descriptionBn,
      descriptionEn,
      timestamp: new Date().toISOString()
    };
    setActivityLogs(prev => [newLog, ...prev.slice(0, 49)]);
  }, []);

  // Auth methods
  const login = (idOrEmail: string, pass: string): boolean => {
    const cleanId = idOrEmail.trim().toLowerCase();
    const cleanPass = pass.trim();
    // Demo credentials: robiul / 123456 or nrrobiulislamhridoy@gmail.com / admin123 or similar
    if ((cleanId === 'robiul' || cleanId === 'admin' || cleanId.includes('robiul')) && cleanPass.length >= 4) {
      setIsAuthenticated(true);
      localStorage.setItem(AUTH_KEY, 'true');
      showToast('success', 'স্বাগতম!', 'আপনার ড্যাশবোর্ডে সফলভাবে লগইন করা হয়েছে।');
      addLog('auth', 'সিস্টেম', 'ইউজার সফলভাবে লগইন করেছেন।', 'User logged in successfully.');
      return true;
    } else if (cleanId && cleanPass) {
      // Allow flexible demo login
      setIsAuthenticated(true);
      localStorage.setItem(AUTH_KEY, 'true');
      showToast('success', 'স্বাগতম!', 'আপনার ড্যাশবোর্ডে সফলভাবে লগইন করা হয়েছে।');
      addLog('auth', 'সিস্টেম', 'ইউজার সফলভাবে লগইন করেছেন।', 'User logged in successfully.');
      return true;
    }
    showToast('error', 'লগইন ব্যর্থ', 'সঠিক আইডি বা পাসওয়ার্ড প্রদান করুন।');
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(AUTH_KEY);
    showToast('info', 'লগআউট সম্পন্ন', 'আপনি সফলভাবে সিস্টেম থেকে লগআউট করেছেন।');
    addLog('auth', 'সিস্টেম', 'ইউজার লগআউট সম্পন্ন করেছেন।', 'User logged out.');
  };

  // User Profile
  const updateUserProfile = (profileUpdate: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...profileUpdate }));
    showToast('success', 'প্রোফাইল আপডেট', 'আপনার প্রোফাইল তথ্য সফলভাবে সংরক্ষণ করা হয়েছে।');
    addLog('update', 'প্রোফাইল', 'ইউজারের প্রোফাইল তথ্য সংশোধন করা হয়েছে।', 'User profile details updated.');
  };

  // Family Members
  const addFamilyMember = (member: Omit<FamilyMember, 'id' | 'createdAt'>) => {
    const newMember: FamilyMember = {
      ...member,
      id: 'fam_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setFamilyMembers(prev => [newMember, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'পারিবারিক সদস্যের তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'পরিবার', `পরিবারের নতুন সদস্য (${member.nameBn}) এর তথ্য যুক্ত করা হয়েছে।`, `Added new family member: ${member.nameEn || member.nameBn}`);
  };

  const updateFamilyMember = (id: string, updated: Partial<FamilyMember>) => {
    setFamilyMembers(prev => prev.map(m => m.id === id ? { ...m, ...updated, updatedAt: new Date().toISOString() } : m));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'সদস্যের তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'পরিবার', `সদস্যের তথ্য হালনাগাদ করা হয়েছে।`, `Updated family member details.`);
  };

  const deleteFamilyMember = (id: string) => {
    const target = familyMembers.find(m => m.id === id);
    setFamilyMembers(prev => prev.filter(m => m.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'সদস্যের তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'পরিবার', `পরিবারের সদস্য (${target?.nameBn || ''}) এর তথ্য মুছে ফেলা হয়েছে।`, `Deleted family member.`);
  };

  // Education
  const addEducation = (edu: Omit<EducationItem, 'id' | 'createdAt'>) => {
    const newEdu: EducationItem = {
      ...edu,
      id: 'edu_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setEducation(prev => [newEdu, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'শিক্ষাগত যোগ্যতার তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'শিক্ষা', `শিক্ষাগত তথ্য (${edu.examName}) যুক্ত করা হয়েছে।`, `Added education: ${edu.examName}`);
  };

  const updateEducation = (id: string, updated: Partial<EducationItem>) => {
    setEducation(prev => prev.map(e => e.id === id ? { ...e, ...updated } : e));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'শিক্ষাগত তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'শিক্ষা', `শিক্ষাগত যোগ্যতা সংশোধন করা হয়েছে।`, `Updated education entry.`);
  };

  const deleteEducation = (id: string) => {
    const target = education.find(e => e.id === id);
    setEducation(prev => prev.filter(e => e.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'শিক্ষাগত তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'শিক্ষা', `শিক্ষাগত তথ্য (${target?.examName || ''}) মুছে ফেলা হয়েছে।`, `Deleted education entry.`);
  };

  // Skills
  const addSkill = (skill: Omit<SkillItem, 'id' | 'createdAt'>) => {
    const newSkill: SkillItem = {
      ...skill,
      id: 'skl_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setSkills(prev => [newSkill, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'নতুন দক্ষতার তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'দক্ষতা', `দক্ষতা (${skill.skillName}) যুক্ত করা হয়েছে।`, `Added skill: ${skill.skillName}`);
  };

  const updateSkill = (id: string, updated: Partial<SkillItem>) => {
    setSkills(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'দক্ষতার তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'দক্ষতা', `দক্ষতার তথ্য হালনাগাদ করা হয়েছে।`, `Updated skill entry.`);
  };

  const deleteSkill = (id: string) => {
    const target = skills.find(s => s.id === id);
    setSkills(prev => prev.filter(s => s.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'দক্ষতার তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'দক্ষতা', `দক্ষতা (${target?.skillName || ''}) মুছে ফেলা হয়েছে।`, `Deleted skill entry.`);
  };

  // Assets
  const addAsset = (asset: Omit<AssetItem, 'id' | 'createdAt'>) => {
    const newAsset: AssetItem = {
      ...asset,
      id: 'ast_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setAssets(prev => [newAsset, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'সম্পদ ও জমির তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'সম্পদ', `মৌজা ${asset.mouza}, খতিয়ান নং ${asset.khatianNo} এর তথ্য যুক্ত করা হয়েছে।`, `Added asset record for Mouza ${asset.mouza}`);
  };

  const updateAsset = (id: string, updated: Partial<AssetItem>) => {
    setAssets(prev => prev.map(a => a.id === id ? { ...a, ...updated } : a));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'সম্পদের তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'সম্পদ', `সম্পদের বিবরণ সংশোধন করা হয়েছে।`, `Updated asset entry.`);
  };

  const deleteAsset = (id: string) => {
    const target = assets.find(a => a.id === id);
    setAssets(prev => prev.filter(a => a.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'সম্পদের তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'সম্পদ', `সম্পদের তথ্য (খতিয়ান ${target?.khatianNo || ''}) মুছে ফেলা হয়েছে।`, `Deleted asset entry.`);
  };

  // Liabilities
  const addLiability = (liability: Omit<LiabilityItem, 'id' | 'createdAt'>) => {
    const newLiability: LiabilityItem = {
      ...liability,
      id: 'lia_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setLiabilities(prev => [newLiability, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'দায়ের তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'দায়', `দায় বিবরণী (${liability.liabilityReason}) যুক্ত করা হয়েছে।`, `Added liability: ${liability.liabilityReason}`);
  };

  const updateLiability = (id: string, updated: Partial<LiabilityItem>) => {
    setLiabilities(prev => prev.map(l => l.id === id ? { ...l, ...updated } : l));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'দায়ের তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'দায়', `দায়ের তথ্য হালনাগাদ করা হয়েছে।`, `Updated liability entry.`);
  };

  const deleteLiability = (id: string) => {
    const target = liabilities.find(l => l.id === id);
    setLiabilities(prev => prev.filter(l => l.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'দায়ের তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'দায়', `দায় (${target?.liabilityReason || ''}) মুছে ফেলা হয়েছে।`, `Deleted liability entry.`);
  };

  // Employment
  const addEmployment = (emp: Omit<EmploymentItem, 'id' | 'createdAt'>) => {
    const newEmp: EmploymentItem = {
      ...emp,
      id: 'emp_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    setEmployment(prev => [newEmp, ...prev]);
    showToast('success', 'সফল হয়েছে!', 'চাকুরীর তথ্য সফলভাবে যুক্ত করা হয়েছে।');
    addLog('create', 'চাকুরী', `চাকুরীর তথ্য (${emp.companyName} - ${emp.designation}) যুক্ত করা হয়েছে।`, `Added job history: ${emp.companyName}`);
  };

  const updateEmployment = (id: string, updated: Partial<EmploymentItem>) => {
    setEmployment(prev => prev.map(e => e.id === id ? { ...e, ...updated } : e));
    showToast('success', 'হালনাগাদ সম্পন্ন!', 'চাকুরীর তথ্য সফলভাবে সংশোধন করা হয়েছে।');
    addLog('update', 'চাকুরী', `চাকুরীর ইতিহাস হালনাগাদ করা হয়েছে।`, `Updated employment history.`);
  };

  const deleteEmployment = (id: string) => {
    const target = employment.find(e => e.id === id);
    setEmployment(prev => prev.filter(e => e.id !== id));
    showToast('warning', 'মুছে ফেলা হয়েছে!', 'চাকুরীর তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
    addLog('delete', 'চাকুরী', `চাকুরীর তথ্য (${target?.companyName || ''}) মুছে ফেলা হয়েছে।`, `Deleted job history.`);
  };

  // Data Center Export & Import
  const exportDataToJson = () => {
    try {
      const data = {
        app: 'Robiul Information Management System',
        version: '2.0',
        exportedAt: new Date().toISOString(),
        userProfile,
        familyMembers,
        education,
        skills,
        assets,
        liabilities,
        employment,
        activityLogs
      };
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `robiul_ims_backup_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showToast('success', 'ব্যাকআপ ডাউনলোড', 'আপনার সকল তথ্যের ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে।');
      addLog('backup', 'সিস্টেম', 'ডাটাবেজের পূর্ণাঙ্গ JSON ব্যাকআপ ডাউনলোড করা হয়েছে।', 'Downloaded JSON database backup.');
    } catch (e) {
      console.error(e);
      showToast('error', 'ত্রুটি', 'ব্যাকআপ ফাইল তৈরিতে সমস্যা হয়েছে।');
    }
  };

  const importDataFromJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.userProfile) setUserProfile(parsed.userProfile);
      if (Array.isArray(parsed.familyMembers)) setFamilyMembers(parsed.familyMembers);
      if (Array.isArray(parsed.education)) setEducation(parsed.education);
      if (Array.isArray(parsed.skills)) setSkills(parsed.skills);
      if (Array.isArray(parsed.assets)) setAssets(parsed.assets);
      if (Array.isArray(parsed.liabilities)) setLiabilities(parsed.liabilities);
      if (Array.isArray(parsed.employment)) setEmployment(parsed.employment);
      if (Array.isArray(parsed.activityLogs)) setActivityLogs(parsed.activityLogs);

      showToast('success', 'ডাটা রিস্টোর সম্পন্ন!', 'আপনার ব্যাকআপ থেকে সকল তথ্য সফলভাবে পুনরুদ্ধার করা হয়েছে।');
      addLog('backup', 'সিস্টেম', 'JSON ফাইল থেকে ডাটাবেজ পুনরুদ্ধার করা হয়েছে।', 'Restored database from JSON backup.');
      return true;
    } catch (e) {
      console.error('Import error', e);
      showToast('error', 'ব্যর্থ হয়েছে', 'ভুল ফরম্যাটের ফাইল। অনুগ্রহ করে সঠিক JSON ব্যাকআপ ফাইল নির্বাচন করুন।');
      return false;
    }
  };

  const resetToDemoData = () => {
    setUserProfile(initialUserProfile);
    setFamilyMembers(initialFamilyMembers);
    setEducation(initialEducation);
    setSkills(initialSkills);
    setAssets(initialAssets);
    setLiabilities(initialLiabilities);
    setEmployment(initialEmployment);
    setActivityLogs(initialActivities);
    localStorage.removeItem(STORAGE_KEY);
    showToast('info', 'রিসেট সম্পন্ন', 'সিস্টেমের সকল তথ্য প্রাথমিক ডেমো অবস্থায় ফিরিয়ে নেওয়া হয়েছে।');
    addLog('backup', 'সিস্টেম', 'সিস্টেমের তথ্য প্রাথমিক ডেমো অবস্থায় রিসেট করা হয়েছে।', 'Reset system to default demo data.');
  };

  return (
    <DataContext.Provider value={{
      isAuthenticated,
      login,
      logout,
      userProfile,
      updateUserProfile,
      familyMembers,
      addFamilyMember,
      updateFamilyMember,
      deleteFamilyMember,
      education,
      addEducation,
      updateEducation,
      deleteEducation,
      skills,
      addSkill,
      updateSkill,
      deleteSkill,
      assets,
      addAsset,
      updateAsset,
      deleteAsset,
      liabilities,
      addLiability,
      updateLiability,
      deleteLiability,
      employment,
      addEmployment,
      updateEmployment,
      deleteEmployment,
      activityLogs,
      exportDataToJson,
      importDataFromJson,
      resetToDemoData,
      toasts,
      showToast,
      removeToast,
      globalSearchQuery,
      setGlobalSearchQuery,
      activeTab,
      setActiveTab
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
