import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string, defaultText?: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  bn: {
    // Nav & General
    appTitle: 'রবিউল - ইনফরমেশন ম্যানেজমেন্ট সিস্টেম',
    appShortTitle: 'রবিউল IMS',
    dashboard: 'ড্যাশবোর্ড',
    family: 'পরিবার পরিচিতি',
    educationSkills: 'শিক্ষা ও দক্ষতা',
    assets: 'সম্পদ বিবরণী',
    liabilities: 'দায় সমূহ',
    employment: 'চাকুরীর ইতিহাস',
    reports: 'রিপোর্ট',
    dataCenter: 'ক্লাউড সিঙ্ক / ডাটা সেন্টার',
    userGuide: 'ব্যবহার নির্দেশিকা',
    userInfo: 'ব্যবহারকারীর তথ্য',
    viewProfile: 'ইউজারের তথ্য দেখুন',
    logout: 'লগআউট',
    login: 'লগইন',
    welcomeBack: 'স্বাগতম, মোঃ রবিউল ইসলাম',
    searchPlaceholder: 'যেকোনো তথ্য খুঁজুন (নাম, মৌজা, খতিয়ান, প্রতিষ্ঠান)...',

    // Actions
    show: 'দেখুন',
    edit: 'তথ্য সংশোধন',
    delete: 'মুছে ফেলুন',
    add: 'যুক্ত করুন',
    save: 'সংরক্ষণ করুন',
    cancel: 'বাতিল',
    confirm: 'নিশ্চিত করুন',
    close: 'বন্ধ করুন',
    print: 'প্রিন্ট রিপোর্ট',
    exportJson: 'ব্যাকআপ ডাউনলোড',
    importJson: 'ডাটা রিস্টোর',
    search: 'অনুসন্ধান',
    actions: 'অ্যাকশন',
    upload: 'ফাইল সংযুক্ত করুন',
    preview: 'প্রিভিউ',
    download: 'ডাউনলোড',

    // Toast & Confirmations
    itemAddedSuccess: 'আপনার তথ্য সফলভাবে যুক্ত করা হয়েছে!',
    itemUpdatedSuccess: 'আপনার তথ্য সফলভাবে সংশোধন করা হয়েছে!',
    itemDeletedSuccess: 'তথ্যটি সফলভাবে মুছে ফেলা হয়েছে!',
    loginSuccess: 'সফলভাবে লগইন হয়েছে। আপনার ড্যাশবোর্ডে স্বাগতম!',
    logoutSuccess: 'সফলভাবে লগআউট সম্পন্ন হয়েছে। আবার আসবেন!',
    confirmDeleteTitle: 'আপনি কি নিশ্চিত?',
    confirmDeleteMsg: 'এই তথ্যটি স্থায়ীভাবে মুছে ফেলা হবে। আপনি কি এগিয়ে যেতে চান?',

    // Module titles
    addFamilyMember: 'পরিবারের সদস্য যুক্ত করুন',
    editFamilyMember: 'সদস্যের তথ্য সংশোধন',
    addEducation: 'শিক্ষাগত যোগ্যতা যুক্ত করুন',
    addSkill: 'দক্ষতা যুক্ত করুন',
    addAsset: 'সম্পদের তথ্য যুক্ত করুন',
    addLiability: 'দায় যুক্ত করুন',
    addEmployment: 'চাকুরীর তথ্য যুক্ত করুন',

    // AI & Guide
    aiAssistant: 'এআই সহকারী',
    aiDescription: 'রবিউল IMS এর তথ্য অনুসন্ধান ও সহায়তা সেবা',
    askAi: 'এআইকে জিজ্ঞেস করুন...',
    syncSuccess: 'সকল তথ্য ডিভাইসে সংরক্ষিত ও সুরক্ষিত রয়েছে'
  },
  en: {
    // Nav & General
    appTitle: 'Robiul - Information Management System',
    appShortTitle: 'Robiul IMS',
    dashboard: 'Dashboard',
    family: 'Family Profile',
    educationSkills: 'Education & Skills',
    assets: 'Asset & Land Statement',
    liabilities: 'Liabilities & Debts',
    employment: 'Employment History',
    reports: 'Reports & Analytics',
    dataCenter: 'Cloud Sync / Data Center',
    userGuide: 'User Guide',
    userInfo: 'User Info',
    viewProfile: 'View User Profile',
    logout: 'Logout',
    login: 'Login',
    welcomeBack: 'Welcome back, Md. Robiul Islam',
    searchPlaceholder: 'Search anything (name, mouza, degree, job)...',

    // Actions
    show: 'Show',
    edit: 'Edit Info',
    delete: 'Delete',
    add: 'Add',
    save: 'Save Changes',
    cancel: 'Cancel',
    confirm: 'Confirm',
    close: 'Close',
    print: 'Print Report',
    exportJson: 'Download Backup',
    importJson: 'Restore Data',
    search: 'Search',
    actions: 'Actions',
    upload: 'Attach File',
    preview: 'Preview',
    download: 'Download',

    // Toast & Confirmations
    itemAddedSuccess: 'Your information has been successfully added!',
    itemUpdatedSuccess: 'Your information has been successfully updated!',
    itemDeletedSuccess: 'The item has been deleted successfully!',
    loginSuccess: 'Logged in successfully. Welcome to your dashboard!',
    logoutSuccess: 'Logged out successfully. See you again!',
    confirmDeleteTitle: 'Are you sure?',
    confirmDeleteMsg: 'This record will be permanently removed. Do you want to proceed?',

    // Module titles
    addFamilyMember: 'Add Family Member',
    editFamilyMember: 'Edit Family Member',
    addEducation: 'Add Education Qualification',
    addSkill: 'Add Skill',
    addAsset: 'Add Asset & Land Info',
    addLiability: 'Add Liability / Loan',
    addEmployment: 'Add Employment Record',

    // AI & Guide
    aiAssistant: 'AI Assistant',
    aiDescription: 'Smart AI guidance and information assistant for Robiul IMS',
    askAi: 'Ask AI assistant...',
    syncSuccess: 'All data is locally synced and safely stored'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('robiul_ims_lang');
    return (saved === 'en' || saved === 'bn') ? saved : 'bn';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('robiul_ims_lang', lang);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'bn' ? 'en' : 'bn');
  };

  const t = (key: string, defaultText?: string): string => {
    if (translations[language] && translations[language][key]) {
      return translations[language][key];
    }
    if (translations.bn[key]) {
      return translations.bn[key];
    }
    return defaultText || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
