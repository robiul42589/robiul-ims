import { 
  UserProfile, 
  FamilyMember, 
  EducationItem, 
  SkillItem, 
  AssetItem, 
  LiabilityItem, 
  EmploymentItem,
  ActivityLog 
} from '../types';

export const initialUserProfile: UserProfile = {
  id: 'usr_robiul_01',
  nameBn: 'মোঃ রোবিউল ইসলাম',
  nameEn: 'Md. Robiul Islam',
  email: 'nrrobiulislamhridoy@gmail.com',
  phone: '+880 1700-123456',
  designation: 'ইনফরমেশন অফিসার ও সফটওয়্যার স্পেশালিস্ট',
  bio: 'পেশাগত জীবনে তথ্য প্রযুক্তি, ডাটা ম্যানেজমেন্ট ও উন্নয়নমূলক কাজের প্রতি নিবেদিত। ব্যক্তিগত ও পারিবারিক তথ্যাদি সুশৃঙ্খলভাবে সংরক্ষণে বিশ্বাসী।',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  nid: '19952692512000458',
  dob: '1995-10-15',
  bloodGroup: 'B+',
  address: {
    village: 'গোবিন্দপুর',
    postOffice: 'পাকশী',
    postalCode: '৬৬২০',
    upazila: 'ঈশ্বরদী',
    district: 'পাবনা'
  }
};

export const initialFamilyMembers: FamilyMember[] = [
  {
    id: 'fam_01',
    nameBn: 'মোঃ রোবিউল ইসলাম',
    nameEn: 'Md. Robiul Islam',
    dob: '1995-10-15',
    fatherNameBn: 'মোঃ রফিকুল ইসলাম',
    motherNameBn: 'মোছাঃ রোকেয়া বেগম',
    birthRegNo: '19957612345000123',
    nidNo: '19952692512000458',
    village: 'গোবিন্দপুর',
    postOffice: 'পাকশী',
    postalCode: '৬৬২০',
    upazila: 'ঈশ্বরদী',
    district: 'পাবনা',
    relation: 'নিজ',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bloodGroup: 'B+',
    phone: '+880 1700-123456',
    occupation: 'আইটি প্রফেশনাল',
    notes: 'প্রধান অ্যাকাউন্ট ও সিস্টেমের মূল ব্যক্তি',
    createdAt: '2026-01-10T09:00:00.000Z'
  },
  {
    id: 'fam_02',
    nameBn: 'মোঃ রফিকুল ইসলাম',
    nameEn: 'Md. Rafiqul Islam',
    dob: '1965-03-12',
    fatherNameBn: 'মরহুম আব্দুল করিম',
    motherNameBn: 'মরহুমা রাবেয়া খাতুন',
    birthRegNo: '19657612345000001',
    nidNo: '19652692512000101',
    village: 'গোবিন্দপুর',
    postOffice: 'পাকশী',
    postalCode: '৬৬২০',
    upazila: 'ঈশ্বরদী',
    district: 'পাবনা',
    relation: 'পিতা',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bloodGroup: 'O+',
    phone: '+880 1711-223344',
    occupation: 'অবসরপ্রাপ্ত সরকারি কর্মকর্তা',
    notes: 'পারিবারিক অভিভাবক',
    createdAt: '2026-01-10T09:30:00.000Z'
  },
  {
    id: 'fam_03',
    nameBn: 'মোছাঃ রোকেয়া বেগম',
    nameEn: 'Most. Rokeya Begum',
    dob: '1970-07-20',
    fatherNameBn: 'মকবুল হোসেন',
    motherNameBn: 'জাহানারা খাতুন',
    birthRegNo: '19707612345000002',
    nidNo: '19702692512000102',
    village: 'গোবিন্দপুর',
    postOffice: 'পাকশী',
    postalCode: '৬৬২০',
    upazila: 'ইশ্বরদী',
    district: 'পাবনা',
    relation: 'মাতা',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    bloodGroup: 'A+',
    phone: '+880 1712-998877',
    occupation: 'গৃহিণী',
    notes: 'গৃহকর্ত্রী ও স্নেহময়ী মাতা',
    createdAt: '2026-01-10T10:00:00.000Z'
  },
  {
    id: 'fam_04',
    nameBn: 'মোছাঃ সুমাইয়া আক্তার',
    nameEn: 'Most. Sumaiya Akter',
    dob: '1998-12-05',
    fatherNameBn: 'মোঃ আব্দুল হান্নান',
    motherNameBn: 'সুলতানা রাজিয়া',
    birthRegNo: '19987612345000005',
    nidNo: '19982692512000555',
    village: 'গোবিন্দপুর',
    postOffice: 'পাকশী',
    postalCode: '৬৬২০',
    upazila: 'ঈশ্বরদী',
    district: 'পাবনা',
    relation: 'স্ত্রী',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    bloodGroup: 'B+',
    phone: '+880 1799-887766',
    occupation: 'শিক্ষিকা',
    notes: 'সহধর্মিণী',
    createdAt: '2026-01-12T11:00:00.000Z'
  }
];

export const initialEducation: EducationItem[] = [
  {
    id: 'edu_01',
    examName: 'বি.এসসি (কম্পিউটার সায়েন্স অ্যান্ড ইঞ্জিনিয়ারিং)',
    passingYear: '২০১৭',
    boardUniversity: 'রাজশাহী বিশ্ববিদ্যালয়',
    institutionName: 'কম্পিউটার সায়েন্স অ্যান্ড ইঞ্জিনিয়ারিং বিভাগ',
    gpa: '৩.৬৫ / ৪.০০',
    majorGroup: 'কম্পিউটার সায়েন্স',
    certificateUrl: 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?auto=format&fit=crop&w=600&q=80',
    certificateFileName: 'BSc_Certificate_Robiul.pdf',
    notes: 'প্রথম শ্রেণীতে উত্তীর্ণ',
    createdAt: '2026-01-11T09:00:00.000Z'
  },
  {
    id: 'edu_02',
    examName: 'এইচ.এস.সি (উচ্চ মাধ্যমিক)',
    passingYear: '২০১৩',
    boardUniversity: 'রাজশাহী শিক্ষা বোর্ড',
    institutionName: 'ঈশ্বরদী সরকারি কলেজ',
    gpa: '৫.০০ (জিপিএ-৫)',
    majorGroup: 'বিজ্ঞান বিভাগ',
    certificateUrl: 'https://images.unsplash.com/photo-1589330694653-dad6bc0140ad?auto=format&fit=crop&w=600&q=80',
    certificateFileName: 'HSC_Certificate.pdf',
    notes: 'ট্যালেন্টপুল বৃত্তি প্রাপ্ত',
    createdAt: '2026-01-11T09:15:00.000Z'
  },
  {
    id: 'edu_03',
    examName: 'এস.এস.সি (মাধ্যমিক)',
    passingYear: '২০১১',
    boardUniversity: 'রাজশাহী শিক্ষা বোর্ড',
    institutionName: 'পাকশী রেলওয়ে উচ্চ বিদ্যালয়',
    gpa: '৫.০০ (জিপিএ-৫)',
    majorGroup: 'বিজ্ঞান বিভাগ',
    certificateUrl: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80',
    certificateFileName: 'SSC_Certificate.pdf',
    notes: 'কৃতি শিক্ষার্থী হিসেবে সংবর্ধনা',
    createdAt: '2026-01-11T09:30:00.000Z'
  }
];

export const initialSkills: SkillItem[] = [
  {
    id: 'skl_01',
    skillName: 'ওয়েব ও ইনফরমেশন সিস্টেম ডেভেলপমেন্ট',
    proficiencyLevel: 'বিশেষজ্ঞ',
    experienceYears: '৭+ বছর',
    description: 'React, TypeScript, Node.js, REST API এবং ডাটাবেজ সিস্টেম ডিজাইন।',
    category: 'কারিগরি প্রযুক্তি',
    createdAt: '2026-01-11T10:00:00.000Z'
  },
  {
    id: 'skl_02',
    skillName: 'ডাটাবেজ ও ক্লাউড ডাটা ম্যানেজমেন্ট',
    proficiencyLevel: 'দক্ষ',
    experienceYears: '৫ বছর',
    description: 'পোস্টগ্রেসিকিউএল, মাইএসকিউএল, ফায়ারবেস এবং ক্লাউড ব্যাকআপ সমাধান।',
    category: 'ডাটা ব্যবস্থাপনা',
    createdAt: '2026-01-11T10:15:00.000Z'
  },
  {
    id: 'skl_03',
    skillName: 'ভূমি ও সম্পদ রেকর্ড অ্যানালাইসিস',
    proficiencyLevel: 'মধ্যম',
    experienceYears: '৩ বছর',
    description: 'খতিয়ান, পরচা, দাগ নম্বর যাচাই ও ডিজিটাল ভূমি তথ্য সংরক্ষণ।',
    category: 'আইন ও নথিপত্র',
    createdAt: '2026-01-11T10:30:00.000Z'
  },
  {
    id: 'skl_04',
    skillName: 'মাইক্রোসফট অফিস ও ডিজিটাল রিপোর্টিং',
    proficiencyLevel: 'বিশেষজ্ঞ',
    experienceYears: '৮ বছর',
    description: 'অ্যাডভান্সড এক্সেল, অটোমেটেড ফর্মুলা, পাওয়ারপয়েন্ট ও প্রেজেন্টেশন।',
    category: 'অফিস অ্যাপ্লিকেশন',
    createdAt: '2026-01-11T10:45:00.000Z'
  }
];

export const initialAssets: AssetItem[] = [
  {
    id: 'ast_01',
    district: 'পাবনা',
    upazila: 'ঈশ্বরদী',
    landOffice: 'পাকশী ইউনিয়ন ভূমি অফিস',
    mouza: 'রূপপুর',
    jlNo: '৭২',
    holdingNo: '৫৪৮',
    khatianNo: 'বি.এস. ১২০৪',
    owners: [
      { id: 'own_1', name: 'মোঃ রোবিউল ইসলাম', share: '৮ আনা (৫০%)' },
      { id: 'own_2', name: 'মোঃ রফিকুল ইসলাম', share: '৮ আনা (৫০%)' }
    ],
    plots: [
      { id: 'plt_1', dagPlotNo: 'দাগ নং ৩৫০২', landCategory: 'ভিটি / বসতবাড়ি', landArea: '১৪.৫', unit: 'শতক' },
      { id: 'plt_2', dagPlotNo: 'দাগ নং ৩৫০৩', landCategory: 'বাগান ও পুকুর পাড়', landArea: '১০.০', unit: 'শতক' }
    ],
    deedDocumentUrl: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=600&q=80',
    deedDocumentName: 'দলিল_নং_৪৫১২_পাকশী.pdf',
    khatianDocumentUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
    khatianDocumentName: 'খতিয়ান_পরচা_১২০৪.pdf',
    estimatedValueBDT: 4800000,
    remarks: 'পাকশী মেইন রোডের নিকটবর্তী পৈতৃক ও ক্রয়সূত্রে অর্জিত বসতভিটা ও বাগান।',
    createdAt: '2026-01-12T14:00:00.000Z'
  },
  {
    id: 'ast_02',
    district: 'পাবনা',
    upazila: 'ঈশ্বরদী',
    landOffice: 'দাশুরিয়া ইউনিয়ন ভূমি অফিস',
    mouza: 'দাশুরিয়া',
    jlNo: '৮৫',
    holdingNo: '৩১৮',
    khatianNo: 'আর.এস. ৮৯০',
    owners: [
      { id: 'own_3', name: 'মোঃ রোবিউল ইসলাম', share: '১৬ আনা (১০০%)' }
    ],
    plots: [
      { id: 'plt_3', dagPlotNo: 'দাগ নং ১২১০', landCategory: 'নাল (কৃষি জমি)', landArea: '৩৩.০', unit: 'শতক' }
    ],
    deedDocumentUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80',
    deedDocumentName: 'সাব_রেজিস্ট্রি_দলিল_৭৮৯.pdf',
    khatianDocumentUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
    khatianDocumentName: 'দাশুরিয়া_খতিয়ান_৮৯০.pdf',
    estimatedValueBDT: 2500000,
    remarks: 'উর্বর তিন ফসলী আবাদি জমি। সেচ সুবিধা বিদ্যমান।',
    createdAt: '2026-01-13T15:30:00.000Z'
  }
];

export const initialLiabilities: LiabilityItem[] = [
  {
    id: 'lia_01',
    liabilityReason: 'মোটরসাইকেল ক্রয় বাবদ লোন',
    creditorName: 'ডাচ-বাংলা ব্যাংক লিমিটেড (ঈশ্বরদী শাখা)',
    incurredDate: '2024-03-15',
    loanAmountBDT: 180000,
    expectedRepaymentDate: '2026-06-30',
    paidAmountBDT: 140000,
    status: 'চলমান',
    remarks: 'মাসিক কিস্তিতে নিয়মিত পরিশোধ চলমান রয়েছে। অবশিষ্ট কিস্তি মাত্র ৪টি।',
    attachmentUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80',
    attachmentFileName: 'DBBL_Loan_Sanction_Letter.pdf',
    createdAt: '2026-01-14T10:00:00.000Z'
  },
  {
    id: 'lia_02',
    liabilityReason: 'বাগান সংস্কার ও বাড়ি উন্নয়ন ধার',
    creditorName: 'জনাব কামরুল হাসান (পারিবারিক আত্মীয়)',
    incurredDate: '2025-08-01',
    loanAmountBDT: 75000,
    expectedRepaymentDate: '2026-12-15',
    paidAmountBDT: 75000,
    status: 'পরিশোধিত',
    remarks: 'সম্পূর্ণ টাকা ব্যাংকিং চ্যানেলে পরিশোধ করা হয়েছে। কোনো পাওনা নেই।',
    createdAt: '2026-01-14T10:30:00.000Z'
  }
];

export const initialEmployment: EmploymentItem[] = [
  {
    id: 'emp_01',
    companyName: 'টেকনোভার্স বাংলাদেশ লিমিটেড',
    designation: 'সিনিয়র সিস্টেম অ্যানালিস্ট ও ডাটা ম্যানেজার',
    joiningDate: '2022-04-01',
    isCurrent: true,
    releaseDate: '',
    department: 'ইনফরমেশন টেকনোলজি ও সফটওয়্যার বিভাগ',
    location: 'গুলশান-২, ঢাকা (হাইব্রিড)',
    salaryBDT: 85000,
    remarks: 'প্রতিষ্ঠানের ডিজিটাল ডাটাবেজ আর্কিটেকচার, টিম সুপারভিশন এবং ক্লাউড সিস্টেম তদারকির দায়িত্ব পালন।',
    joiningLetterUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
    joiningLetterName: 'Joining_Letter_Technoverse.pdf',
    appointmentLetterUrl: 'https://images.unsplash.com/photo-1589330694653-dad6bc0140ad?auto=format&fit=crop&w=600&q=80',
    appointmentLetterName: 'Appointment_Technoverse_Robiul.pdf',
    createdAt: '2026-01-15T11:00:00.000Z'
  },
  {
    id: 'emp_02',
    companyName: 'ইনফোটেক সলিউশনস',
    designation: 'জুনিয়র সফটওয়্যার ইঞ্জিনিয়ার',
    joiningDate: '2018-02-15',
    isCurrent: false,
    releaseDate: '2022-03-25',
    department: 'সফটওয়্যার ডেভেলপমেন্ট',
    location: 'বনানী, ঢাকা',
    salaryBDT: 45000,
    remarks: 'ক্লায়েন্ট পোর্টাল ও ডাটা ম্যানেজমেন্ট মডিউল তৈরিতে ৪ বছর সফলভাবে দায়িত্ব সম্পন্ন।',
    joiningLetterUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
    joiningLetterName: 'Infotech_Release_Experience.pdf',
    appointmentLetterUrl: 'https://images.unsplash.com/photo-1589330694653-dad6bc0140ad?auto=format&fit=crop&w=600&q=80',
    appointmentLetterName: 'Infotech_Appointment.pdf',
    createdAt: '2026-01-15T11:30:00.000Z'
  }
];

export const initialActivities: ActivityLog[] = [
  {
    id: 'act_01',
    action: 'auth',
    module: 'সিস্টেম',
    descriptionBn: 'সিস্টেমে সফলভাবে লগইন করা হয়েছে।',
    descriptionEn: 'Successfully logged in to Robiul IMS.',
    timestamp: '2026-11-05T20:30:00.000Z'
  },
  {
    id: 'act_02',
    action: 'create',
    module: 'সম্পদ',
    descriptionBn: 'পাকশী মৌজার খতিয়ান নং ১২০৪ এর নতুন জমি সংক্রান্ত তথ্য যুক্ত করা হয়েছে।',
    descriptionEn: 'New land asset record added for Pakshi mouza.',
    timestamp: '2026-11-04T16:20:00.000Z'
  },
  {
    id: 'act_03',
    action: 'update',
    module: 'দায়',
    descriptionBn: 'মোটরসাইকেল লোনের কিস্তির তথ্য হালনাগাদ করা হয়েছে।',
    descriptionEn: 'Updated payment installment for motorcycle loan.',
    timestamp: '2026-11-03T11:45:00.000Z'
  }
];
