export type Language = 'bn' | 'en';

export type UserRole = 'owner' | 'admin' | 'viewer';

export interface UserProfile {
  id: string;
  nameBn: string;
  nameEn: string;
  email: string;
  phone: string;
  designation: string;
  bio: string;
  avatarUrl: string;
  nid: string;
  dob: string;
  bloodGroup: string;
  address: {
    village: string;
    postOffice: string;
    postalCode: string;
    upazila: string;
    district: string;
  };
}

export type FamilyRelation = 
  | 'নিজ' 
  | 'পিতা' 
  | 'মাতা' 
  | 'ভাই' 
  | 'বোন' 
  | 'স্ত্রী' 
  | 'স্বামী' 
  | 'সন্তান(কন্যা)' 
  | 'সন্তান(পুত্র)' 
  | 'দাদা' 
  | 'দাদী' 
  | 'অন্যান্য';

export interface FamilyMember {
  id: string;
  nameBn: string;
  nameEn: string;
  dob: string;
  fatherNameBn: string;
  motherNameBn: string;
  birthRegNo: string;
  nidNo: string;
  village: string;
  postOffice: string;
  postalCode: string;
  upazila: string;
  district: string;
  relation: FamilyRelation;
  photoUrl: string;
  bloodGroup?: string;
  phone?: string;
  occupation?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface EducationItem {
  id: string;
  examName: string; // যেমন: এস.এস.সি, এইচ.এস.সি, বি.এসসি ইত্যাদি
  passingYear: string;
  boardUniversity: string;
  institutionName: string;
  gpa: string;
  certificateUrl: string;
  certificateFileName?: string;
  majorGroup?: string;
  notes?: string;
  createdAt: string;
}

export interface SkillItem {
  id: string;
  skillName: string;
  proficiencyLevel: 'শিক্ষানবিস' | 'মধ্যম' | 'দক্ষ' | 'বিশেষজ্ঞ';
  experienceYears: string;
  description: string;
  certificateUrl?: string;
  certificateFileName?: string;
  category?: string;
  createdAt: string;
}

export interface LandOwner {
  id: string;
  name: string;
  share: string; // যেমন: ১৬ আনা, ৮ আনা, ৫০% বা অংশ
}

export interface LandPlot {
  id: string;
  dagPlotNo: string;
  landCategory: string; // যেমন: নাল, ধানী, ভিটি, পুকুর, বাড়ি, বাণিজ্যিক
  landArea: string; // পরিমাণ (যেমন: ২০ শতক, ০.২০ একর)
  unit: string; // শতক, একর, কাঠা
}

export interface AssetItem {
  id: string;
  // সেকশন ১: সাধারণ তথ্য
  district: string;
  upazila: string;
  landOffice: string; // ইউনিয়ন/পৌর. ভূমি অফিস
  mouza: string;
  jlNo: string;
  holdingNo: string;
  khatianNo: string;

  // সেকশন ২: মালিকের তথ্য (একের অধিক মালিক)
  owners: LandOwner[];

  // সেকশন ৩: জমির তথ্য (একের অধিক দাগ/প্লট)
  plots: LandPlot[];

  // সেকশন ৪: সংযুক্তি
  deedDocumentUrl?: string;
  deedDocumentName?: string;
  khatianDocumentUrl?: string;
  khatianDocumentName?: string;

  estimatedValueBDT?: number;
  remarks?: string;
  createdAt: string;
}

export interface LiabilityItem {
  id: string;
  liabilityReason: string; // যে বাবদ দায় রয়েছে (যেমন: গৃহ ঋণ, বাইক লোন, ব্যক্তিগত ধার)
  creditorName: string; // যে প্রতিষ্ঠান/ব্যক্তির নিকট দায় রয়েছে
  incurredDate: string; // দায় গ্রহণের তারিখ
  loanAmountBDT: number; // ঋণের পরিমাণ (টাকায়)
  expectedRepaymentDate: string; // সম্ভব্য পরিশোধের তারিখ
  paidAmountBDT?: number; // পরিশোধিত অংশ
  status: 'চলমান' | 'আংশিক পরিশোধিত' | 'পরিশোধিত';
  remarks?: string; // মন্তব্য
  attachmentUrl?: string; // সংযুক্তি
  attachmentFileName?: string;
  createdAt: string;
}

export interface EmploymentItem {
  id: string;
  companyName: string; // প্রতিষ্ঠানের নাম
  designation: string; // পদবী
  joiningDate: string; // চাকুরীতে যোগদানের তারিখ
  isCurrent: boolean; // চলমান চেকবক্স
  releaseDate?: string; // অব্যাহতির তারিখ (চলমান থাকলে disabled)
  department?: string;
  location?: string;
  remarks?: string; // মন্তব্য / কাজের দায়িত্ব
  joiningLetterUrl?: string; // যোগদান পত্র
  joiningLetterName?: string;
  appointmentLetterUrl?: string; // নিয়োগপত্র
  appointmentLetterName?: string;
  salaryBDT?: number;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  action: 'create' | 'update' | 'delete' | 'auth' | 'backup';
  module: 'পরিবার' | 'শিক্ষা' | 'দক্ষতা' | 'সম্পদ' | 'দায়' | 'চাকুরী' | 'প্রোফাইল' | 'সিস্টেম';
  descriptionBn: string;
  descriptionEn: string;
  timestamp: string;
}

export type ToastType = 'success' | 'info' | 'warning' | 'error';

export interface ToastMessage {
  id: string;
  type: ToastType;
  title: string;
  message: string;
}
